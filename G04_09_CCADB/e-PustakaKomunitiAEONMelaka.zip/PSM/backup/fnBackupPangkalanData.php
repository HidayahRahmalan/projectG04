<?php 
include('dumper.php');
include('../connection/config.php');

$tableName = $_GET['tableName'];
$date=date('d-m-Y');
$dumpString = "$tableName($date).sql";
$dumpStringAll = "e-pustaka($date).sql";


if($tableName == 'allTable'){

	try {
		
		$dumper = Shuttle_Dumper::create(array(
			'host' => 'localhost',
			'username' => 'root',
			'password' => '',
			'db_name' => 'psm',
		));
		$dumper->dump($dumpStringAll);

		mysql_query("INSERT INTO backup_log VALUES('', 'SEMUA PANGKALAN DATA', NOW(), 'BACKUP PANGKALAN DATA')")or die(mysql_error());

		echo '<script language = "JavaScript">alert("Berjaya Muat Turun Keseluruhan Struktur Rajah!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/backupPangkalanData.php">';

	} catch(Shuttle_Exception $e) {
		echo '<script language = "JavaScript">alert("Maaf, terdapat sedikit kesulitan sila hubungi pihak administrator")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/backupPangkalanData.php">';
	}

}else{

	try {
		
		$dumper = Shuttle_Dumper::create(array(
			'host' => 'localhost',
			'username' => 'root',
			'password' => '',
			'db_name' => 'psm',
			'include_tables' => array($tableName),
		));
		$dumper->dump($dumpString);

		mysql_query("INSERT INTO backup_log VALUES('', '$tableName', NOW(), 'BACKUP PANGKALAN DATA')")or die(mysql_error());

		echo '<script language = "JavaScript">alert("Berjaya Muat Turun Struktur Rajah '.$tableName.'!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/backupPangkalanData.php">';

	} catch(Shuttle_Exception $e) {
		echo '<script language = "JavaScript">alert("Maaf, terdapat sedikit kesulitan sila hubungi pihak administrator")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/backupPangkalanData.php">';
	}
}