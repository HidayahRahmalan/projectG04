<?php 
//ignore Warnings
error_reporting(E_ALL & ~E_NOTICE & ~8192);
session_start();
require('../function/fnUserDetail.php');
if(!isset($_GET['staffIDEncrypt']) && isset($_SESSION['staffIDEncrypt'])) header("location: ?staffIDEncrypt=".getId($_SESSION['staffIDEncrypt']));

include("../connection/config.php");
//Get Latest available member ID for [KANAK-KANAK]
$getMemberIDKanak = mysql_query("CALL getMemberIDKanak()");
$get = mysql_fetch_assoc($getMemberIDKanak);
$memberIDKanakTemp = $get['memberIDKid'];
$memberIDKanak = $memberIDKanakTemp + 1;
$K = "K";
if($memberIDKanak <= 9){$memberIDKanak = '000'.$memberIDKanak.''.$K.''; }
    elseif($memberIDKanak >= 10 && $memberIDKanak <=99 ){ $memberIDKanak = '00'.$memberIDKanak.''.$K.''; }
    elseif($memberIDKanak >= 100 && $memberIDKanak <=199 ){ $memberIDKanak = '0'.$memberIDKanak.''.$K.''; }
    elseif($memberIDKanak >= 1000){ $memberIDKanak = ''.$memberIDKanak.'K'; }
mysql_close($con);

include("../connection/config.php");
//Get Latest available member ID for [BELIA]
$getMemberIDBelia = mysql_query("CALL getMemberIDBelia()");
$get1 = mysql_fetch_assoc($getMemberIDBelia);
$memberIDBeliaTemp = $get1['memberIDYouth'];
$memberIDBelia = $memberIDBeliaTemp + 1;
$B = "B";
if($memberIDBelia <= 9){$memberIDBelia = '000'.$memberIDBelia.''.$B.''; }
    elseif($memberIDBelia >= 10 && $memberIDBelia <=99 ){ $memberIDBelia = '00'.$memberIDBelia.''.$B.''; }
    elseif($memberIDBelia >= 100 && $memberIDBelia <=199 ){ $memberIDBelia = '0'.$memberIDBelia.''.$B.''; }
    elseif($memberIDBelia >= 1000){ $memberIDBelia = ''.$memberIDBelia.'B'; }
mysql_close($con);

include("../connection/config.php");
//Get Latest available member ID for [DEWASA]
$getMemberIDDewasa = mysql_query("CALL getMemberIDDewasa()");
$get2 = mysql_fetch_assoc($getMemberIDDewasa);
$memberIDDewasaTemp = $get2['memberIDAdult'];
$memberIDDewasa = $memberIDDewasaTemp + 1;
$D = "D";
if($memberIDDewasa <= 9){$memberIDDewasa = '000'.$memberIDDewasa.''.$D.''; }
    elseif($memberIDDewasa >= 10 && $memberIDDewasa <=99 ){ $memberIDDewasa = '00'.$memberIDDewasa.''.$D.''; }
    elseif($memberIDDewasa >= 100 && $memberIDDewasa <=199 ){ $memberIDDewasa = '0'.$memberIDDewasa.''.$D.''; }
    elseif($memberIDDewasa >= 1000){ $memberIDDewasa = ''.$memberIDDewasa.'D'; }
mysql_close($con);

include("../connection/config.php");
//Get Latest available email ID
$getEmailID = mysql_query("CALL getEmailID()");
$get3 = mysql_fetch_assoc($getEmailID);
$emailIDTemp = $get3['emailID'];
$emailID = $emailIDTemp + 1;
mysql_close($con);

include("../connection/config.php");
//Get Latest available contact ID
$getContactID = mysql_query("CALL getContactID()");
$get4 = mysql_fetch_assoc($getContactID);
$contactIDTemp = $get4['contactID'];
$contactID = $contactIDTemp + 1;
mysql_close($con);

include("../connection/config.php");
//Count Jumlah Message
$getTotalMessage = mysql_query("CALL getTotalMessage()")or die(mysql_error());
$get5 = mysql_fetch_assoc($getTotalMessage);
$totalMessage = $get5['totalMessage'];
mysql_close($con);

$currentYear = date("Y");
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php include("../include/tabTitle.php"); ?></title>

    <!-- Tab icon -->
    <?php include("../include/iconTab.php"); ?>
    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <!-- Timeline CSS -->
    <link href="../dist/css/timeline.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <script>
        function showMemberIDKids()
        {
            document.getElementById("labelMemberIDKid").hidden="";
            document.getElementById("labelMemberIDYouth").hidden="hidden";
            document.getElementById("labelMemberIDAdult").hidden="hidden";
        }
        
        function showMemberIDYouth()
        {
            document.getElementById("labelMemberIDYouth").hidden="";
            document.getElementById("labelMemberIDKid").hidden="hidden";
            document.getElementById("labelMemberIDAdult").hidden="hidden";

        }

        function showMemberIDAdult()
        {
            document.getElementById("labelMemberIDAdult").hidden="";
            document.getElementById("labelMemberIDKid").hidden="hidden";
            document.getElementById("labelMemberIDYouth").hidden="hidden";
        }

        function copyValuePerempuan(){
            document.getElementById("resultGender").value="PEREMPUAN";
        }

        function copyValueLelaki(){
            document.getElementById("resultGender").value="LELAKI";
        }

        function detectGenderBOD(){
            var memberIC = document.getElementById("memberIC").value;


            if((memberIC%1) != 0){
                document.getElementById("genderMalePassport").checked=false;
                document.getElementById("genderFemalePassport").checked=false;
                document.getElementById("checkKanak").hidden="hidden";
                document.getElementById("checkDewasa").hidden="hidden";
                document.getElementById("checkBelia").hidden="hidden";
                document.getElementById("passportCheckBox").hidden="";
                document.getElementById("memberBOD").value="";
                document.getElementById("memberBOD").readOnly=false;
                document.getElementById("genderMalePassport").hidden="";
                document.getElementById("genderMaleTextPassport").hidden="";
                document.getElementById("genderFemalePassport").hidden="";
                document.getElementById("genderFemaleTextPassport").hidden="";
                document.getElementById("checkBoxIC").hidden="hidden";
                document.getElementById("genderMale").hidden="hidden";
                document.getElementById("genderMaleText").hidden="hidden";
                document.getElementById("genderFemale").hidden="hidden";
                document.getElementById("genderFemaleText").hidden="hidden";

            }else{
                document.getElementById("genderMalePassport").hidden="hidden";
                document.getElementById("genderFemalePassport").hidden="hidden";
                document.getElementById("passportCheckBox").hidden="hidden";
                document.getElementById("memberBOD").readOnly=true;
                document.getElementById("genderMalePassport").hidden="hidden";
                document.getElementById("genderMaleTextPassport").hidden="hidden";
                document.getElementById("genderFemalePassport").hidden="hidden";
                document.getElementById("genderFemaleTextPassport").hidden="hidden";
                document.getElementById("checkBoxIC").hidden="";

            var memberGender = document.getElementById("memberGender").value;
            var resultGender = document.getElementById("resultGender");
            var memberBOD = document.getElementById("memberBOD");

            var genderMale = document.getElementById("genderMale");
            var genderMaleText = document.getElementById("genderMaleText");

            var genderFemale = document.getElementById("genderFemale");
            var genderFemaleText = document.getElementById("genderFemaleText");

            var memberYear2Digit = document.getElementById("memberYear2Digit");
            var memberYear = document.getElementById("memberYear");
            var currentYear = document.getElementById("currentYear");
            var radioKanak = document.getElementById("radioKanak");
            var radioDewasa = document.getElementById("radioDewasa");
            var radioBelia = document.getElementById("radioBelia");
            var memberAge = document.getElementById("memberAge");

            var endValueIC = memberIC.substring(11, 12);
            var birthYearIC = memberIC.substring(0,2);
            var birthMonthIC = memberIC.substring(2,4);
            var birthDateIC = memberIC.substring(4,6);
            memberYear2Digit.value = birthYearIC;

            memberGender = endValueIC;
            memberBOD.value = birthDateIC + "/" + birthMonthIC + "/" + birthYearIC;

                //Echo Year for Member
                if(memberYear2Digit.value >= 00 && memberYear2Digit.value <= 70){
                    memberYear.value = "20" + memberYear2Digit.value;

                    //Get Member Age
                    memberAge.value = currentYear.value - memberYear.value;
                }
                else{
                    memberYear.value = "19" + memberYear2Digit.value;
                     
                    //Get Member Age
                    memberAge.value = currentYear.value - memberYear.value;
                }

                //onClick radio button type user
                if(memberAge.value >= 3 && memberAge.value <= 12){
                    radioKanak.click();
                    document.getElementById("checkKanak").hidden="";
                    document.getElementById("checkDewasa").hidden="hidden";
                    document.getElementById("checkBelia").hidden="hidden";
                    document.getElementById("unCheckAll").hidden="hidden";
                }
                if(memberAge.value >= 13 && memberAge.value <= 20){
                    radioBelia.click();
                    document.getElementById("checkKanak").hidden="hidden";
                    document.getElementById("checkDewasa").hidden="hidden";
                    document.getElementById("checkBelia").hidden="";
                    document.getElementById("unCheckAll").hidden="hidden";
                }
                if(memberAge.value >= 21){
                    radioDewasa.click();
                    document.getElementById("checkKanak").hidden="hidden";
                    document.getElementById("checkDewasa").hidden="";
                    document.getElementById("checkBelia").hidden="hidden";
                    document.getElementById("unCheckAll").hidden="hidden";
                }

                //GENAP PEREMPUAN
                //LELAKI GANJIL
                if(memberGender == 1 || memberGender == 3 || memberGender == 5 || memberGender == 7 || memberGender == 9){
                    resultGender.value = "LELAKI";
                    genderMale.hidden="";
                    genderMaleText.hidden="";
                    genderFemale.hidden="hidden";
                    genderFemaleText.hidden="hidden";
                }
                if(memberGender == 0 || memberGender == 2 || memberGender == 4 || memberGender == 6 || memberGender == 8) {
                    resultGender.value = "PEREMPUAN";
                    genderMale.hidden="hidden";
                    genderMaleText.hidden="hidden";
                    genderFemale.hidden="";
                    genderFemaleText.hidden="";

                }

            }
        }
    </script>

</head>
<?php 
    include("../connection/config.php");
     if(isset($_SESSION['staffIDEncrypt']))
     { 
        $profileUsersData = getUsersData(mysql_real_escape_string($_GET['staffIDEncrypt']));
        ?>
        <?php if(userExists(mysql_real_escape_string($_GET['staffIDEncrypt']))){
        $staffID = $profileUsersData['staffID'];
        ?>
<body style="background-color: <?php include('../include/colorCode.php'); ?>">

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0; background-color: <?php include('../include/colorCode.php'); ?>">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php include("../include/headerTitle.php"); ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-envelope fa-fw"></i> 
                        <?php if($totalMessage > 0){ ?>
                        <span class="label label-success"><?php echo $totalMessage; ?></span>
                        <i class="fa fa-caret-down"></i>
                        <?php }else{?>
                        <i class="fa fa-caret-down"></i>
                        <?php } ?>
                    </a>
                    <ul class="dropdown-menu dropdown-messages">
                        <?php
                        if($totalMessage > 0){
                        include("../connection/config.php");
                        $displayListMessage = "CALL displayListMessage()";           
                        $myData = mysql_query($displayListMessage)or die(mysql_error());
                                    
                            while($record = mysql_fetch_array($myData)){
                            $billLogPinjamanBuku++;
                            $memberName = $record['memberName'];
                            $memberID = $record['memberID'];
                            $dateUploadTemp = $record['dateUpload'];
                            $dateUpload = date("d/m/Y h:i:s a", strtotime($dateUploadTemp));
                            echo'<li>
                                <a href="paparanBorangCopPengesahanAhli.php?memberID='.$memberID.'">
                                    <div>
                                        <strong>'.$memberID.'</strong>
                                        <span class="pull-right text-muted">
                                            <em>'.$dateUpload.'</em>
                                        </span>
                                    </div>
                                    <div>Cop Pengesahan dari '.$memberName.'...</div>
                                </a>
                            </li>
                            <li class="divider"></li>';
                            }
                            echo'<li>
                                    <a class="text-center" href="paparanKeseluruhanMessage.php">
                                        <strong>Baca Keseluruhan Mesej</strong>
                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>';
                        }else{
                            echo'<li>
                                <a href="#">
                                    <div>
                                        <strong></strong>
                                        <span class="pull-right text-muted">
                                            <em></em>
                                        </span>
                                    </div>
                                    <div><br></div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a class="text-center" href="paparanKeseluruhanMessage.php">
                                    <strong>Baca Keseluruhan Mesej</strong>
                                    <i class="fa fa-angle-right"></i>
                                </a>
                            </li>';
                        }
                        mysql_close($con);
                        ?>
                    </ul>
                    <!-- /.dropdown-messages -->
                </li>
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="penetapanAkaun.php"><i class="fa fa-gear fa-fw"></i> Penetapan Akaun</a>
                        </li>
                        <li class="divider"></li>
                        <?php echo '<li><a href="../function/logout.php?staffID='.$staffID.'"><i class="fa fa-sign-out fa-fw"></i> Log Keluar</a>
                        </li>'; ?>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation" style="background-color: <?php include('../include/colorCode.php'); ?>">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <?php include("../include/leftPanelDetail.php"); ?>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <?php include("../include/userMenu.php"); ?>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Ahli Baru</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            BORANG PENDAFTARAN KEAHLIAN PERPUSTAKAAN (PERPUSTAM)
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                <form action="../function/fnDaftarAhliBaru.php" method="POST" name="myForm">
                                    <table border="1" width="100%">
                                      <tr>
                                        <th colspan="2"><center><b>BORANG PENDAFTARAN KEAHLIAN PERPUSTAKAAN (PERPUSTAM)</b></center></th>
                                      </tr>
                                    </table>

                                    <br>

                                    <table border="1" width="100%">
                                      <tr>
                                        <td style="padding-top: 10px">
                                            
                                            <table border="0" width="50%">
                                            <tr>
                                                <td valign="top" style="padding-top: 10px; padding-left: 10px">
                                                    <img src="../images/logoPerpustam.png" width="60px" height="60px">
                                                </td>

                                                <td>&nbsp;</td>
                                                
                                                <td>
                                                <p style="font-size: 8pt">
                                                <b>PERBADANAN PERPUSTAKAAN AWAM MELAKA</b><br>
                                                242-1, JALAN BUKIT BARU, 75150 MELAKA<br>
                                                NO TEL: 06-2824859&emsp;&emsp;NO FAX: 06-2824798<br>
                                                LAMAN WEB : <u>http://www.perpustam.gov.my</u><br>
                                                EMAIL : perkhidmatan@perpustam.gov.my
                                                </p>
                                                </td>

                                            </tr>
                                            </table>
                                            
                                        </td>


                                        <td width="35%" rowspan="2" valign="top" style="padding-top: 10px; padding-left: 10px">
                                            <p style="font-size: 8pt">
                                                <b>TANDA &#9745; PADA YANG BERKENAAN : -</b><br>
                                                <div id="passportCheckBox" hidden>
                                                    <div style="font-size: 8pt">
                                                        <input type="radio" onClick="showMemberIDKids()" name="memberType" value="KANAK-KANAK" required id="radioKanak">&nbsp;<b>KANAK-KANAK / CHILD</b> (3&frac12; HINGGA 12 TAHUN)
                                                    </div>
                                                    <div style="font-size: 8pt">
                                                        <input type="radio" onClick="showMemberIDYouth()" name="memberType" value="BELIA" required id="radioBelia">&nbsp;<b>BELIA / YOUTH</b> (13 HINGGA 20 TAHUN)
                                                    </div>
                                                    <div style="font-size: 8pt">
                                                        <input type="radio" onClick="showMemberIDAdult()" name="memberType" value="DEWASA" required id="radioDewasa">&nbsp;<b>DEWASA / ADULT</b>(21 TAHUN KE ATAS)
                                                    </div>
                                                </div>
                                                
                                                <div id="checkBoxIC">
                                                    <div id="checkKanak" hidden>
                                                        <div style="font-size: 8pt">
                                                            &#9745;&nbsp;<b>KANAK-KANAK / CHILD</b> (3&frac12; HINGGA 12 TAHUN)
                                                        </div>

                                                        <div style="font-size: 8pt">
                                                            &#9744;&nbsp;<b>BELIA / YOUTH</b> (13 HINGGA 20 TAHUN)
                                                        </div>
                                                        
                                                        <div style="font-size: 8pt">
                                                            &#9744;&nbsp;<b>DEWASA / ADULT</b>(21 TAHUN KE ATAS)
                                                        </div>
                                                    </div>

                                                    <div id="checkBelia" hidden>
                                                        <div style="font-size: 8pt">
                                                            &#9744;&nbsp;<b>KANAK-KANAK / CHILD</b> (3&frac12; HINGGA 12 TAHUN)
                                                        </div>

                                                        <div style="font-size: 8pt">
                                                            &#9745;&nbsp;<b>BELIA / YOUTH</b> (13 HINGGA 20 TAHUN)
                                                        </div>

                                                        <div style="font-size: 8pt">
                                                            &#9744;&nbsp;<b>DEWASA / ADULT</b>(21 TAHUN KE ATAS)
                                                        </div>
                                                    </div>

                                                    <div id="checkDewasa" hidden>
                                                        <div style="font-size: 8pt">
                                                        &#9744;&nbsp;<b>KANAK-KANAK / CHILD</b> (3&frac12; HINGGA 12 TAHUN)
                                                        </div>

                                                        <div style="font-size: 8pt">
                                                            &#9744;&nbsp;<b>BELIA / YOUTH</b> (13 HINGGA 20 TAHUN)
                                                        </div>

                                                        <div style="font-size: 8pt">
                                                            &#9745;&nbsp;<b>DEWASA / ADULT</b>(21 TAHUN KE ATAS)
                                                        </div>
                                                    </div>

                                                    <div id="unCheckAll">
                                                        <div style="font-size: 8pt">
                                                        &#9744;&nbsp;<b>KANAK-KANAK / CHILD</b> (3&frac12; HINGGA 12 TAHUN)
                                                        </div>

                                                        <div style="font-size: 8pt">
                                                            &#9744;&nbsp;<b>BELIA / YOUTH</b> (13 HINGGA 20 TAHUN)
                                                        </div>

                                                        <div style="font-size: 8pt">
                                                            &#9744;&nbsp;<b>DEWASA / ADULT</b>(21 TAHUN KE ATAS)
                                                        </div>
                                                    </div>
                                                </div>
                                            </p>

                                        </td>
                                      </tr>


                                      <tr>
                                        <td style="padding-top: 10px; padding-left: 10px">
                                            <p style="font-size: 8pt">
                                                <b>UNTUK KEGUNAAN PEJABAT :-<br>
                                                NO AHLI&emsp;&emsp; : 
                                                <label hidden id="labelMemberIDKid">
                                                <?php 
                                                    echo"$memberIDKanak";
                                                ?>
                                                </label>

                                                <label hidden id="labelMemberIDYouth">
                                                <?php 
                                                    echo"$memberIDBelia";
                                                ?>
                                                </label>


                                                <label hidden id="labelMemberIDAdult">
                                                <?php
                                                    echo"$memberIDDewasa";
                                                ?>
                                                </label><br>
                                                TARIKH&emsp;&emsp;&nbsp;&nbsp; : <?php echo " " . date("d/m/Y") . "<br>"; ?>
                                            </p>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td colspan="2" style="padding-top: 10px; padding-left: 10px">
                                            <p style="font-size: 8pt">
                                            <u><b>BUTIRAN PERIBADI // PERSONAL DETAILS</b></u><br><br>

                                            <b>1.&emsp;NAMA PENUH // <i>FULL NAME</i></b><br>
                                                &emsp;&emsp;<input type="text" name="memberName" required style="width: 500px; text-transform:uppercase;"><br><br>

                                            <b>2.&emsp;NO KAD PENGENALAN / NO. SIJIL KELAHIRAN / NO MYKID // <i>IDENTITY CARD NUMBER / BIRTH CERTIFICATE NUMBER</i></b><br>
                                            &emsp;&emsp;<input type="text" id="memberIC" onkeyup="detectGenderBOD()" maxlength="12" name="memberIC" placeholder="87222310XXXX" required style="width: 150px; text-transform: uppercase;">&nbsp;<label id="labelInfoIC"></label><br><br>

                                            <b>3.&emsp;TARIKH LAHIR (HH/BB/TT) // <i>DATE OF BIRTH (DD/MM/YY)</i></b><br>
                                            &emsp;&emsp;<input type="text" id="memberBOD" placeholder="dd/mm/YY" maxlength="8" name="memberBOD" readonly><br><br>

                                            <b>4.&emsp;JANTINA // <i>GENDER</i></b><br>
                                            &emsp;&emsp;
                                            <label class="radio-inline">
                                                <input hidden id="genderMale" type="radio" name="radioMale" value="LELAKI" checked="checked"><b hidden id="genderMaleText">LELAKI/MALE</b>
                                                
                                                <input hidden id="genderFemale" type="radio" name="radioFemale" value="PEREMPUAN" checked="checked"><b hidden id="genderFemaleText">PEREMPUAN/FEMALE</b>

                                                <input hidden id="genderMalePassport" type="radio" name="radioGender" value="LELAKI" onclick="copyValueLelaki(this)"><b hidden id="genderMaleTextPassport">LELAKI/MALE</b>
                                                &emsp;&emsp;
                                                <input hidden id="genderFemalePassport" type="radio" name="radioGender" value="PEREMPUAN" onclick="copyValuePerempuan(this)"><b hidden id="genderFemaleTextPassport">PEREMPUAN/FEMALE</b>
                                                <input type="hidden" id="memberGender">
                                                <input type="hidden" name="memberGender" id="resultGender">
                                            </label>
                                            <br><br>

                                            <b>5.&emsp;BANGSA // <i>RACE</i></b><br>
                                            &emsp;&emsp;
                                            <label class="radio-inline">
                                                <input type="radio" name="memberRace" value="MELAYU" checked="checked"><b>MELAYU/<i>MALAY</i></b>
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="memberRace" value="CINA"><b>CINA/<i>CHINESE</i></b>
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="memberRace" value="INDIA"><b>INDIA/<i>INDIAN</i></b>
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="memberRace" value="LAIN-LAIN"><b>LAIN-LAIN/<i>OTHERS</i></b>
                                            </label>
                                            <br><br>

                                            <b>6.&emsp;ALAMAT SEMASA // <i>CURRENT ADDRESS</i></b><br>
                                            &emsp;&emsp;<textarea name="memberAddress" class="form-control" rows="3" style="width: 400px; font-size: 8pt; padding-left:10px"></textarea>
                                            <br><br>

                                            <b>7.&emsp;NOMBOR TELEFON : RUMAH(R)/ PEJABAT(P)/ BIMBIT(B) // <i>TELEPHONE NUMBER: HOUSE(H)/ OFFICE(O)/ MOBILE(M)</i></b><br>

                                            <table border="0" style="font-size: 8pt;">
                                                <tr>
                                                <td style="padding-left: 20px;"><b>SUAMI/BAPA  // <i>HUSBAND/FATHER</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:(R/H)</b>&nbsp;<input type="text" name="contactFatherH"></td>
                                                <td><b>&nbsp;(P/O)</b>&nbsp;<input type="text" name="contactFatherO"></td>
                                                <td><b>&nbsp;(B/M)</b>&nbsp;<input type="text" name="contactFatherM"></td>
                                                </tr>

                                                <tr>
                                                <td style="padding-left: 20px;"><b>ISTERI/IBU  // <i>WIFE/MOTHER</i>&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;:(R/H)</b>&nbsp;<input type="text" name="contactMotherH"></td>
                                                <td><b>&nbsp;(P/O)</b>&nbsp;<input type="text" name="contactMotherO"></td>
                                                <td><b>&nbsp;(B/M)</b>&nbsp;<input type="text" name="contactMotherM"></td>
                                                </tr>

                                                <tr>
                                                <td style="padding-left: 20px;"><b>SENDIRI  // <i>SELF</i>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;:(R/H)</b>&nbsp;<input type="text" name="contactSelfH"></td>
                                                <td><b>&nbsp;(P/O)</b>&nbsp;<input type="text" name="contactSelfO"></td>
                                                <td><b>&nbsp;(B/M)</b>&nbsp;<input type="text" name="contactSelfM"></td>
                                                </tr>
                                            </table>
                                            <br><br>


                                            <b style="font-size: 8pt;">8.&emsp;ALAMAT EMAIL // <i>EMAIL ADDRESS</i></b><br>

                                            <table border="0" style="font-size: 8pt;">
                                                <tr>
                                                <td style="padding-left: 20px;"><b>SUAMI/BAPA  // <i>HUSBAND/FATHER</i>&emsp;&emsp;:</b>&nbsp;<input type="text" name="emailFather" style="width:200px"></td>
                                                </tr>

                                                <tr>
                                                <td style="padding-left: 20px;"><b>ISTERI/IBU  // <i>WIFE/MOTHER</i>&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;:</b>&nbsp;<input type="text" name="emailMother" style="width: 200px"></td>
                                                </tr>

                                                <tr>
                                                <td style="padding-left: 20px;"><b>SENDIRI  // <i>SELF</i>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;:</b>&nbsp;<input type="text" name="emailSelf" style="width:200px"></td>
                                                </tr>
                                            </table>
                                            <br><br>

                                            <table border="0" width="100%">
                                            <tr>
                                                <td width="50%" valign="top" style="padding-right: 20px">
                                                    <table border="1">
                                                    <tr>
                                                        <td style="padding-left: 10px;">
                                                            <b style="font-size: 8pt;">PENGESAHAN PEMOHON</b><br>
                                                            
                                                            &emsp;&emsp;<p style="font-size: 7pt;">Saya bersetuju akan mematuhi segala peraturan yang telah ditetapkan  oleh Perbadanan Perpustakaan Awam Melaka.
                                                            <br>
                                                            &emsp;&emsp;<i>I, agree to comply with the terms and condition imposed by the Melaka Public Library Corporation</i>
                                                            </p>
                                                            <br>
                                                            <br>
                                                            <br>
                                                            <br>
                                                            ........................................................................
                                                            <p style="font-size: 8pt;"><b>TANDATANGAN PEMOHON // <i>APPLICAN'S SIGNATURE</i></b></p>
                                                        </td>
                                                    </tr>
                                                    </table>
                                                </td>


                                                <td valign="top" style="padding-right: 10px">
                                                    <table border="1" width="100%">
                                                    <tr>
                                                        <td style="padding-left: 10px">
                                                            <b style="font-size: 8pt;">COP MAJIKAN/IPTA/IPTS/SEKOLAH/TADIKA :-</b><br>
                                                             
                                                            &emsp;&emsp;<p style="font-size: 7pt;">
                                                            <br><br><br>
                                                            </p>
                                                            <br>
                                                            <br>
                                                            <br>
                                                            <br>
                                                            <br>
                                                            <p style="font-size: 8pt;"><br></p>
                                                        </td>
                                                    </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                            </table>

                                            </p>
                                        </td>
                                      </tr>
                                    </table>
                                    <br>
                                    <div hidden>
                                        <input type="text" value="<?php echo $memberIDKanak; ?>" name="memberIDKanak"><input type="text" value="<?php echo $memberIDBelia; ?>" name="memberIDBelia"><input type="text" value="<?php echo $memberIDDewasa; ?>" name="memberIDDewasa">
                                        <input type="text" value="<?php echo $emailID; ?>" name="emailID">
                                        <input type="text" value="<?php echo $contactID; ?>" name="contactID">
                                        <input type="text" name="staffID" value="<?php echo $profileUsersData['staffID']; ?>">
                                        <input type="text" name="currentYear" value="<?php echo $currentYear; ?>" id="currentYear">
                                        <input type="text" name="memberYear2Digit" id="memberYear2Digit">
                                        <input type="text" name="memberAge" id="memberAge">
                                        <input type="text" name="memberYear" id="memberYear">
                                        <input type="radio" onClick="showMemberIDKids()" name="memberType" value="KANAK-KANAK" required id="radioKanak">
                                        <input type="radio" onClick="showMemberIDYouth()" name="memberType" value="BELIA" required id="radioBelia">
                                        <input type="radio" onClick="showMemberIDAdult()" name="memberType" value="DEWASA" required id="radioDewasa">
                                    </div>
                                    <div align="right">
                                        <button type="submit" name="btnDaftarAhliBaru" class="btn btn-default">Daftar Ahli Baru <i class="fa fa-angle-double-right fa-fw"></i></button>
                                    </div>
                                </form>
                                </div>
                                <!-- /.col-lg-12 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>
</html>
<?php  } else echo '<script language = "JavaScript">alert("ID Tidak Sah!"); window.location.href="../index.php?staffIDEncrypt=$id";</script>';?>
<?php
    } 
?>
