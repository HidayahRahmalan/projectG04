<?php 
//ignore Warnings
error_reporting(E_ALL & ~E_NOTICE & ~8192);
session_start();
require('../function/fnUserDetail.php');
if(!isset($_GET['staffIDEncrypt']) && isset($_SESSION['staffIDEncrypt'])) header("location: ?staffIDEncrypt=".getId($_SESSION['staffIDEncrypt']));

if(isset($_POST['btnHantarNotis'])){

    $memberID = $_POST['memberID'];
    $noticeDate = $_POST['noticeDate'];

     echo 
         ' <script language = "JavaScript">
          var papar1 = confirm("Anda pasti untuk senarai hitam ahli ini?");
          
          if(papar1==true)
          {
             self.location="../function/fnDaftarNotisSekolah.php?memberID='.$memberID.'&noticeDate='.$noticeDate.'";
          }
          
         else
         {
              self.location="ahliSenaraiHitam.php";
         }
          
      </script>';
}

if(isset($_POST['btnHantarInfoBlastDewasa'])){

    $memberID = $_POST['memberID'];
    $infoBlastDateDewasa = $_POST['infoBlastDateDewasa'];

     echo 
         ' <script language = "JavaScript">
          var papar1 = confirm("Anda pasti untuk senarai hitam ahli ini?");
          
          if(papar1==true)
          {
             self.location="../function/fnDaftarInfoBlast1Dewasa.php?memberID='.$memberID.'&infoBlastDateDewasa='.$infoBlastDateDewasa.'";
          }
          
         else
         {
              self.location="ahliSenaraiHitam.php";
         }
          
      </script>';
}

if(isset($_POST['btnHantarInfoBlastBelia'])){

    $memberID = $_POST['memberID'];
    $infoBlastDateBelia = $_POST['infoBlastDateBelia'];

     echo 
         ' <script language = "JavaScript">
          var papar1 = confirm("Anda pasti untuk senarai hitam ahli ini?");
          
          if(papar1==true)
          {
             self.location="../function/fnDaftarInfoBlast1Belia.php?memberID='.$memberID.'&infoBlastDateBelia='.$infoBlastDateBelia.'";
          }
          
         else
         {
              self.location="ahliSenaraiHitam.php";
         }
          
      </script>';
}

include("../connection/config.php");
//Count Jumlah Senarai Hitam Keseluruhan
$getTotalBalcklistAll = mysql_query("CALL getTotalBlacklistAll()");
$get = mysql_fetch_assoc($getTotalBalcklistAll);
$totalBlacklist = $get['totalBlacklist'];
mysql_close($con);

include("../connection/config.php");
//Count Jumlah Senarai Hitam Perempuan Keseluruhan
$getTotalBlacklistPerempuan = mysql_query("CALL getTotalBlacklistPerempuan()")or die(mysql_error());
$get1 = mysql_fetch_assoc($getTotalBlacklistPerempuan);
$totalBlacklistPerempuan = $get1['totalBlacklistPerempuan'];
mysql_close($con);

include("../connection/config.php");
// //Count Jumlah Senarai Hitam Lelaki Keseluruhan
$getTotalBlacklistLelaki = mysql_query("CALL getTotalBlacklistLelaki()")or die(mysql_error());
$get2 = mysql_fetch_assoc($getTotalBlacklistLelaki);
$totalBlacklistLelaki = $get2['totalBlacklistLelaki'];
mysql_close($con);

include("../connection/config.php");
//Count Jumlah Message
$getTotalMessage = mysql_query("CALL getTotalMessage()")or die(mysql_error());
$get4 = mysql_fetch_assoc($getTotalMessage);
$totalMessage = $get4['totalMessage'];
mysql_close($con);
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php include("../include/tabTitle.php"); ?></title>
    <!-- Tab icon -->
    <?php include("../include/iconTab.php"); ?>
    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link href="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">
    <!-- DataTables Responsive CSS -->
    <link href="../bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <script>
    function searchKeyPress(e)
    {
        // look for window.event in case event isn't passed in
        e = e || window.event;
        if (e.keyCode == 13)
        {
            document.getElementById('btnLogin').click();
            return false;
        }
        return true;
    }

    function showUser(str) {
      if (str=="") {
        document.getElementById("txtHint").innerHTML="";
        return;
      } 
      if (window.XMLHttpRequest) {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
      } else { // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
      }
      xmlhttp.onreadystatechange=function() {
        if (this.readyState==4 && this.status==200) {
          document.getElementById("txtHint").innerHTML=this.responseText;
        }
      }
      xmlhttp.open("POST","../include/incGetListBook.php?memberID="+str,true);
      xmlhttp.send();
    }
    </script>

</head>
     <?php
     include("../connection/config.php");
     if(isset($_SESSION['staffIDEncrypt']))
     { 
        $profileUsersData = getUsersData(mysql_real_escape_string($_GET['staffIDEncrypt']));
        ?>
        <?php if(userExists(mysql_real_escape_string($_GET['staffIDEncrypt']))){
        $staffID = $profileUsersData['staffID'];
        ?>
<body style="background-color: <?php include('../include/colorCode.php'); ?>">

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0; background-color: <?php include('../include/colorCode.php'); ?>">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php include("../include/headerTitle.php"); ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-envelope fa-fw"></i> 
                        <?php if($totalMessage > 0){ ?>
                        <span class="label label-success"><?php echo $totalMessage; ?></span>
                        <i class="fa fa-caret-down"></i>
                        <?php }else{?>
                        <i class="fa fa-caret-down"></i>
                        <?php } ?>
                    </a>
                    <ul class="dropdown-menu dropdown-messages">
                        <?php
                        if($totalMessage > 0){
                        include("../connection/config.php");
                        $displayListMessage = "CALL displayListMessage()";           
                        $myData = mysql_query($displayListMessage)or die(mysql_error());
                                    
                            while($record = mysql_fetch_array($myData)){
                            $billLogPinjamanBuku++;
                            $memberName = $record['memberName'];
                            $memberID = $record['memberID'];
                            $dateUploadTemp = $record['dateUpload'];
                            $dateUpload = date("d/m/Y h:i:s a", strtotime($dateUploadTemp));
                            echo'<li>
                                <a href="paparanBorangCopPengesahanAhli.php?memberID='.$memberID.'">
                                    <div>
                                        <strong>'.$memberID.'</strong>
                                        <span class="pull-right text-muted">
                                            <em>'.$dateUpload.'</em>
                                        </span>
                                    </div>
                                    <div>Cop Pengesahan dari '.$memberName.'...</div>
                                </a>
                            </li>
                            <li class="divider"></li>';
                            }
                            echo'<li>
                                    <a class="text-center" href="paparanKeseluruhanMessage.php">
                                        <strong>Baca Keseluruhan Mesej</strong>
                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>';
                        }else{
                            echo'<li>
                                <a href="#">
                                    <div>
                                        <strong></strong>
                                        <span class="pull-right text-muted">
                                            <em></em>
                                        </span>
                                    </div>
                                    <div><br></div>
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a class="text-center" href="paparanKeseluruhanMessage.php">
                                    <strong>Baca Keseluruhan Mesej</strong>
                                    <i class="fa fa-angle-right"></i>
                                </a>
                            </li>';
                        }
                        mysql_close($con);
                        ?>
                    </ul>
                    <!-- /.dropdown-messages -->
                </li>
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="penetapanAkaun.php"><i class="fa fa-gear fa-fw"></i> Penetapan Akaun</a>
                        </li>
                        <li class="divider"></li>
                        <?php echo '<li><a href="../function/logout.php?staffID='.$staffID.'"><i class="fa fa-sign-out fa-fw"></i> Log Keluar</a>
                        </li>'; ?>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation" style="background-color: <?php include('../include/colorCode.php'); ?>">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <?php include("../include/leftPanelDetail.php"); ?>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <?php include("../include/userMenu.php"); ?>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Ahli Senarai Hitam</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-ban fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $totalBlacklist; ?></div>
                                    <div>Jumlah Senarai Hitam Keseluruhan</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="panel panel" style="background-color: #F08080">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-female fa-5x" style="color: white"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge" style="color: white"><?php echo $totalBlacklistPerempuan; ?></div>
                                    <div style="color: white">Jumlah Senarai Hitam Ahli Wanita</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-male fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $totalBlacklistLelaki; ?></div>
                                    <div>Jumlah Senarai Hitam Ahli Lelaki</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Senarai Hitam Keseluruhan
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th width="2%">#</th>
                                            <th>Nama Ahli</th>
                                            <th>No Ahli</th>
                                            <th>Status</th>
                                            <th>Tindakan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        include("../connection/config.php");
                                        $getDisplayBlacklistMember = "CALL getDisplayBlacklistMember()";            
                                        $myData = mysql_query($getDisplayBlacklistMember)or die(mysql_error());
                                                    
                                        while($record = mysql_fetch_array($myData)){
                                        $bill++;
                                        $memberName = $record['memberName'];
                                        $memberStatus = $record['memberStatus'];
                                        $memberID = $record['memberID'];
                                        $memberStatus = $record['memberStatus'];
                                            echo'
                                            <tr>
                                                <td align="center">'.$bill.'</td>
                                                <td>'.$memberName.'</td>
                                                <td>'.$memberID.'</td>';
                                            if($memberStatus == 'SENARAI HITAM'){
                                            echo'<td><label style="color:red">SENARAI HITAM</label></td><td align="center"><button title="Paparan Butiran Tarikh" type="submit" class="btn btn-default"><a href="paparanButiranSenaraiHitam.php?memberID='.$memberID.'" style="color: black"><i class="fa fa-calendar fa-fw"></i></a></button>&nbsp;<button title="Edit Log Butiran Hitam" type="submit" class="btn btn-default"><a href="editButiranSenaraiHitam.php?memberID='.$memberID.'" style="color: black"><i class="fa fa-edit fa-fw"></i></a></button>&nbsp;<button title="Pulih Senarai Hitam" type="submit" class="btn btn-default"><a href="../function/fnAlertPulihSenaraiHitam.php?memberID='.$memberID.'" style="color: green"><i class="fa fa-check-circle-o fa-fw"></i></a></button></td>
                                            </tr>';
                                            }
                                            if($memberStatus == 'PROSES SENARAI HITAM'){
                                            echo'<td><label style="color:orange">PROSES SENARAI HITAM</label></td><td align="center"><button title="Paparan Butiran Tarikh" type="submit" class="btn btn-default"><a href="paparanButiranSenaraiHitam.php?memberID='.$memberID.'" style="color: black"><i class="fa fa-calendar fa-fw"></i></a></button>&nbsp;<button title="Edit Log Butiran Hitam" type="submit" class="btn btn-default"><a href="editButiranSenaraiHitam.php?memberID='.$memberID.'" style="color: black"><i class="fa fa-edit fa-fw"></i></a></button>&nbsp;<button title="Pulih Senarai Hitam" type="submit" class="btn btn-default"><a href="../function/fnAlertPulihSenaraiHitam.php?memberID='.$memberID.'" style="color: green"><i class="fa fa-check-circle-o fa-fw"></i></a></button></td>
                                            </tr>';
                                            }
                                        }
                                        mysql_close($con);
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
            <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-plus-circle"></i> Ahli Senarai Hitam
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <form action="" method="POST">
                                <div class="form-group">
                                    <label>No Ahli</label>
                                    <input class="form-control" onkeyup="showUser(this.value)" style="width: 120px; text-transform: uppercase;">
                                </div>
                                <div id="txtHint"></div>
                            </form>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!--.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>

</body>
</html>
<?php  } else echo '<script language = "JavaScript">alert("ID Tidak Sah!"); window.location.href="../index.php?staffIDEncrypt=$id";</script>';?>
<?php
    } 
?>