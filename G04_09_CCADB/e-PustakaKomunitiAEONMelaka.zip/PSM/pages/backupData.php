<?php 
//ignore Warnings
error_reporting(E_ALL & ~E_NOTICE & ~8192);
session_start();
date_default_timezone_set("Asia/Kuala Lumpur");
require('../function/fnUserDetail.php');
if(!isset($_GET['staffIDEncrypt']) && isset($_SESSION['staffIDEncrypt'])) header("location: ?staffIDEncrypt=".getId($_SESSION['staffIDEncrypt']));
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php include("../include/tabTitle.php"); ?></title>
    <!-- Tab icon -->
    <?php include("../include/iconTab.php"); ?>
    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <!-- DataTables CSS -->
    <link href="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">
    <!-- DataTables Responsive CSS -->
    <link href="../bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- AJAX VIEW DATA -->
    <script>
    function viewdata(){
       $.ajax({
       type: "GET",
       url: "include/viewBackupLog.php"
      }).done(function( data ) {
      $('#viewdata').html(data);
      });
    }
    $('#save').click(function(){
    
    var moDescription = $('#moDescription').val();
    var moNumber = $('#moNumber').val();
    var prpo = $('#prpo').val();
    var vendor = $('#vendor').val();
    var value = $('#value').val();
    var prpoDate = $('#prpoDate').val();
    var prpoDescription = $('#prpoDescription').val();
    var userID = $('#userID').val();
    var id = $('#id').val();
    var dateInsert = $('#dateInsert').val();
    
    var datas="&moDescription="+moDescription+"&moNumber="+moNumber+"&prpo="+prpo+"&vendor="+vendor+"&value="+value+"&prpoDate="+prpoDate+"&prpoDescription="+prpoDescription+"&userID="+userID+"&id="+id+"&dateInsert="+dateInsert;
      
    $.ajax({
       type: "POST",
       url: "function/newdata.php",
       data: datas
    }).done(function( data ) {
      $('#info').html(data);
      viewdata();
    });
    });
    </script>
</head>
     <?php 
     if(isset($_SESSION['staffIDEncrypt']))
     { 
        $profileUsersData = getUsersData(mysql_real_escape_string($_GET['staffIDEncrypt']));
        ?>
        <?php if(userExists(mysql_real_escape_string($_GET['staffIDEncrypt']))){
        $staffID = $profileUsersData['staffID'];
        ?>
<body style="background-color: <?php include('../include/colorCode.php'); ?>">

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0; background-color: <?php include('../include/colorCode.php'); ?>">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php include("../include/headerTitle.php"); ?>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="penetapanAkaun.php"><i class="fa fa-gear fa-fw"></i> Penetapan Akaun</a>
                        </li>
                        <li class="divider"></li>
                        <?php echo '<li><a href="../function/logout.php?staffID='.$staffID.'"><i class="fa fa-sign-out fa-fw"></i> Log Keluar</a>
                        </li>'; ?>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation" style="background-color: <?php include('../include/colorCode.php'); ?>">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <?php include("../include/leftPanelDetail.php"); ?>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <?php include("../include/userMenu.php"); ?>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><i>Backup</i> Keseluruhan Data</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-7">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Senarai <i>Backup</i> Keseluruhan Data Log
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div>
                            <!-- AJAX OCCUR HERE at include/viewBackupLog.php -->
                            </div>
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th width="15%">No.</th>
                                            <th>Rajah</th>
                                            <th><i>Backup</i> Tarikh | Masa</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        include("../connection/config.php");
                                        $getListOfBackupLog="CALL getListOfBackupLog()";           
                                        $myData = mysql_query($getListOfBackupLog)or die(mysql_error());
                                                    
                                        while($record = mysql_fetch_array($myData)){
                                        $bill++;
                                        $backupLogID = $record['backupLogID'];
                                        $tableBackup = $record['tableBackup'];
                                        $backupDateTimeTemp = $record['backupDateTime'];
                                        $backupDateTime = date("d/m/Y h:i:s a", strtotime($backupDateTimeTemp));
                                        echo'<tr>';
                                        echo'
                                            <td align="center">'.$bill.'</td>
                                            <td>'.$tableBackup.'</td>
                                            <td>'.$backupDateTime.'</td>';
                                        echo'</tr>';
                                        }
                                        mysql_close($con);
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-7 -->
                <div class="col-lg-5">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Senarai Rajah
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div>
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th>Nama Rajah</th>
                                            <th>Backup</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        include("../connection/config.php");
                                        $getListOfDBTable="CALL getListOfDBTable()";           
                                        $myData = mysql_query($getListOfDBTable)or die(mysql_error());
                                                    
                                        while($record = mysql_fetch_array($myData)){
                                        $billTable++;
                                        $tableName = $record['TABLE_NAME'];
                                        $quote= "'";
                                        echo'
                                        <tr>
                                            <td align="center">'.$billTable.'</td>
                                            <td>'.$tableName.'</td>
                                            <td><button title="Muat Turun Excel" name="btnExcell" type="submit" class="btn btn-default" onclick="window.location.href='.$quote.'../function/fnBackupDataExcell.php?tableName='.$tableName.''.$quote.'"><i class="fa fa-file-excel-o"></i></button>
                                            </td>
                                        </tr>
                                        ';
                                        }
                                        mysql_close($con);
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-5 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>

</body>
</html>
<?php  } else echo '<script language = "JavaScript">alert("ID Tidak Sah!"); window.location.href="../index.php?staffIDEncrypt=$id";</script>';?>
<?php
    } 
?>