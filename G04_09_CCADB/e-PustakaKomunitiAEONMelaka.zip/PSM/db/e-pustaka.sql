-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2017 at 05:48 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `psm`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `checkBlacklistExist`(IN vMemberID varchar(5))
BEGIN 
SELECT * FROM blacklist WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `checkExistOrNotMemberBlacklist`(IN vMemberID varchar(5))
BEGIN 
SELECT * FROM blacklist WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `displayListMessage`()
BEGIN 
	SELECT member.*, form.*
	FROM member
	INNER JOIN form
	ON member.memberID = form.memberID WHERE
    form.formStatus='HANTAR COP PENGESAHAN'
	ORDER BY form.dateUpload DESC;
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnDaftarNotisSekolah`(IN vMemberID varchar(5), IN vNoticeDate date)
BEGIN 
INSERT INTO blacklist(memberID, noticeDate) VALUES(vMemberID, vNoticeDate);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnDeleteBranch`(IN vBranchID int(11))
BEGIN 
DELETE FROM staff WHERE branchID=vBranchID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnDeleteInventoriBuku`(IN vBookID int(11))
BEGIN 
UPDATE book SET bookStatus='TIADA' WHERE bookID=vBookID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnDeleteMember`(IN vMemberID varchar(5))
BEGIN 
DELETE FROM member WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnDeleteStaff`(IN vStaffID varchar(9))
BEGIN 
DELETE FROM staff WHERE staffID=vStaffID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnEditButiranBuku`(IN vBookTitle varchar(50), IN vTypeBookID int(11), 
IN vAuthor varchar(50), IN vPlaceOfIssue varchar(50), IN vPublisher varchar(50),
IN vYearsOfIssue int(11), IN vNoOfAcquisition varchar(30), IN vDateOfAcquisition date,
IN vBookPrice double, IN vBookLanguageID int(11), IN vBookID int(11))
BEGIN 
UPDATE book SET bookTitle=vBookTitle, typeBookID=vTypeBookID,
author=vAuthor, placeOfIssue=vPlaceOfIssue, publisher=vPublisher,
yearsOfIssue=vYearsOfIssue, noOfAcquisition=vNoOfAcquisition,
dateOfAcquisition=vDateOfAcquisition, bookPrice=vBookPrice,
bookLanguageID=vBookLanguageID WHERE bookID=vBookID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnEditCawangan`(IN vBranchID int(11), IN vBranchName varchar(50))
BEGIN 
UPDATE branch SET branchName=vBranchName WHERE branchID=vBranchID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnEditLogButiranHitam`(IN vInfoBlastDate1 date, 
IN vInfoBlastDate2 date, IN vInfoBlastDate3 date, 
IN vWarningDate date, IN vMemberID varchar(5))
BEGIN 
UPDATE blacklist SET infoBlastDate1=vInfoBlastDate1, 
infoBlastDate2=vInfoBlastDate2, infoBlastDate3=vInfoBlastDate3,
warningDate=vWarningDate WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnEditLogButiranHitamKanak`(IN  vNoticeDate date, 
IN vSignBoardDate date, IN vWarningDate date,
IN vMemberID varchar(5))
BEGIN 
UPDATE blacklist SET noticeDate=vNoticeDate, signBoardDate=vSignBoardDate,
warningDate=vWarningDate WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnExcellBorrowerByCategory`(IN vYear int(11))
BEGIN 
select * from borrow_statistic WHERE 
year=vYear ORDER BY monthNum ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnExcellBorrowerByGender`(IN vYear int(11))
BEGIN 
select * from borrow_statistic WHERE 
year=vYear ORDER BY monthNum ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnExcellBorrowerByRace`(IN vYear int(11))
BEGIN 
select * from borrow_statistic WHERE 
year=vYear ORDER BY monthNum ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnExcellMemberByCategory`(IN vYear int(11))
BEGIN 
select * from member_statistic WHERE
year=vYear ORDER BY monthNum ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnExcellMemberByGender`(IN vYear int(11))
BEGIN 
select * from member_statistic 
WHERE year=vYear ORDER BY monthNum ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnExcellMemberByRace`(IN vYear int(11))
BEGIN 
select * from member_statistic WHERE year=vYear
ORDER BY monthNum ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnExcellVisitorByCategory`(IN vYear int(11))
BEGIN 
select * from attendance_statistic WHERE 
year=vYear ORDER BY monthNum ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnExcellVisitorByGender`(IN vYear int(11))
BEGIN 
select * from attendance_statistic WHERE
year=vYear ORDER BY monthNum ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnExcellVisitorByRace`(IN vYear int(11))
BEGIN 
select * from attendance_statistic 
WHERE year=vYear ORDER BY monthNum ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnGetListBarcode`(IN vBookISBN varchar(20))
BEGIN 
SELECT * FROM BOOK WHERE bookISBN LIKE CONCAT('%',vBookISBN,'%')
ORDER BY bookID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnGetListSearchBook`(IN vBookTitle varchar(50))
BEGIN 
SELECT * FROM BOOK WHERE bookTitle LIKE CONCAT('%',vBookTitle,'%')
ORDER BY bookID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnInsertInfoBlast1Belia`(IN vMemberID varchar(5), IN vInfoBlastDateBelia date)
BEGIN 
INSERT INTO blacklist(memberID, infoBlastDate1) VALUES(vMemberID, vInfoBlastDateBelia);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnInsertInfoBlast1Dewasa`(IN vMemberID varchar(5), IN vInfoBlastDateDewasa date)
BEGIN 
INSERT INTO blacklist(memberID, infoBlastDate1) 
VALUES(vMemberID, vInfoBlastDateDewasa);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnInsertNotisSekolahKanak`(IN vMemberID varchar(5), IN vNoticeDate date)
BEGIN 
INSERT INTO blacklist(memberID, noticeDate) 
VALUES(vMemberID, vNoticeDate);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnLogoutMember`(IN vMemberID varchar(5))
BEGIN 
UPDATE audit_log SET logOutDate=NOW() 
WHERE staffID=vMemberID ORDER BY auditLogID DESC LIMIT 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnLogoutStaff`(IN vStaffID varchar(9))
BEGIN 
UPDATE audit_log SET logOutDate=NOW() 
WHERE staffID=vStaffID ORDER BY auditLogID DESC LIMIT 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnPerbaharuiMember`(IN vMemberID varchar(5))
BEGIN 
UPDATE member SET memberStatus='SAH' WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnPulihSenaraiHitam`(IN vMemberID varchar(5))
BEGIN 
DELETE FROM blacklist WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnRegisterStaff`(IN vStaffID varchar(9), IN vStaffIDEncrypt varchar(50),
IN vStaffName varchar(50), IN vStaffContact varchar(12), IN vStaffEmail varchar(50),
IN vStaffPosition varchar(50), IN vStaffPassword varchar(50), IN vStaffRowLevel int(11),
IN vBranchID int(11))
BEGIN 
INSERT INTO staff VALUES (vStaffID, vStaffIDEncrypt, vStaffName, vStaffContact,
vStaffEmail, vStaffPosition, vStaffPassword, vStaffRowLevel, vBranchID, '');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnResetKataLaluanMember`(IN vMemberID varchar(5), IN vNewPasswordEncrypt varchar(50))
BEGIN 
UPDATE member SET memberPassword=vNewPasswordEncrypt 
WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnUpdateAkaunStaff`(IN vStaffName varchar(50), IN vStaffEmail varchar(50),
IN vStaffContact varchar(12), IN vStaffID varchar(9))
BEGIN 
UPDATE staff SET staffName=vStaffName, staffEmail=vStaffEmail,
staffContact=vStaffContact WHERE staffID=vStaffID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnUpdateBookStatusTiada`(IN vBookID int(11))
BEGIN 
UPDATE book SET bookStatus='TIADA' WHERE bookID=vBookID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnUpdateContact`(IN vContactFatherH varchar(13), IN vContactFatherO varchar(13),
IN vContactFatherM varchar(13), IN vContactMotherH varchar(13), IN vContactMotherO varchar(13),
IN vContactMotherM varchar(13), IN vContactSelfH varchar(13), IN vContactSelfO varchar(13),
IN vContactSelfM varchar(13), IN vContactID int(11))
BEGIN 
UPDATE contact SET contactFatherH=vContactFatherH, 
contactFatherO=vContactFatherO, contactFatherM=vContactFatherM,
contactMotherH=vContactMotherH, contactMotherO=vContactMotherO,
contactMotherM=vContactMotherM, contactSelfH=vContactSelfH,
contactSelfO=vContactSelfO, contactSelfM=vContactSelfM
 WHERE contactID=vContactID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnUpdateCopPengesahanMemberSah`(IN vFormComment varchar(50), 
IN vMemberID varchar(5))
BEGIN 
UPDATE form SET formStatus='SAH', formComment=vFormComment 
WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnUpdateCopPengesahanMemberTidakSah`(IN vFormComment varchar(50), 
IN vMemberID varchar(5))
BEGIN 
UPDATE form SET formStatus='TIDAK SAH', 
formComment=vFormComment WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnUpdateEmail`(IN vEmailFather varchar(50), IN vEmailMother varchar(50),
IN vEmailSelf varchar(50), IN vEmailID int(11))
BEGIN 
UPDATE email SET emailFather=vEmailFather, emailMother=vEmailMother, 
emailSelf=vEmailSelf WHERE emailID=vEmailID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnUpdateGambarPengguna`(IN vImageData blob, 
IN vStaffID varchar(9))
BEGIN 
UPDATE staff SET staffImg=vImageData WHERE staffID=vStaffID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnUpdateMember`(IN vMemberName varchar(100), IN vMemberBOD varchar(10),
IN vMemberGender varchar(10), IN vMemberRace varchar(10), IN vMemberAddress text, IN
vMemberType varchar(20), IN vMemberStatus varchar(20), IN vMemberID varchar(5))
BEGIN 
UPDATE member SET memberName=vMemberName, memberBOD=vMemberBOD,
memberGender=vMemberGender, memberRace=vMemberRace, memberAddress=vMemberAddress,
memberType=vMemberType, memberStatus=vMemberStatus WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnUpdatePenetapanKataLaluanMember`(IN vNewPasswordEncrypt varchar(50), IN vMemberID varchar(5))
BEGIN 
UPDATE member SET memberPassword=vNewPasswordEncrypt 
WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnUpdatePenetapanKataLaluanStaff`(IN vNewPasswordEncrypt varchar(50), IN vStaffID varchar(9))
BEGIN 
UPDATE staff SET staffPassword=vNewPasswordEncrypt 
WHERE staffID=vStaffID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnUpdateStatusMemberDalamProses`(IN vMemberID varchar(5))
BEGIN 
UPDATE member SET memberStatus='DALAM PROSES'
WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnUpdateStatusMemberSah`(IN vMemberID varchar(5))
BEGIN 
UPDATE member SET memberStatus='SAH' 
WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `fnUploadCopPengesahan`(IN vMemberID varchar(5), IN vImageData blob)
BEGIN 
UPDATE form SET formContent=vImageData, dateUpload=NOW(),
formStatus='HANTAR COP PENGESAHAN' WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getAttendanceAdultToday`()
BEGIN 
SELECT SUM(attendanceTotal) AS totalAttendanceAdultToday FROM
attendance WHERE attendanceDate=CURDATE() AND attendanceCategory='Dewasa';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getAttendanceFemaleToday`()
BEGIN 
SELECT SUM(attendanceTotal) AS totalAttendanceFemaleToday FROM
attendance WHERE attendanceDate=CURDATE() AND
attendanceGender='Perempuan';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getAttendanceKidToday`()
BEGIN 
SELECT SUM(attendanceTotal) AS totalAttendanceKidToday FROM
attendance WHERE attendanceDate=CURDATE() AND
attendanceCategory='Kanak-Kanak';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getAttendanceMaleToday`()
BEGIN 
SELECT SUM(attendanceTotal) AS totalAttendanceMaleToday FROM 
attendance WHERE attendanceDate=CURDATE() AND attendanceGender='Lelaki';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getAttendanceToday`()
BEGIN 
SELECT SUM(attendanceTotal) AS totalAttendanceToday FROM
attendance WHERE attendanceDate=CURDATE();
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getAttendanceYouthToday`()
BEGIN 
SELECT SUM(attendanceTotal) AS totalAttendanceYouthToday FROM attendance
WHERE attendanceDate=CURDATE() AND attendanceCategory='Belia';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getAvailableStaffIDAM`()
BEGIN 
SELECT COUNT(branchID) AS availableStaffIDAM FROM 
staff WHERE branchID='1' AND staffPosition !='Admin';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getAvailableStaffIDMM`()
BEGIN 
SELECT COUNT(branchID) AS availableStaffIDMM FROM 
staff WHERE branchID='2' AND staffPosition !='Admin';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getBookLanguage`()
BEGIN 
SELECT * FROM book_language ORDER BY bookLanguageID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getBorrowBookDetail`(IN vBorrowID int(11))
BEGIN 
SELECT * FROM borrow WHERE borrowID=vBorrowID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getContactID`()
BEGIN 
SELECT MAX(contactID) AS contactID FROM contact;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAprBorrowCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE month='Apr'
AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAprBorrowGender`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Apr' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAprBorrowRace`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Apr' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAprMemberCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Apr' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAprMemberGender`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Apr' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAprMemberRace`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Apr' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAprVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Apr' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAprVisitorGender`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Apr' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAprVisitorRace`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Apr' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAttendance`(IN vAttendanceID int(11))
BEGIN 
SELECT * FROM attendance WHERE attendanceID=vAttendanceID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAugBorrowCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE month='Aug' 
AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAugBorrowGender`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Aug' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAugBorrowRace`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Aug' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAugMemberCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Aug' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAugMemberGender`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Aug' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAugMemberRace`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Aug' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAugVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Aug' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAugVisitorGender`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Aug' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailAugVisitorRace`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Aug' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailBook`(IN vBookID int(11))
BEGIN 
SELECT * FROM book WHERE bookID=vBookID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailBookBlacklist`(IN vMemberID varchar(5))
BEGIN 
SELECT * FROM borrow WHERE memberID=vMemberID
AND borrowStatus='DALAM PINJAMAN';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailBookLanguage`(IN vBookLanguageID int(11))
BEGIN 
SELECT * FROM book_language WHERE bookLanguageID=vBookLanguageID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailBookType`(IN vTypeBookID int(11))
BEGIN 
SELECT * FROM type_book WHERE typeBookID=vTypeBookID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailBranch`(IN vBranchID int(11))
BEGIN 
SELECT branchID, branchName FROM branch WHERE branchID=vBranchID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailContact`(IN vContactID int(11))
SELECT * FROM contact WHERE contactID=vContactID$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailDecBorrowCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE month='Dec' 
AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailDecBorrowGender`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Dec' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailDecBorrowRace`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Dec' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailDecMemberCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Dec' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailDecMemberGender`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Dec' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailDecMemberRace`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Dec' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailDecVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Dec' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailDecVisitorGender`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Dec' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailDecVisitorRace`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Dec' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailEmail`(IN vEmailID int(11))
SELECT * FROM email WHERE emailID=vEmailID$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailFebBorrowCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE month='Feb'
AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailFebBorrowGender`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE
month='Feb' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailFebBorrowRace`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Feb' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailFebMemberCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Feb' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailFebMemberGender`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Feb' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailFebMemberRace`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Feb' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailFebVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Feb' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailFebVisitorGender`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Feb' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailFebVisitorRace`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Feb' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailFormMember`(IN vMemberID varchar(5))
BEGIN 
SELECT * FROM form WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJanBorrowCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE month='Jan'
AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJanBorrowGender`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE month='Jan'
AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJanBorrowRace`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Jan' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJanMemberCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Jan' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJanMemberGender`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Jan' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJanMemberRace`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Jan' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJanVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Jan' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJanVisitorGender`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Jan' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJanVisitorRace`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Jan' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJulBorrowCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE month='Jul'
AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJulBorrowGender`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Jul' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJulBorrowRace`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Jul' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJulMemberCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Jul' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJulMemberGender`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Jul' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJulMemberRace`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Jul' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJulVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Jul' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJulVisitorGender`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Jul' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJulVisitorRace`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Jul' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJunBorrowCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE month='Jun'
AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJunBorrowGender`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Jun' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJunBorrowRace`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Jun' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJunMemberCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Jun' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJunMemberGender`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE
month='Jun' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJunMemberRace`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Jun' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJunVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Jun' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJunVisitorGender`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Jun' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailJunVisitorRace`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Jun' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMarBorrowCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE month='Mar'
AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMarBorrowGender`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Mar' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMarBorrowRace`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Mar' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMarMemberCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Mar' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMarMemberGender`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Mar' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMarMemberRace`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Mar' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMarVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Mar' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMarVisitorGender`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Mar' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMarVisitorRace`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Mar' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMayBorrowCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE month='May' 
AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMayBorrowGender`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='May' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMayBorrowRace`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='May' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMayMemberCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='May' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMayMemberGender`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='May' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMayMemberRace`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='May' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMayVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='May' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMayVisitorGender`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='May' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMayVisitorRace`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='May' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMember`(IN vMemberID varchar(5))
SELECT * FROM member WHERE memberID=vMemberID$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailMemberRegister`(IN vMemberID varchar(5))
BEGIN 
SELECT * FROM member_date_register WHERE memberID=vMemberID
ORDER BY memberDateRegisterID DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailNovBorrowCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE month='Nov' 
AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailNovBorrowGender`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Nov' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailNovBorrowRace`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Nov' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailNovMemberCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Nov' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailNovMemberGender`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Nov' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailNovMemberRace`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Nov' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailNovVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Nov' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailNovVisitorGender`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Nov' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailNovVisitorRace`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Nov' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailOctBorrowCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE month='Oct' 
AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailOctBorrowGender`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Oct' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailOctBorrowRace`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Oct' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailOctMemberCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Oct' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailOctMemberGender`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Oct' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailOctMemberRace`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Oct' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailOctVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Oct' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailOctVisitorGender`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Oct' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailOctVisitorRace`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Oct' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailSepBorrowCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE month='Sep' 
AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailSepBorrowGender`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Sep' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailSepBorrowRace`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE 
month='Sep' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailSepMemberCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Sep' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailSepMemberGender`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Sep' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailSepMemberRace`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
month='Sep' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailSepVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Sep' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailSepVisitorGender`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Sep' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailSepVisitorRace`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic WHERE 
month='Sep' AND year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailStaff`(IN vStaffID varchar(9))
BEGIN 
SELECT * FROM staff WHERE staffID=vStaffID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailTotalWarning`(IN vMemberID varchar(5))
BEGIN 
SELECT blacklist.*, total_warning.* FROM blacklist INNER JOIN
total_warning ON total_warning.memberID = blacklist.memberID
WHERE blacklist.memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDisplayBlacklistMember`()
BEGIN 
SELECT * FROM member WHERE memberStatus='SENARAI HITAM'
OR memberStatus='PROSES SENARAI HITAM';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDisplayBranch`()
BEGIN 
SELECT branchID, branchName FROM branch ORDER BY branchID DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getEmailID`()
BEGIN 
SELECT MAX(emailID) AS emailID FROM email;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellBackupAttendance`()
BEGIN 
select * from attendance ORDER BY attendanceID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellBackupAttendanceStatistic`()
BEGIN 
select * from attendance_statistic ORDER BY attendanceStatisticID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellBackupAuditLog`()
BEGIN 
select * from audit_log ORDER BY auditLogID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellBackupBackupLog`()
BEGIN 
select * from backup_log ORDER BY backupLogID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellBlacklistBackupLog`()
BEGIN 
select * from blacklist ORDER BY blacklistID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellBookBackupLog`()
BEGIN 
select * from book ORDER BY bookID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellBookLanguageBackupLog`()
BEGIN 
select * from book_language ORDER BY bookLanguageID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellBorrowBackupLog`()
BEGIN 
select * from borrow ORDER BY borrowID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellBorrowerGender`(IN vYear int(11))
BEGIN 
select * from borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellBorrowRace`(IN vYear int(11))
BEGIN 
select * from borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellBorrowStatisticBackupLog`()
BEGIN 
select * from borrow_statistic ORDER BY borrowStatisticID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellBorrowStatisticCategory`(IN vYear int(11))
BEGIN 
select * from borrow_statistic 
WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellBranchBackupLog`()
BEGIN 
select * from branch ORDER BY branchID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellContactBackupLog`()
BEGIN 
select * from contact ORDER BY contactID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellEmailBackupLog`()
BEGIN 
select * from email ORDER BY emailID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellFormBackupLog`()
BEGIN 
select formID, memberID, dateUpload, formStatus, formComment 
FROM form ORDER BY formID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellMemberBackupLog`()
BEGIN 
select * from member ORDER BY memberID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellMemberCategory`(IN vYear int(11))
BEGIN 
select * from member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellMemberDateRegisterBackupLog`()
BEGIN 
select * from member_date_register ORDER BY memberDateRegisterID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellMemberGender`(IN vYear int(11))
BEGIN 
select * from member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellMemberRace`(IN vYear int(11))
BEGIN 
select * from member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellMemberStatisticBackupLog`()
BEGIN 
select * from member_statistic ORDER BY memberStatisticID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellRecoveryLogBackupLog`()
BEGIN 
select * from recovery_log ORDER BY recoveryLogID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellStaffBackupLog`()
BEGIN 
select * from staff ORDER BY staffID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellStatisticYearBackupLog`()
BEGIN 
select * from statistic_year ORDER BY statisticYearID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellTotalWarningBackupLog`()
BEGIN 
select * from total_warning ORDER BY totalWarningID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellTypeBookBackupLog`()
BEGIN 
select * from type_book ORDER BY typeBookID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellVisitorCategory`(IN vYear int(11))
BEGIN 
select * from attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellVisitorGender`(IN vYear int(11))
BEGIN 
select * from attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getExcellVisitorRace`(IN vYear int(11))
BEGIN 
select * from attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getJumlahAhli`()
BEGIN 
SELECT COUNT(memberID) AS totalMember FROM member;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getJumlahAhliLelaki`()
BEGIN 
SELECT COUNT(memberID) AS totalMemberMale FROM
member WHERE memberGender='LELAKI';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getJumlahAhliWanita`()
BEGIN 
SELECT COUNT(memberID) AS totalMemberFemale FROM
member WHERE memberGender='PEREMPUAN';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getJumlahCawangan`()
BEGIN 
SELECT COUNT(branchID) AS totalBranch FROM branch;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getJumlahPenggunaSistemKesuluruhan`()
BEGIN 
SELECT COUNT(staffID) AS totalUserSistem FROM staff;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListAuditLog`()
BEGIN 
SELECT * FROM audit_log ORDER BY auditLogID DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListLogPengesahan`()
BEGIN 
SELECT member.*, form.*
FROM member
INNER JOIN form
ON member.memberID = form.memberID WHERE form.formStatus='HANTAR COP PENGESAHAN'
ORDER BY form.dateUpload DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListLogPinjamanBukuMember`(IN vMemberID varchar(5))
BEGIN 
SELECT * FROM borrow, book, member WHERE borrow.memberID=member.memberID
AND borrow.bookID=book.bookID AND member.memberID=vMemberID ORDER BY
borrow.borrowID DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListNameBranchStaff`(IN vBranchID int(11))
BEGIN 
SELECT branch.*, staff.staffName, staff.staffID, staff.branchID, 
staff.staffContact FROM branch INNER JOIN staff ON 
branch.branchID=staff.branchID WHERE staff.branchID=vBranchID
ORDER BY staff.staffID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListOfBackupLog`()
BEGIN 
SELECT * FROM backup_log WHERE descriptionBackup='BACKUP DATA'
ORDER BY backupLogID DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListOfBackupLogStructureDB`()
BEGIN 
SELECT * FROM backup_log WHERE 
descriptionBackup='BACKUP PANGKALAN DATA' ORDER BY backupLogID DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListOfBook`()
BEGIN 
SELECT * FROM BOOK ORDER BY bookTitle ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListOfDBTable`()
BEGIN 
SELECT TABLE_NAME FROM information_schema.TABLES WHERE
TABLE_SCHEMA=DATABASE();
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListOfMember`()
BEGIN 
SELECT * FROM member;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListOfPenggunaSistem`()
BEGIN 
SELECT staffName, staffID FROM staff;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListOfSenaraiPinjaman`()
BEGIN 
SELECT DISTINCT member.memberID, member.memberName 
FROM member INNER JOIN borrow ON member.memberID = borrow.memberID
WHERE borrow.borrowStatus='DALAM PINJAMAN' OR borrow.borrowStatus='LAMBAT PULANG'
 ORDER BY borrow.borrowID DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListOptionBranch`()
BEGIN 
SELECT * FROM branch ORDER BY branchID ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListPengunjungEdit`()
BEGIN 
SELECT * FROM attendance ORDER BY attendanceDate DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListRecoveryLog`()
BEGIN 
SELECT * FROM recovery_log ORDER BY recoveryLogID DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListStatusPinjaman`(IN vBookID int(11))
BEGIN 
SELECT * FROM borrow WHERE bookID=vBookID AND
borrowStatus='DALAM PINJAMAN' OR borrowStatus='TIDAK DIPULANGKAN' 
OR borrowStatus='LAMBAT PULANG' ORDER BY borrowID DESC LIMIT 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getListTableOfPemulihanData`()
BEGIN 
SELECT TABLE_NAME FROM information_schema.TABLES WHERE 
TABLE_SCHEMA=DATABASE() AND TABLE_NAME!='staff' 
AND TABLE_NAME != 'recovery_log';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getLogPembaharuanAhli`(IN vMemberID varchar(5))
BEGIN 
SELECT * FROM member_date_register WHERE memberID=vMemberID
ORDER BY memberDateRegisterID DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getLogPinjamanBuku`(IN vMemberID varchar(5))
BEGIN 
SELECT * FROM borrow, book, member WHERE
borrow.memberID=member.memberID AND borrow.bookID=book.bookID
AND member.memberID=vMemberID ORDER BY borrow.borrowID DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMemberData`(IN vMemberIDEncrypt varchar(50))
BEGIN 
SELECT * FROM member WHERE memberIDEncrypt=vMemberIDEncrypt;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMemberID`(IN vMemberIDEncrypt varchar(50))
BEGIN 
SELECT memberIDEncrypt FROM member WHERE memberIDEncrypt=vMemberIDEncrypt;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMemberIDBelia`()
BEGIN 
SELECT COUNT(memberID) AS memberIDYouth FROM member WHERE memberID LIKE '%B%';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMemberIDDewasa`()
BEGIN 
SELECT COUNT(memberID) AS memberIDAdult FROM member WHERE memberID LIKE '%D%';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getMemberIDKanak`()
BEGIN 
SELECT COUNT(memberID) AS memberIDKid FROM member WHERE memberID LIKE '%K%'; 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOptionStatisticYear`()
BEGIN 
SELECT * FROM statistic_year;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallAdultBorrowerByCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(adult) AS totalOverallAdult FROM borrow_statistic
 WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallAdultMemberCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(adult) AS totalOverallAdult 
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallAdultVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(adult) AS totalOverallAdult 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallCinaMemberRace`(IN vYear int(11))
BEGIN 
SELECT SUM(raceCina) AS totalOverallRaceCina 
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallFemaleBorrowerGender`(IN vYear int(11))
BEGIN 
SELECT SUM(totalFemale) AS totalOverallFemale 
FROM borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallFemaleMemberGender`(IN vYear int(11))
BEGIN 
SELECT SUM(totalFemale) AS totalOverallFemale 
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallFemaleVisitorGender`(IN vYear int(11))
BEGIN 
SELECT SUM(totalFemale) AS totalOverallFemale 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallIndiaMemberRace`(IN vYear int(11))
BEGIN 
SELECT SUM(raceIndia) AS totalOverallRaceIndia 
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallKidBorrowerCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(kid) AS totalOverallKid 
FROM borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallKidMemberCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(kid) AS totalOverallKid 
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallKidVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(kid) AS totalOverallKid 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallMaleBorrowerGender`(IN vYear int(11))
BEGIN 
SELECT SUM(totalMale) AS totalOverallMale 
FROM borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallMaleMemberGender`(IN vYear int(11))
BEGIN 
SELECT SUM(totalMale) AS totalOverallMale FROM 
member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallMaleVisitorGender`(IN vYear int(11))
BEGIN 
SELECT SUM(totalMale) AS totalOverallMale 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallMelayuMemberRace`(IN vYear int(11))
BEGIN 
SELECT SUM(raceMelayu) AS totalOverallRaceMelayu 
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallOtherMemberRace`(IN vYear int(11))
BEGIN 
SELECT SUM(raceOther) AS totalOverallRaceOther 
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallRaceCinaBorrow`(IN vYear int(11))
BEGIN 
SELECT SUM(raceCina) AS totalOverallRaceCina 
FROM borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallRaceCinaVisitorRace`(IN vYear int(11))
BEGIN 
SELECT SUM(raceCina) AS totalOverallRaceCina 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallRaceIndiaBorrow`(IN vYear int(11))
BEGIN 
SELECT SUM(raceIndia) AS totalOverallRaceIndia 
FROM borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallRaceIndiaVisitorRace`(IN vYear int(11))
BEGIN 
SELECT SUM(raceIndia) AS totalOverallRaceIndia 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallRaceMelayuBorrow`(IN vYear int(11))
BEGIN 
SELECT SUM(raceMelayu) AS totalOverallRaceMelayu 
FROM borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallRaceMelayuVisitorRace`(IN vYear int(11))
BEGIN 
SELECT SUM(raceMelayu) AS totalOverallRaceMelayu 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallRaceOtherBorrow`(IN vYear int(11))
BEGIN 
SELECT SUM(raceOther) AS totalOverallRaceOther 
FROM borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallRaceOtherVisitorRace`(IN vYear int(11))
BEGIN 
SELECT SUM(raceOther) AS totalOverallRaceOther 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallYouthBorrowerCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(youth) AS totalOverallYouth 
FROM borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallYouthMemberCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(youth) AS totalOverallYouth 
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOverallYouthVisitorCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(youth) AS totalOverallYouth 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalAdultBorrowByCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(adult) AS totalAdult FROM
borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalAdultMemberByCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(adult) AS totalOverallAdult FROM
member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalAdultVisitorByCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(adult) AS totalAdult FROM 
attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalBlacklistAll`()
BEGIN 
	SELECT COUNT(blacklistID) AS totalBlacklist FROM blacklist;
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalBlacklistLelaki`()
BEGIN 
SELECT COUNT(*) AS totalBlacklistLelaki FROM blacklist, member 
WHERE blacklist.memberID=member.memberID AND 
member.memberGender='LELAKI';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalBlacklistPerempuan`()
BEGIN 
SELECT COUNT(*) AS totalBlacklistPerempuan FROM blacklist, member
WHERE blacklist.memberID=member.memberID AND 
member.memberGender='PEREMPUAN';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalBookAvailable`()
BEGIN 
SELECT COUNT(bookStatus) AS totalBookAvailable FROM
book WHERE bookStatus='ADA';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalBorrowerDaily`()
BEGIN 
SELECT COUNT(*) AS totalBorrowerDaily FROM borrow WHERE
borrowDate=CURRENT_DATE();
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalDailyBorrower`()
BEGIN 
SELECT COUNT(borrowID) AS totalDailyBorrower FROM borrow
WHERE borrowDate=CURRENT_DATE() AND 
borrowStatus='DALAM PINJAMAN';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalFemaleBorrowByGender`(IN vYear int(11))
BEGIN 
select SUM(totalFemale) AS totalOverallFemale 
FROM borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalFemaleMemberByGender`(IN vYear int(11))
BEGIN 
select SUM(totalFemale) AS totalOverallFemale 
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalFemaleVisitorByGender`(IN vYear int(11))
BEGIN 
select SUM(totalFemale) AS totalOverallFemale 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalKidBorrowByCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(kid) AS totalKid FROM 
borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalKidMemberByCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(kid) AS totalKid 
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalKidVisitorByCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(kid) AS totalKid FROM 
attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalMaleBorrowByGender`(IN vYear int(11))
BEGIN 
select SUM(totalMale) AS totalOverallMale 
FROM borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalMaleMemberByGender`(IN vYear int(11))
BEGIN 
select SUM(totalMale) AS totalOverallMale 
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalMaleVisitorByGender`(IN vYear int(11))
BEGIN 
select SUM(totalMale) AS totalOverallMale 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalMemberOverall`()
BEGIN 
SELECT COUNT(member.memberID) AS totalMemberDaily FROM
member, member_date_register WHERE
member.memberID=member_date_register.memberID AND
memberDateRegister = CURRENT_DATE();
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalMessage`()
BEGIN 
SELECT COUNT(*) AS totalMessage FROM form WHERE formStatus='HANTAR COP PENGESAHAN';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalOverallAttendaceFemaleVisitor`()
BEGIN 
SELECT COUNT(attendanceID) AS totalAttendVisitorFemale
FROM attendance WHERE attendanceGender='Perempuan';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalOverallAttendaceMaleVisitor`()
BEGIN 
SELECT COUNT(memberID) AS totalOverallMemberMale
FROM member WHERE memberGender='LELAKI';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalOverallAttendaceVisitor`()
BEGIN 
SELECT COUNT(attendanceID) AS totalAttendVisitor 
FROM attendance;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalOverallAttendanceMaleVisitor`()
BEGIN 
SELECT COUNT(attendanceID) AS totalAttendVisitorMale
FROM attendance WHERE attendanceGender='Lelaki';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalOverallBorrower`()
BEGIN 
SELECT COUNT(borrowID) AS totalBorrowerOveral FROM borrow
WHERE borrowStatus='DALAM PINJAMAN' OR borrowStatus='PULANG'
OR borrowStatus='TIDAK DIPULANGKAN';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalOverallMember`()
BEGIN 
SELECT COUNT(memberID) AS totalOverallMember FROM member;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalOverallMemberFemale`()
BEGIN 
SELECT COUNT(memberID) AS totalOverallMemberFemale 
FROM member WHERE memberGender='PEREMPUAN';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalRaceCinaBorrowByRace`(IN vYear int(11))
BEGIN 
select SUM(raceCina) AS totalRaceCina 
FROM borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalRaceCinaMemberByRace`(IN vYear int(11))
BEGIN 
select SUM(raceCina) AS totalRaceCina
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalRaceCinaVisitorByRace`(IN vYear int(11))
BEGIN 
select SUM(raceCina) AS totalRaceCina 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalRaceIndiaBorrowByRace`(IN vYear int(11))
BEGIN 
select SUM(raceIndia) AS totalRaceIndia 
FROM borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalRaceIndiaMemberByRace`(IN vYear int(11))
BEGIN 
select SUM(raceIndia) AS totalRaceIndia
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalRaceIndiaVisitorByRace`(IN vYear int(11))
BEGIN 
select SUM(raceIndia) AS totalRaceIndia 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalRaceMelayuBorrowByRace`(IN vYear int(11))
BEGIN 
select SUM(raceMelayu) AS totalRaceMelayu 
FROM borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalRaceMelayuMemberByRace`(IN vYear int(11))
BEGIN 
select SUM(raceMelayu) AS totalRaceMelayu 
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalRaceMelayuVisitorByRace`(IN vYear int(11))
BEGIN 
select SUM(raceMelayu) AS totalRaceMelayu 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalRaceOtherBorrowByRace`(IN vYear int(11))
BEGIN 
select SUM(raceOther) AS totalRaceOther 
FROM borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalRaceOtherMemberByRace`(IN vYear int(11))
BEGIN 
select SUM(raceOther) AS totalRaceOther 
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalRaceOtherVisitorByRace`(IN vYear int(11))
BEGIN 
select SUM(raceOther) AS totalRaceOther 
FROM attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalReturn`()
BEGIN 
SELECT COUNT(borrowID) AS totalReturn FROM
borrow WHERE borrowStatus='PULANG';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotaltotalBookInBorrow`()
BEGIN 
SELECT COUNT(bookStatus) AS totalBookInBorrow FROM
book WHERE bookStatus='DALAM PINJAMAN';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotaltotalBookNotReturn`()
BEGIN 
SELECT COUNT(bookStatus) AS totalBookNotReturn FROM book WHERE
bookStatus='TIDAK DIKEMBALIKAN';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalVisitorDaily`()
BEGIN 
SELECT COUNT(*) AS totalVisitorDaily FROM attendance WHERE
attendanceDate=CURRENT_DATE();
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalYouthBorrowByCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(youth) AS totalYouth FROM 
borrow_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalYouthMemberByCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(youth) AS totalYouth 
FROM member_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTotalYouthVisitorByCategory`(IN vYear int(11))
BEGIN 
SELECT SUM(youth) AS totalYouth FROM 
attendance_statistic WHERE year=vYear;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `incGetListBook`(IN vMemberID varchar(5))
BEGIN 
SELECT book.*, borrow.* FROM book INNER JOIN borrow ON
book.bookID = borrow.bookID WHERE borrow.borrowStatus='LAMBAT PULANG' OR 
borrow.borrowStatus='DALAM PINJAMAN' AND borrow.memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `inserNewBranch`(IN vBranchName varchar(50))
BEGIN 
INSERT INTO branch VALUES('', vBranchName);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertAttendanceBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'attendance', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertAttendanceStatisticBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'attendance_statistic', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertAuditLog`(IN vMemberID varchar(10))
BEGIN 
INSERT INTO audit_log VALUES('', vMemberID, NOW(), '');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertAuditLogBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'audit_log', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertBackupLogBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'backup_log', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertBlacklistBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'blacklist', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertBookBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'book', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertBookLanguageBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'book_language', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertBorrowBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'borrow', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertBorrowStatisticBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'borrow_statistic', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertBranchBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'branch', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertContactBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'contact', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertEmailBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'email', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertFormBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'form', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertInfoBlast2BeliaDewasa`(IN vInfoBlastDate2 date, IN vMemberID varchar(5))
BEGIN 
	UPDATE blacklist SET infoBlastDate2=vInfoBlastDate2
	WHERE memberID=vMemberID;
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertInfoBlast3BeliaDewasa`(IN vInfoBlastDate3 date, IN vMemberID varchar(5))
BEGIN 
UPDATE blacklist SET infoBlastDate3=vInfoBlastDate3
WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertMemberBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'member', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertMemberDateRegisterBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'member_date_register', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertMemberStatisticBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'member_statistic', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertNewBook`(IN vBookTitle varchar(50),IN vBookISBN varchar(20),
IN vTypeBookID int(11), IN vAuthor varchar(50), IN vPlaceOfIssue varchar(50), IN
vPublisher varchar(50), IN vYearsOfIssue int(11), IN vNoOfAcquisition varchar(30),
IN vDateOfAcquisition date, IN vCallNo int(11), IN vBookPrice double, IN vBookLanguageID
int(11))
BEGIN 
INSERT INTO book VALUES('', vBookTitle, vBookISBN, vTypeBookID,
vAuthor, vPlaceOfIssue, vPublisher, vYearsOfIssue, vNoOfAcquisition,
vDateOfAcquisition, vCallNo, vBookPrice, NOW(), NOW(), vBookLanguageID,
'SEDIA ADA', '');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertNewBranch`(IN vBranchName varchar(50))
BEGIN 
INSERT INTO branch VALUES('', vBranchName);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertRecoveryLogBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'recovery_log', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertSignBoardDateKanak`(IN vSignBoardDate date, IN vMemberID varchar(5))
BEGIN 
UPDATE blacklist SET signBoardDate=vSignBoardDate
WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertStaffBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'staff', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertStatisticYearBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'statistic_year', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertTotalWarningBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'total_warning', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertTypeBookBackupLog`()
BEGIN 
INSERT INTO backup_log VALUES('', 'type_book', NOW(), 'BACKUP DATA');
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertWarningDateKanak`(IN vWarningDate date, IN vMemberID varchar(5))
BEGIN 
UPDATE blacklist SET warningDate=vWarningDate 
WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertWarningLetterBeliaDewasa3BeliaDewasa`(IN vWarningDate date, IN vMemberID varchar(5))
BEGIN 
UPDATE blacklist SET warningDate=vWarningDate
WHERE memberID=vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectMemberLogin`(IN vMemberID varchar(5))
BEGIN 
SELECT memberID, memberIDEncrypt, memberPassword 
FROM member WHERE memberID = vMemberID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectStaffLogin`(IN vStaffID varchar(9))
BEGIN 
SELECT staffID, staffIDEncrypt, staffPassword, staffRowLevel
FROM staff WHERE staffID = vStaffID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `statisticBorrowBookGeneral`(IN vYear int(11))
BEGIN 
SELECT * FROM borrow_statistic WHERE
year=vYear ORDER BY month ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `statisticNewMember`(IN vYear int(11))
BEGIN 
SELECT * FROM member_statistic WHERE 
year=vYear ORDER BY month ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `statisticTotalAdultYearly`(IN vYear int(11))
BEGIN 
SELECT year, adult AS totalAdult FROM borrow_statistic 
WHERE year=vYear ORDER BY month ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `statisticTotalKidYearly`(IN vYear int(11))
BEGIN 
SELECT year, kid AS totalKid FROM borrow_statistic 
WHERE year=vYear ORDER BY month ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `statisticTotalYouthYearly`(IN vYear int(11))
BEGIN 
SELECT year, youth AS totalYouth FROM borrow_statistic 
WHERE year=vYear ORDER BY month ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `statisticVisitor`(IN vYear int(11))
BEGIN 
SELECT * FROM attendance_statistic
WHERE year=vYear ORDER BY month ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateBookStatusSediaAda`(IN vBookID int(11))
BEGIN 
UPDATE book SET bookStatus='SEDIA ADA', memberID='' WHERE bookID=vBookID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateBorrowStatusPulang`(IN vBorrowID int(11))
BEGIN 
UPDATE borrow SET borrowStatus='PULANG' WHERE borrowID=vBorrowID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateTotalBorrowMemberDecrease`(IN vMemberID varchar(5))
BEGIN 
UPDATE member SET totalBorrow=totalBorrow-1 WHERE memberID=vMemberID;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE IF NOT EXISTS `attendance` (
`attendanceID` int(11) NOT NULL,
  `attendanceDate` date NOT NULL,
  `attendanceTime` varchar(30) NOT NULL,
  `staffID` varchar(9) NOT NULL,
  `attendanceRace` varchar(20) NOT NULL,
  `attendanceGender` varchar(10) NOT NULL,
  `attendanceCategory` varchar(20) NOT NULL,
  `attendanceTotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `attendance_statistic`
--

CREATE TABLE IF NOT EXISTS `attendance_statistic` (
`attendanceStatisticID` int(11) NOT NULL,
  `month` varchar(20) NOT NULL,
  `monthNum` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `totalMale` int(11) DEFAULT '0',
  `totalFemale` int(11) DEFAULT '0',
  `raceMelayu` int(11) DEFAULT '0',
  `raceCina` int(11) DEFAULT '0',
  `raceIndia` int(11) DEFAULT '0',
  `raceOther` int(11) DEFAULT '0',
  `adult` int(11) DEFAULT '0',
  `youth` int(11) DEFAULT '0',
  `kid` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE IF NOT EXISTS `audit_log` (
`auditLogID` int(11) NOT NULL,
  `staffID` varchar(20) NOT NULL,
  `logInDate` datetime NOT NULL,
  `logOutDate` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `audit_log`
--

INSERT INTO `audit_log` (`auditLogID`, `staffID`, `logInDate`, `logOutDate`) VALUES
(1, 'ABM040001', '2017-05-13 21:08:09', '2017-05-13 21:08:14'),
(2, '0016D', '2017-05-13 21:09:39', '2017-05-13 21:09:45'),
(3, 'ABM040001', '2017-05-13 21:10:25', '2017-05-13 22:16:10'),
(4, 'ADMIN0001', '2017-05-13 22:16:22', '2017-05-13 22:16:30'),
(5, 'ABM040001', '2017-05-13 22:17:03', '0000-00-00 00:00:00'),
(6, 'ABM040001', '2017-05-14 20:35:02', '0000-00-00 00:00:00'),
(7, 'ABM040001', '2017-05-15 15:12:29', '0000-00-00 00:00:00'),
(8, 'ABM040001', '2017-05-15 20:55:07', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `backup_log`
--

CREATE TABLE IF NOT EXISTS `backup_log` (
`backupLogID` int(11) NOT NULL,
  `tableBackup` varchar(50) NOT NULL,
  `backupDateTime` datetime NOT NULL,
  `descriptionBackup` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `blacklist`
--

CREATE TABLE IF NOT EXISTS `blacklist` (
`blacklistID` int(11) NOT NULL,
  `memberID` varchar(5) NOT NULL,
  `infoBlastDate1` date DEFAULT NULL,
  `infoBlastDate2` date DEFAULT NULL,
  `infoBlastDate3` date DEFAULT NULL,
  `noticeDate` date DEFAULT NULL,
  `signBoardDate` date DEFAULT NULL,
  `warningDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Triggers `blacklist`
--
DELIMITER //
CREATE TRIGGER `trigDeleteBlacklist` BEFORE DELETE ON `blacklist`
 FOR EACH ROW BEGIN

       DELETE FROM `psm`.`total_warning` WHERE memberID=old.memberID; 
     
       UPDATE borrow SET borrowStatus='SEDIA ADA' WHERE memberID=old.memberID AND borrowStatus='TIDAK DIPULANGKAN'; 
       
       UPDATE member SET memberStatus='SAH', totalBorrow='0' WHERE memberID=old.memberID; 
       
       UPDATE book SET bookStatus='SEDIA ADA', memberID='' WHERE memberID=old.memberID AND bookStatus='TIADA';
      
    END
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `trigInsertBlacklist` AFTER INSERT ON `blacklist`
 FOR EACH ROW BEGIN

       INSERT INTO total_warning VALUES('', new.memberID, '1');
     
       UPDATE borrow SET borrowStatus='TIDAK DIPULANGKAN' WHERE memberID=new.memberID AND borrowStatus='DALAM PINJAMAN';

       UPDATE member SET memberStatus='PROSES SENARAI HITAM' WHERE memberID=new.memberID;

       UPDATE book SET bookStatus='TIADA' WHERE memberID=new.memberID AND bookStatus='DALAM PINJAMAN';
      
    END
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `trigUpdateInfoBlastBlacklist` AFTER UPDATE ON `blacklist`
 FOR EACH ROW BEGIN
    DECLARE vTotalWarning int(11);
    DECLARE vMemberType varchar(20);
    DECLARE vMemberStatus varchar(20);

    SELECT totalWarning INTO vTotalWarning FROM total_warning WHERE memberID=new.memberID;

    SELECT memberType, memberStatus INTO vMemberType, vMemberStatus FROM member WHERE memberID=new.memberID;

      IF(vTotalWarning = 1 && vMemberType = 'KANAK-KANAK' && vMemberStatus = 'PROSES SENARAI HITAM') THEN
         UPDATE total_warning SET totalWarning=totalWarning+1 WHERE memberID=new.memberID;

      ELSEIF(vTotalWarning = 2 && vMemberType = 'KANAK-KANAK' && vMemberStatus = 'PROSES SENARAI HITAM') THEN
          UPDATE total_warning SET totalWarning=totalWarning+1 WHERE memberID=new.memberID;
          UPDATE member SET memberStatus='SENARAI HITAM' WHERE memberID=new.memberID;

      ELSEIF(vTotalWarning = 3 && vMemberType = 'KANAK-KANAK' && vMemberStatus = 'SENARAI HITAM') THEN
          UPDATE member SET memberStatus='SENARAI HITAM' WHERE memberID=new.memberID;

      ELSEIF(vTotalWarning = 1 && vMemberType = 'BELIA' && vMemberStatus = 'PROSES SENARAI HITAM' || vTotalWarning = 1 && vMemberType = 'DEWASA' && vMemberStatus = 'PROSES SENARAI HITAM') THEN
          UPDATE total_warning SET totalWarning=totalWarning+1 WHERE memberID=new.memberID;

      ELSEIF(vTotalWarning = 2 && vMemberType = 'BELIA' && vMemberStatus = 'PROSES SENARAI HITAM' || vTotalWarning = 2 && vMemberType = 'DEWASA' && vMemberStatus = 'PROSES SENARAI HITAM') THEN
          UPDATE total_warning SET totalWarning=totalWarning+1 WHERE memberID=new.memberID;

      ELSEIF(vTotalWarning = 3 && vMemberType = 'BELIA' && vMemberStatus = 'PROSES SENARAI HITAM' || vTotalWarning = 3 && vMemberType = 'DEWASA' && vMemberStatus = 'PROSES SENARAI HITAM') THEN
          UPDATE total_warning SET totalWarning=totalWarning+1 WHERE memberID=new.memberID;
          UPDATE member SET memberStatus='SENARAI HITAM' WHERE memberID=new.memberID;

      ELSEIF(vTotalWarning = 4 && vMemberType = 'BELIA' && vMemberStatus = 'SENARAI HITAM' || vTotalWarning = 4 && vMemberType = 'DEWASA' && vMemberStatus = 'SENARAI HITAM') THEN
          UPDATE member SET memberStatus='SENARAI HITAM' WHERE memberID=new.memberID;
      END IF;
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE IF NOT EXISTS `book` (
`bookID` int(11) NOT NULL,
  `bookTitle` varchar(50) NOT NULL,
  `bookISBN` varchar(20) NOT NULL,
  `typeBookID` int(11) NOT NULL,
  `author` varchar(50) NOT NULL,
  `placeOfIssue` varchar(50) NOT NULL,
  `publisher` varchar(50) NOT NULL,
  `yearsOfIssue` int(11) NOT NULL,
  `noOfAcquisition` varchar(30) NOT NULL,
  `dateOfAcquisition` date NOT NULL,
  `callNo` int(11) NOT NULL,
  `bookPrice` double NOT NULL,
  `registerDate` date NOT NULL,
  `registerTime` time NOT NULL,
  `bookLanguageID` int(11) NOT NULL,
  `bookStatus` varchar(20) NOT NULL,
  `memberID` varchar(5) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`bookID`, `bookTitle`, `bookISBN`, `typeBookID`, `author`, `placeOfIssue`, `publisher`, `yearsOfIssue`, `noOfAcquisition`, `dateOfAcquisition`, `callNo`, `bookPrice`, `registerDate`, `registerTime`, `bookLanguageID`, `bookStatus`, `memberID`) VALUES
(6, 'WORDSEARCH', '9780857341938', 7, 'Igloo Books Ltd', 'China', 'igloo', 2010, '654776', '2017-05-07', 332445, 4.99, '2017-05-07', '00:43:08', 3, 'SEDIA ADA', ''),
(7, 'Android Application Development DUMMIES', '9781118027707', 4, 'Barry Burd', 'New Jersey', 'John Wiley & Sons, inc', 2012, '2567319', '2017-05-07', 2567319, 127.8, '2017-05-07', '00:55:35', 3, 'SEDIA ADA', ''),
(8, 'Hacking for DUMMIES', '9781118380932', 4, 'Kevin Beaver, CISSP', 'Canada', 'jo', 2013, '2567320', '2017-05-07', 2567320, 95.8, '2017-05-07', '01:18:38', 3, 'SEDIA ADA', ''),
(9, 'Modul Pengajian Tamadun Islam dan Tamadun Asia', '9789831004654', 5, 'Osman Bakar', 'Kuala Lumpur', 'Penerbit Universiti Malaya', 2009, '02500', '2017-05-07', 2500, 30, '2017-05-07', '01:22:31', 1, 'SEDIA ADA', ''),
(10, 'Rasulullah is my Doctor', '9789673661374', 1, 'Jerry D. Gray', 'Batu Caves, Selangor', 'PTS ISLAMIKA SDN. BHD.', 2013, '145140', '2017-05-07', 145140, 25, '2017-05-07', '01:25:29', 1, 'SEDIA ADA', ''),
(11, 'The Legend of Sleepy Hollow', '070097045000', 2, 'Washington Irving', 'New York', 'Playmore Inc', 2003, '120403', '2017-05-07', 120403, 2.9, '2017-05-07', '01:32:26', 3, 'SEDIA ADA', ''),
(12, 'The Three Musketeers', '9789814177535', 2, 'Alexandre Dumas', 'Singapore', 'New Dawn Press', 2005, '368240', '2017-05-07', 368240, 2.9, '2017-05-07', '01:34:46', 3, 'SEDIA ADA', ''),
(13, 'Physics of Future', '9780141044248', 3, 'Michio Kaku', 'England', 'PENGUIN BOOKS', 2012, '018179', '2017-05-07', 18179, 47.65, '2017-05-07', '01:39:37', 3, 'SEDIA ADA', ''),
(14, 'The Secret of the Old Clock', '9780448095011', 2, 'Carolyn Keene', 'New York', 'GROSSET & DUNLAP', 2002, '50599', '2017-05-07', 50599, 13.9, '2017-05-07', '01:56:43', 3, 'SEDIA ADA', ''),
(15, 'Can of Worms', '071001003994', 2, 'Kathy Mackel', 'New York', 'Avon Books', 1999, '008012', '2017-05-07', 8012, 5, '2017-05-07', '02:00:33', 3, 'SEDIA ADA', ''),
(16, 'Twelve Silver Cups', '9780861631421', 2, 'Enid Blyton', 'Singapore', 'Award Publications Limited', 2002, '120904', '2017-05-07', 120904, 12.9, '2017-05-07', '02:03:31', 3, 'SEDIA ADA', ''),
(17, 'The Bungalow Mystery', '9780448095035', 2, 'Carolyn Keene', 'New York', 'GROSSET & DUNLAP', 2004, '50599', '2017-05-11', 50599, 13.9, '2017-05-07', '02:08:31', 3, 'SEDIA ADA', ''),
(18, 'The Hidden Staircase', '9780448095028', 2, 'Carolyn Keene', 'New York', 'GROSSET & DUNLAP', 2003, '50599', '2017-05-14', 50599, 25.99, '2017-05-14', '20:37:39', 3, 'SEDIA ADA', ''),
(19, 'The Mystery of the Fire Dragon', '9780448095387', 2, 'Carolyn Keene', 'New York', 'GROSSET & DUNLAP', 2000, '90000', '2017-05-14', 90000, 25.99, '2017-05-14', '20:39:55', 3, 'SEDIA ADA', '');

-- --------------------------------------------------------

--
-- Table structure for table `book_language`
--

CREATE TABLE IF NOT EXISTS `book_language` (
`bookLanguageID` int(11) NOT NULL,
  `bookLanguageName` varchar(30) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `book_language`
--

INSERT INTO `book_language` (`bookLanguageID`, `bookLanguageName`) VALUES
(1, 'Bahasa Melayu'),
(2, 'Bahasa Cina'),
(3, 'Bahasa Inggeris');

-- --------------------------------------------------------

--
-- Table structure for table `borrow`
--

CREATE TABLE IF NOT EXISTS `borrow` (
`borrowID` int(11) NOT NULL,
  `bookID` int(11) NOT NULL,
  `memberID` varchar(5) NOT NULL,
  `borrowStatus` varchar(30) NOT NULL,
  `borrowDate` date NOT NULL,
  `returnDate` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `borrow`
--

INSERT INTO `borrow` (`borrowID`, `bookID`, `memberID`, `borrowStatus`, `borrowDate`, `returnDate`) VALUES
(3, 6, '0001b', 'SEDIA ADA', '2017-05-15', '2017-06-05'),
(4, 6, '0001D', 'SEDIA ADA', '2017-05-15', '2017-06-05'),
(5, 6, '0001K', 'SEDIA ADA', '2017-05-15', '2017-06-05');

--
-- Triggers `borrow`
--
DELIMITER //
CREATE TRIGGER `trigInsertBorrow` AFTER INSERT ON `borrow`
 FOR EACH ROW BEGIN

      UPDATE book SET memberID=new.memberID, bookStatus='DALAM PINJAMAN' WHERE bookID=new.bookID;

      UPDATE member SET totalBorrow=totalBorrow+1 WHERE memberID=new.memberID;
      
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `borrow_statistic`
--

CREATE TABLE IF NOT EXISTS `borrow_statistic` (
`borrowStatisticID` int(11) NOT NULL,
  `month` varchar(20) NOT NULL,
  `monthNum` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `totalMale` int(11) DEFAULT '0',
  `totalFemale` int(11) DEFAULT '0',
  `raceMelayu` int(11) NOT NULL DEFAULT '0',
  `raceCina` int(11) NOT NULL DEFAULT '0',
  `raceIndia` int(11) NOT NULL DEFAULT '0',
  `raceOther` int(11) NOT NULL DEFAULT '0',
  `adult` int(11) NOT NULL DEFAULT '0',
  `youth` int(11) NOT NULL DEFAULT '0',
  `kid` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `borrow_statistic`
--

INSERT INTO `borrow_statistic` (`borrowStatisticID`, `month`, `monthNum`, `year`, `totalMale`, `totalFemale`, `raceMelayu`, `raceCina`, `raceIndia`, `raceOther`, `adult`, `youth`, `kid`) VALUES
(1, 'May', 5, 2017, 1, 4, 5, 0, 0, 0, 1, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE IF NOT EXISTS `branch` (
`branchID` int(11) NOT NULL,
  `branchName` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branchID`, `branchName`) VALUES
(1, 'AEON Bandaraya Melaka'),
(2, 'Melaka Mall'),
(4, 'Jasin Melaka');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
`contactID` int(11) NOT NULL,
  `contactFatherH` varchar(13) NOT NULL,
  `contactFatherO` varchar(13) NOT NULL,
  `contactFatherM` varchar(13) NOT NULL,
  `contactMotherH` varchar(13) NOT NULL,
  `contactMotherO` varchar(13) NOT NULL,
  `contactMotherM` varchar(13) NOT NULL,
  `contactSelfH` varchar(13) NOT NULL,
  `contactSelfO` varchar(13) NOT NULL,
  `contactSelfM` varchar(13) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=101 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`contactID`, `contactFatherH`, `contactFatherO`, `contactFatherM`, `contactMotherH`, `contactMotherO`, `contactMotherM`, `contactSelfH`, `contactSelfO`, `contactSelfM`) VALUES
(1, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(2, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(3, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(4, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(5, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(6, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(7, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(8, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(9, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(10, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(11, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(12, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(13, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(14, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(15, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(16, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(17, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(18, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(19, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(20, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(21, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(22, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(23, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(24, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(25, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(26, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(27, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(28, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(29, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(30, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(31, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(32, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(33, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(34, '2013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(35, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(36, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(37, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(38, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(39, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(40, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(41, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(42, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(43, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(44, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(45, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(46, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(47, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(48, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(49, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(50, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(51, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(52, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(53, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(54, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(55, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(56, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(57, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(58, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(59, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(60, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(61, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(62, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(63, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(64, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(65, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(66, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(67, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(68, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(69, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(70, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(71, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(72, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(73, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(74, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(75, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(76, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(77, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(78, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(79, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(80, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(81, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(82, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(83, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(84, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(85, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(86, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(87, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(88, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(89, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(90, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(91, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(96, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(97, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(98, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(99, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787'),
(100, '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787', '013-56667787');

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE IF NOT EXISTS `email` (
`emailID` int(11) NOT NULL,
  `emailFather` varchar(50) NOT NULL,
  `emailMother` varchar(50) NOT NULL,
  `emailSelf` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=101 ;

--
-- Dumping data for table `email`
--

INSERT INTO `email` (`emailID`, `emailFather`, `emailMother`, `emailSelf`) VALUES
(1, 'kadar@gmail.com', 'shafiqah@gmail.com', 'n.afiqah@gmail.com'),
(2, 'rethinamani@gmail.com', 'sanjana@gmail.com', 'sathesgumar@gmail.com'),
(3, 'alias@gmail.com', 'sharifah@gmail.com', 'n.annisah@gmail.com'),
(4, 'azzam@gmail.com', 'zuria@gmail.com', 'nurfatihah@gmail.com'),
(5, 'ramle@gmail.com', 'rabiah@gmail.com', 'fitri@gmail.com'),
(6, 'johari12@gmail.com', 'juwana@gmail.com', 'fifi_athirah@gmail.com'),
(7, 'rokman43@gmail.com', 'rokiah21@gmail.com', 'rohaidi7@gmail.com'),
(8, 'suib@gmail.com', 'syifasah@gmail.com', 'daus@gmail.com'),
(9, 'zaharin@gmail.com', 'zurin@gmail.com', 'aziem@gmail.com'),
(10, 'amran@gmail.com', 'aminah@gmail.com', 'faliq@gmail.com'),
(11, 'norizan@gmail.com', 'norasmala@gmail.com', 'afiq@gmail.com'),
(12, 'abuzah@gmail.com', 'mariam@gmail.com', 'imam@gmail.com'),
(13, 'johari@gmail.com', 'johana@gmail.com', 'wafiy@gmail.com'),
(14, 'm.nor@gmail.com', 'syazlin@gmail.com', 'wan.syahreen@gmail.com'),
(15, 'arsil@gmail.com', 'armila@gmail.com', 'nur.izaty@gmail.com'),
(16, 'sainan@gmail.com', 'siti@gmail.com', 'nurul.fad@gmail.com'),
(17, 'ahmad.fauzan@gmail.com', 'faidzah@gmail.com', 'm.faiz@gmail.com'),
(18, 'm.salasa@gmail.com', 'syida@gmail.com', 'nurul.hudah@gmail.com'),
(19, 'abd.wahid@gmail.com', 'wahidah@gmail.com', 'nurul.syahira@gmail.com'),
(20, 'yarman@gmail.com', 'fatin@gmail.com', 'fayarika@gmail.com'),
(21, 'm.isa@gmail.com', 'filzah@gmail.com', 'syakira@gmail.com'),
(22, 'mohamad.isa@gmail.com', 'miza@gmail.com', 'm.saifullah@gmail.com'),
(23, 'akram@gmail.com', 'adilah@gmail.com', 'dzul.akmal@gmail.com'),
(24, 'muhammad43@gmail.com', 'mira@gmail.com', 'norazlifah@gmail.com'),
(25, 'nasir@gmail.com', 'wani@gmail.com', 'nurfateha@gmail.com'),
(26, 'abdul.aziz@gmail.com', 'arzwina@gmail.com', 'puteri.n.afiqah@gmail.com'),
(27, 'rozali@gmail.com', 'rusyda@gmail.com', 'm.izzudin@gmail.com'),
(28, 'rusli@gmail.com', 'amylia@gmail.com', 'noramelia@gmail.com'),
(29, 'ismail@gmail.com', 'haryatie@gmail.com', 'zarif.dayana@gmail.com'),
(30, 'samsun@gmail.com', 'syifah@gmail.com', 'norsyafira@gmail.com'),
(31, 'shaffry@gmail.com', 'syahilah@gmail.com', 'syamimi@gmail.com'),
(32, 'mohammad@gmail.com', 'ardina@gmail.com', 'shameza@gmail.com'),
(33, 'elacgovan@gmail.com', 'santini@gmail.com', 'tamarai.selvee@gmail.com'),
(34, 'ahmad.syaipudin@gmail.com', 'arzira@gmail.com', 'amirah.aqilah@gmail.com'),
(35, 'anuar@gmail.com', 'zaiton@gmail.com', 'syaiful.akmal@gmail.com'),
(36, 'kamaruzaman@gmail.com', 'khadijah@gmail.com', 'nabilah@gmail.com'),
(37, 'mee23@gmail.com', 'janet@gmail.com', 'vong.mee@gmail.com'),
(38, 'saminadan@gmail.com', 'sanjana@gmail.com', 'vissalini@gmail.com'),
(39, 'zulkifli@gmail.com', 'sarah@gmail.com', 'syazana@gmail.com'),
(40, 'sheng@gmail.com', 'chia@gmail.com', 'heie.jing@gmail.com'),
(41, 'misrap@gmail.com', 'maisarah@gmail.com', 'm.naim@gmail.com'),
(42, 'misrap@gmail.com', 'maisarah@gmail.com', 'm.naim@gmail.com'),
(43, 'mohd.zurin@gmail.com', 'zaimah@gmail.com', '.hafizul.hafizin@gmail.com'),
(44, 'abdul.rasid@gmail.com', 'aisyah@gmail.com', 'jannah@gmail.com'),
(45, 'husin@gmail.com', 'syahilah@gmail.com', 'm.faiz@gmail.com'),
(46, 'abd.rahman@gmail.com', 'aiza@gmail.com', 'wan.rizal@gmail.com'),
(47, 'elias@gmail.com', 'ellisa@gmail.com', 'm.faiz@gmail.com'),
(48, 'johari@gmail.com', 'juwana@gmail.com', 'rafhanah@gmail.com'),
(49, 'nurhady@gmail.com', 'norhaslinda@gmail.com', 'siti.munifah@gmail.com'),
(50, 'farakkasi@gmail.com', 'aslinda@gmail.com', 'asmawati@gmail.com'),
(51, 'jumelan@gmail.com', 'julaida@gmail.com', 'asmidar@gmail.com'),
(52, 'ahmad32@gmail.com', 'azira@gmail.com', 'amizah.aida@gmail.com'),
(53, 'noorahim@gmail.com', 'noralifah@gmail.com', 'nur.nabilah@gmail.com'),
(54, 'rosdi@gmail.com', 'rosleen@gmail.com', 'puteri.ira@gmail.com'),
(55, 'sheng@gmail.com', 'shua@gmail.com', 'siah.bing@gmail.com'),
(56, 'jasmi@gmail.com', 'juwita@gmail.com', 'amalina@gmail.com'),
(57, 'gee@gmail.com', 'gai@gmail.com', 'lim.chong@gmail.com'),
(58, 'hau@gmail.com', 'hen@gmail.com', 'low.chen@gmail.com'),
(59, 'mohd.said@gmail.com', 'aliah@gmail.com', 'fatin.halilah@gmail.com'),
(60, 'tat@gmail.com', 'tee@gmail.com', 'chen.jian@gmail.com'),
(61, 'loong@gmail.com', 'lien@gmail.com', 'low.sheng@gmail.com'),
(62, 'hong@gmail.com', 'hiau@gmail.com', 'yeoh.wai@gmail.com'),
(63, 'zulfikri@gmail.com', 'fiana@gmail.com', 'nurul.amalina@gmail.com'),
(64, 'ku.adnan@gmail.com', 'aisyah@gmail.com', 'ku.nur.athirah@gmail.com'),
(65, 'ab.kadir@gmail.com', 'arisa@gmail.com', 'nurliyana@gmail.com'),
(66, 'md.yusof@gmail.com', 'muslimah@gmail.com', 'nur.khairunisa@gmail.com'),
(67, 'azhar@gmail.com', 'azlina@gmail.com', 'amirul.ashraf@gmail.com'),
(68, 'shariff@gmail.com', 'shaza@gmail.com', 'nurul.shahirah@gmail.com'),
(69, 'wan.mustafa@gmail.com', 'wan.asilah@gmail.com', 'wan.nurfarahanie@gmail.com'),
(70, 'hilmi@gmail.com', 'haliza@gmail.com', 'nur.izatie@gmail.com'),
(71, 'mohamad56@gmail.com', 'muslafah@gmail.com', 'nurul.fadzillah@gmail.com'),
(72, 'hassan@gmail.com', 'harisa@gmail.com', 'nurul.ain@gmail.com'),
(73, 'mohammad43@gmail.com', 'maslita@gmail.com', 'nurul.haslinda@gmail.com'),
(74, 'affandi@gmail.com', 'aflizah@gmail.com', 'noramira@gmail.com'),
(75, 'mahadzir@gmail.com', 'mahani@gmail.com', 'nur.syazwani@gmail.com'),
(76, 'zainuddin@gmail.com', 'zairun@gmail.com', 'nurul.nadiah@gmail.com'),
(77, 'm.shariff@gmail.com', 'syifaz@gmail.com', 'armila.azira@gmail.com'),
(78, 'm.jan@gmail.com', 'miah@gmail.com', 'al.arif@gmail.com'),
(79, 'mohd.nordin@gmail.com', 'mazni@gmail.com', 'nurul.adilla@gmail.com'),
(80, 'jamail@gmail.com', 'juraida@gmail.com', 'azreena.husna@gmail.com'),
(81, 'md.hafiz@gmail.com', 'mufanah@gmail.com', 'nur.haliza@gmail.com'),
(82, 'abd.wahab@gmail.com', 'alisa@gmail.com', 'hamizah@gmail.com'),
(83, 'm.khalid@gmail.com', 'khasih@gmail.com', 'nor.ezreen@gmail.com'),
(84, 'azhar23@gmail.com', 'azlin@gmail.com', 'liyana.amira@gmail.com'),
(85, 'dzolkifli@gmail.com', 'diyana@gmail.com', 'n.diyana@gmail.com'),
(86, 'mohd.hasni@gmail.com', 'hasmila@gmail.com', 'aida.suhada@gmail.com'),
(87, 'balasathiah@gmail.com', 'kajol@gmail.com', 'prema@gmail.com'),
(88, 'abdul.yazid@gmail.com', 'yasmin@gmail.com', 'ain.nasuha@gmail.com'),
(89, 'abdul.manaf@gmail.com', 'aiza@gmail.com', 'nor.hidayah@gmail.com'),
(90, 'ahmad31@gmail.com', 'aliah@gmail.com', 'nurul.asyikin@gmail.com'),
(91, 'jamaluddin@gmail.com', 'jamilah@gmail.com', 'nurjuwana.izzati@gmail.com'),
(96, 'ismail@gmail.com', 'isaimah@gmail.com', 'n.erra@gmail.com'),
(97, 'raship@gmail.com', 'rusyda@gmail.com', 'n.hafizah@gmail.com'),
(98, 'ismail.23@gmail.com', 'isaimah@gmail.com', 'n.erra.syakirah@gmail.com'),
(99, 'zainuldin@gmail.com', 'zaimah@gmail.com', 'n.syazwani@gmail.com'),
(100, 'sheikh@gmail.com', 'aminah@gmail.com', 'ridwan@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE IF NOT EXISTS `form` (
`formID` int(11) NOT NULL,
  `memberID` varchar(100) NOT NULL,
  `formContent` blob,
  `dateUpload` datetime NOT NULL,
  `formStatus` varchar(30) NOT NULL,
  `formComment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Triggers `form`
--
DELIMITER //
CREATE TRIGGER `trigUpdateFormStatus` AFTER UPDATE ON `form`
 FOR EACH ROW BEGIN

      IF(new.formStatus = 'SAH') THEN
         UPDATE member SET memberStatus='SAH' WHERE memberID=new.memberID;

      ELSEIF(new.formStatus = 'TIDAK SAH') THEN
		 UPDATE member SET memberStatus='TIDAK SAH' WHERE memberID=new.memberID;
        
      END IF;
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `memberID` varchar(5) NOT NULL,
  `memberName` varchar(100) NOT NULL,
  `memberIC` varchar(15) NOT NULL,
  `memberBOD` varchar(10) DEFAULT NULL,
  `memberGender` varchar(10) NOT NULL,
  `memberRace` varchar(10) NOT NULL,
  `memberAddress` tinytext,
  `emailID` int(11) NOT NULL,
  `contactID` int(11) NOT NULL,
  `memberType` varchar(20) NOT NULL,
  `memberStatus` varchar(20) NOT NULL,
  `staffID` varchar(9) NOT NULL,
  `totalBorrow` int(11) DEFAULT NULL,
  `memberPassword` varchar(50) NOT NULL,
  `memberIDEncrypt` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`memberID`, `memberName`, `memberIC`, `memberBOD`, `memberGender`, `memberRace`, `memberAddress`, `emailID`, `contactID`, `memberType`, `memberStatus`, `staffID`, `totalBorrow`, `memberPassword`, `memberIDEncrypt`) VALUES
('0001B', 'AMIRAH AQILAH BINTI SAHAPUDIN @ AHMAD SHAIPUDIN', '040822085242', '2004-08-22', 'PEREMPUAN', 'MELAYU', 'Ayer Keroh, Melaka', 34, 34, 'BELIA', 'SAH', 'ABM040001', 0, 'da7383caffb0ecae53a37b8811a80cbb', '3af65c01a6749099656422675148de2d'),
('0001D', 'AL ARIF BIN MOHAMAD JAN', '960107126789', '01/07/1996', 'LELAKI', 'MELAYU', 'Tawau, Sabah', 78, 78, 'DEWASA', 'SAH', 'ABM040001', 0, 'f01942566595e17b7c02bb4dc7f8db93', '353f5c1d4d3915ffc108de8c19a265bc'),
('0001K', 'NURUL AFIQAH BINTI KADAR', '141031085048', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Shah Alam, Selangor', 1, 1, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, 'ce058eeec28d245518057d0c53598d19', '09189409b16882c7ef9340dedc026dff'),
('0002B', 'SYAIFUL AKMAL BIN ANUAR', '040921055479', '01/01/1970', 'LELAKI', 'MELAYU', 'Cheng, Melaka', 35, 35, 'BELIA', 'SAH', 'ABM040001', 0, '0292d0a124ee932620ab640370c63aa8', 'c150e43f73ca3d294fc207249a3e11c3'),
('0002D', 'NURUL ADILLA BINTI MOHD NORDIN', '961215016370', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Muar, Johor', 79, 79, 'DEWASA', 'SAH', 'ABM040001', 0, 'ea6e66068f9562c7cbceab424b9384b5', '8be58d3e6b3e112306a9dab50efe9353'),
('0002K', 'SATHESGUMAR A/L RETHINAMANI', '130330065409', '01/01/1970', 'LELAKI', 'INDIA', 'Sungai Udang, Melaka', 2, 2, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '64d9abc88d4aafef3870bc3b6fe31f6c', 'e95cb8efec8f7eeb454ce59bc6e8ce1c'),
('0003B', 'NABILAH BINTI KAMARUZAMAN', '040807035554', '08/07/2004', 'PEREMPUAN', 'MELAYU', 'Malim, Melaka', 36, 36, 'BELIA', 'SAH', 'ABM040001', 0, 'aea0db41c434f667957c12a5d9577cb3', 'd1f0a08b153a106c37e915a3fe919915'),
('0003D', 'NOOR AZREENA HUSNA BINTI MOHD JAMAIL', '960705115246', '07/05/1996', 'PEREMPUAN', 'MELAYU', 'Sungai Udang, Melaka', 80, 80, 'DEWASA', 'SAH', 'ABM040001', 0, '288124916c3b39af6269ee6f08aec895', '8d69f048b45ab0484bb33e0308ffeb9a'),
('0003K', 'NURUL ANNISHA BINTI ALIAS', '120507016038', '05/07/2012', 'PEREMPUAN', 'MELAYU', 'Air Hitam, Melaka', 3, 3, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '0d30e432a82ab6e7625dae0f985e7cce', '308c13619e2a77776e83e11d8f83c5ab'),
('0004B', 'VONG MEE MEE', '040917135882', '01/01/1970', 'PEREMPUAN', 'CINA', 'Ayer Pabas, Melaka', 37, 37, 'BELIA', 'SAH', 'ABM040001', 0, 'b322a21a8843381c0ca7443b4042cbf9', '5632f941cbffcb1e02a0d1d74f11b0ee'),
('0004D', 'NUR HALIZA BINTI MD. HAFIZ', '961212016578', '12/12/1996', 'PEREMPUAN', 'MELAYU', 'Bemban, Melaka', 81, 81, 'DEWASA', 'SAH', 'ABM040001', 0, '1886a9ecd56715bd42688533c03afe0c', '4b3c457de289eac2718ab828c4f62e6c'),
('0004K', 'NURFATIHAH BINTI AZZAM', '120118025116', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Cheng, Melaka', 4, 4, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '6379ac888f6e6a925d151413b128e650', '7123b79193f10b4cedc511556ce9ccc0'),
('0005B', 'VISSALINI A/P SAMINADAN', '041217146030', '01/01/1970', 'PEREMPUAN', 'INDIA', 'Shah Alam, Selangor', 38, 38, 'BELIA', 'SAH', 'ABM040001', 0, 'cd6a5e7a71f9d968fed50241de2400ba', '79281186efdd831f01b56b1192df45bb'),
('0005D', 'HAMIZAH BINTI ABD WAHAB', '960417075358', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Batu Berendam, Melaka', 82, 82, 'DEWASA', 'SAH', 'ABM040001', 0, 'ee0163d4f2b131cd26b0fd71df54557c', '1081393c778fd63e7de6f4033466088c'),
('0005K', 'MUHAMMAD FITRI FAKHRULLAH BIN RAMLE', '121216016349', '01/01/1970', 'LELAKI', 'MELAYU', 'Batu Berendam, Melaka', 5, 5, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '0336f3f009cb8b643f58d0e943cc70a3', 'd5c219665ac4342798fd8f6a80cf3396'),
('0006B', 'NOR ANIS SYAZANA BINTI ZULKIFLI', '031106085474', '11/06/2003', 'PEREMPUAN', 'MELAYU', 'Cheng, melaka', 39, 39, 'BELIA', 'SAH', 'ABM040001', 0, 'd1901b481c7524133cbe44d9b30ba548', '88dc7844647e4c13349cab64a4278e1d'),
('0006D', 'NOR EZREEN FARA BINTI MOHD KHALID', '950916085596', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Segamat, Melaka', 83, 83, 'DEWASA', 'SAH', 'ABM040001', 0, '5daf334e615a09df9cdf24162c95f065', '07942930835cf5f45603033880d1114a'),
('0006K', 'FIFI ATIRAH BINTI JOHARI', '111202115388', '12/02/2011', 'PEREMPUAN', 'MELAYU', 'Bukit Katil, Melaka', 6, 6, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '9c3c4c5d0feac5fb9ce7e2e29a642483', '9b195f253e5f5eb91ab2fa392b51c294'),
('0007B', 'HEIU JING SHENG', '030112016147', '01/12/2003', 'LELAKI', 'CINA', 'Bemban, Melaka', 40, 40, 'BELIA', 'SAH', 'ABM040001', 0, '85677cfb8a788fdb971b4feed645719f', '5ed281cf6f70a6ed8bb7719572098cac'),
('0007D', 'NUR LIYANA AMIRA BINTI AZHAR', '951021025850', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Batu Berendam, Melaka', 84, 84, 'DEWASA', 'SAH', 'ABM040001', 0, '53f32adbacef51b4fa9ba80706479821', 'ff25ddd41a69a298b5d43df1b6335ace'),
('0007K', 'MUHAMAD ROHAIDI BIN ROKMAN', '110422045103', '01/01/1970', 'LELAKI', 'MELAYU', 'Segamat, Melaka', 7, 7, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '254f4036626e79584e5fbda2715de2f7', '738c9a6b80f380eb5f74db6408adf4d6'),
('0008B', 'MUHAMMAD NAIM BIN MISRAP', '031201015863', '12/01/2003', 'LELAKI', 'MELAYU', 'Ayer Keroh, Melaka', 42, 42, 'BELIA', 'SAH', 'ABM040001', 0, 'e630c379528f0b6bb8dab1fb557c5a0d', '737de0b30b0ca13641ee2621abcf1564'),
('0008D', 'NUR DIYANA BINTI DZOLKIFLI', '951111065170', '11/11/1995', 'PEREMPUAN', 'MELAYU', 'Shah Alam, Selangor', 85, 85, 'DEWASA', 'SAH', 'ABM040001', 0, '66388236037077ed91814ebeebb4e077', 'b45b2a04d543334709b8ccf574037945'),
('0008K', 'MUHAMMAD FIRDAUS BIN SU''IB', '110911045017', '09/11/2011', 'LELAKI', 'MELAYU', 'Ayer Pabas, Melaka', 8, 8, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '446870faee3f0568c6b759c6b6f5d482', 'd1db8aaa1e2e69b61412e0b8278d7892'),
('0009B', 'MUHAMMAD HAFIZUL HELMI BIN MOHD ZURIN', '031110016737', '11/10/2003', 'LELAKI', 'MELAYU', 'Ayer Keroh, Melaka', 43, 43, 'BELIA', 'SAH', 'ABM040001', 0, '8eea5947c121877ba61f5bf9ed8b5bff', 'd09c6355f7b9d0ca987fec4681523276'),
('0009D', 'NUR AIDA SUHADA BINTI MOHD HASNI', '951227016466', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Muar, Johor Baru', 86, 86, 'DEWASA', 'SAH', 'ABM040001', 0, 'ef08c2c1bf1aba3f97a16b70b99312c2', '1034708f436b467508d973caacc1926f'),
('0009K', 'AMER AZIEM BIN ZAHARIN', '111230146609', '01/01/1970', 'LELAKI', 'MELAYU', 'Tampin, Melaka', 9, 9, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '56a22c7c6dc7dc767d664183270fcc89', '5b0626383d71fadd388515fe8bf7511b'),
('0010B', 'NURULJANNAH BINTI ABDUL RASID', '030709015568', '07/09/2003', 'PEREMPUAN', 'MELAYU', 'Batu Berendam, Melaka', 44, 44, 'BELIA', 'SAH', 'ABM040001', 0, '7ce15f01e3b07218de2b2bf85348857d', '0dc9e7ec5731e1be353047947179df0d'),
('0010D', 'PREMA SANTHINI A/P BALASATHIAH', '881230045486', '01/01/1970', 'PEREMPUAN', 'INDIA', 'Paya Rumput, Melaka', 87, 87, 'DEWASA', 'SAH', 'ABM040001', 0, '964e29d756d66e2e42374c00f050442f', 'c7dda2583cdeee689b0f65424baf7e38'),
('0010K', 'AHMAD FALIQ BN AMRAN', '110323145777', '01/01/1970', 'LELAKI', 'MELAYU', 'Masjid Tanah, Melaka', 10, 10, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '2e15451f8130cb7e08d9fc5d315259f8', 'a579e27b0c3a8a3984215b65ef598abc'),
('0011B', 'MOHAMAD FAIZ BIN HUSIN', '020117055243', '01/01/1970', 'LELAKI', 'MELAYU', 'Malim, Melaka', 45, 45, 'BELIA', 'SAH', 'ABM040001', 0, '74b15aba46a3acc0b55cf57193dffb44', '15f5f4b5415f488cfaffebbea91aa356'),
('0011D', 'AIN NASUHA BINTI ABDUL YAZID', '951228106156', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Ayer Keroh, Melaka', 88, 88, 'DEWASA', 'SAH', 'ABM040001', 0, '2d7db2cb3777a9adde7d2c326680dab5', '29e855786ab5cd2eda9b75eb4bd6b901'),
('0011K', 'MUHAMAD AFIQ BIN NORIZAN', '100307016429', '03/07/2010', 'LELAKI', 'MELAYU', 'Alor Gajah, Melaka', 11, 11, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '8b21e672ae63ccc3736cd132cbb176c9', '62d82faa99f3b2369607d82a97a466ef'),
('0012B', 'WAN MOHD RAZLAN BIN WAN ABDUL RAHMAN', '020612145609', '06/12/2002', 'LELAKI', 'MELAYU', 'Ayer Keroh, Melaka', 46, 46, 'BELIA', 'SAH', 'ABM040001', 0, 'b8379b9cb84788527fddbe7fe9dc2dd0', '0ab8a3c743297199b2493116bfbb72fd'),
('0012D', 'NOR HIDAYAH BINTI ABDUL MANAF', '951227025258', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Batang Aur, Selangor', 89, 89, 'DEWASA', 'SAH', 'ABM040001', 0, 'bf61a4cde4ab93120278c9bd035bf1b4', '9f90a712253d29952bf58e4abe4d8997'),
('0012K', 'IMAM MUKHSINEEN BIN ABU ZAH', '101217045555', '01/01/1970', 'LELAKI', 'MELAYU', 'Sungai besi, Melaka', 12, 12, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '047a610009cec3e974815e475a2f9c0b', '743a393f8696faf1069e754f86b1da15'),
('0013B', 'MUHAMMAD FAIZ BIN ELIAS', '020730045123', '01/01/1970', 'LELAKI', 'MELAYU', 'Air Pabas, Melaka', 47, 47, 'BELIA', 'SAH', 'ABM040001', 0, '78ccd9a901530a9c12a0e0a0993fe807', '9a072b3a5cc59c22411d0415057ad276'),
('0013D', 'NURUL ASYIKIN BINTI AHMAD', '950220065340', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Ayer Molek, Melaka', 90, 90, 'DEWASA', 'SAH', 'ABM040001', 0, '3dbf06a96025dedaac30f49cd58b2685', '527ee96f88a4d7e1624b01dc584ac287'),
('0013K', 'NUR ATHIRAH WAFIY BINTI MOHD  JOHARI', '100511085878', '05/11/2010', 'PEREMPUAN', 'MELAYU', 'Alor Gajah, Melaka', 13, 13, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, 'b906ceebb6fd420caa04bd89a63de269', '4fb4914e66e59c711cd5ef5c0322b6ec'),
('0014B', 'RAFHANAH BINTI JOHARI', '020301015628', '03/01/2002', 'PEREMPUAN', 'MELAYU', 'Ayer Keroh, Melaka', 48, 48, 'BELIA', 'SAH', 'ABM040001', 0, '20b84b029b6a47d4704a7316b84fa204', '93244b9c4ac98afeea7215502aa05a6d'),
('0014D', 'NURJUWANA IZZATI BINTI JAMALUDDIN', '950626146394', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Bachang, Melaka', 91, 91, 'DEWASA', 'SAH', 'ABM040001', 0, 'febaff2aa4110e8c9c3fcb257f938c4e', 'd7e8d70f1b29ab7aa716c349fd83f0c2'),
('0014K', 'WAN SYAHREEN HAZRIN BINTI WAN MOHAMMED NOR', '090920035820', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Pegoh, Melaka', 14, 14, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '2be52981e315ddbe5db976ae799f12fc', '0c0a1376effab4f1f6f8a0fdbd8059fe'),
('0015B', 'SITI MUNIFAH BINTI NURHADY', '021005145430', '10/05/2002', 'PEREMPUAN', 'MELAYU', 'Jasin, Melaka', 49, 49, 'BELIA', 'SAH', 'ABM040001', 0, '3b23d931595efbe1dc82f225571d20ae', 'b35f362cbb000f7363939ae301eab11e'),
('0015D', 'NOR HAFIZAH BINTI RASHIP', '950909126254', '09/09/95', 'PEREMPUAN', 'MELAYU', 'Sungai Rambar, Melaka', 97, 97, 'DEWASA', 'SAH', 'ABM040001', 0, 'b799b4e03670d96bf84e837688346f80', '34ae6e1e917ce05a30efe7dff80c309c'),
('0015K', 'NUR IZATY BINTI ARSIL', '091004085528', '10/04/2009', 'PEREMPUAN', 'MELAYU', 'Ayer Keroh, Melaka', 15, 15, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, 'b98e809f9776ede82d9c9b7a3cb8fad5', '9462627931b0c459dc9a0484dfaea982'),
('0016B', 'ASMAWATI BINTI FARAKKASI', '010525126108', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Ayer Keroh, Melaka', 50, 50, 'BELIA', 'SAH', 'ABM040001', 0, 'eba256cb7f78ea17ff38b33c0cb041b5', '36b7ad2bc8733739b92f512141d282bd'),
('0016D', 'NURUL ERRA SYAKIRAH BINTI ISMAIL', '940906045548', '06/09/94', 'PEREMPUAN', 'MELAYU', 'Ayer Molek, Melaka', 98, 98, 'DEWASA', 'SAH', 'ABM040001', 0, '8fea71eb98b91f89b237fcd5ed6fd5ab', 'a53ed8571a6c69f7b30d7e9c87a45b28'),
('0016K', 'NURUL FADHILAH BINTI SAINAN', '090814017338', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Air Pabas, Melaka', 16, 16, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, 'f4d87a4a6a826b8ead892a10cf61d35a', '7d9e9aff531cc9512e25677494f90914'),
('0017B', 'ASMIDAR BINTI JUMELAN', '011230055124', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Ayer Hitam, Melaka', 51, 51, 'BELIA', 'SAH', 'ABM040001', 0, '830a22431f9c22afabc90823eb77ced4', 'f60ba6647598081bfd9d56ef728ae0ff'),
('0017D', 'NUR SYAZWANI BINTI ZAINULDDIN', '950522015162', '22/05/95', 'PEREMPUAN', 'MELAYU', 'Ayer Keroh, Melaka', 99, 99, 'DEWASA', 'SAH', 'ABM040001', 0, '8d10a594616cd7ad7f3b14a2a5fc4749', '06103ce50570e41ae29c44b9b0a26464'),
('0017K', 'MOHAMAD FAIZ FARHAN BIN AHMAD FAUZAN', '091021035055', '01/01/1970', 'LELAKI', 'MELAYU', 'Batu Berendam, Melaka', 17, 17, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, 'dab36eb40c66d1ddd8e97936291c01cc', '5034f10f3b4f1fd79350ac88be0f3db5'),
('0018B', 'AMIZAH AIDA BINTI AHMAD', '010909086660', '09/09/2001', 'PEREMPUAN', 'MELAYU', 'Cheng, Melaka', 52, 52, 'BELIA', 'SAH', 'ABM040001', 0, 'dd16666331de84478ffaf53256b664b1', 'd27ccec0c08577a3f6994b39a0e2ee5a'),
('0018D', 'RIDWAN ABDIRASHID SHEIKH', 'P00252777', '12/12/95', 'LELAKI', 'LAIN-LAIN', 'Bukit Beruang, Melaka', 100, 100, 'DEWASA', 'SAH', 'ABM040001', 0, '47acaf4625eeb03174215cfab7aadc64', '54d6df403f9f2cdc0ce1c9e57f22d7db'),
('0018K', 'NURUL HUDAH BINTI MOHD SALASA', '080513126610', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Gadek, Melaka', 18, 18, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '21a26f796d5bb54c2806739ec266e13f', '18deeac5093b3f0116cb4428c3845db1'),
('0019B', 'NUR NABILAH BINTI NOORAHIM', '010829055556', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Bachang, Melaka', 53, 53, 'BELIA', 'SAH', 'ABM040001', 0, '05cf947ae1bb69e797dd4af8c2a1589e', '6e4d3a08769a86e691595325fa089453'),
('0019K', 'NURUL SYAHIRA BINTI ABDUL WAHID', '080526015960', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Jasin, Melaka', 19, 19, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, 'cb1e9a3c4e521e04faee2cad71e6e845', '0d38272d73b281000812ea4823173c96'),
('0020B', 'PUTERI NUR IRA FATIHAH BINTI ROSDI', '010807115782', '08/07/2001', 'PEREMPUAN', 'MELAYU', 'Alor Gajah, Melaka', 54, 54, 'BELIA', 'SAH', 'ABM040001', 0, '7dae1aca7be24cf4f84cb6b985ee71e4', '876fc15f0601d7e148645957d1405f0d'),
('0020K', 'FAYARIKA FEBRI BINTI YARMAN', '080207145590', '02/07/2008', 'PEREMPUAN', 'MELAYU', 'Lendu, Melaka', 20, 20, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, 'e4c7c6b683638e4933e01457889382e7', '69ded07302b924bcc013e91ca037c3de'),
('0021B', 'SIAH BING SHENG', '000828085367', '01/01/1970', 'LELAKI', 'CINA', 'Batu Berendam, Melaka', 55, 55, 'BELIA', 'SAH', 'ABM040001', 0, '83809dfade582174fc820602c8799448', '9243157ea05cc7eb9c9331d490c32e0f'),
('0021K', 'SYAKIRA BINTI MOHAMMAD ISA', '070410017550', '04/10/2007', 'PEREMPUAN', 'MELAYU', 'Air Panase, Melaka', 21, 21, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, 'f1554a8192538aab30c95fe591215c12', 'f171d20fde1331e78c25a2010dd317e5'),
('0022B', 'NUR AMALINA BINTI JASMI', '001003025196', '10/03/2000', 'PEREMPUAN', 'MELAYU', 'Gadek, Melaka', 56, 56, 'BELIA', 'SAH', 'ABM040001', 0, 'b0bce301cdd62cd900451a51e8148dbe', 'aee778fe40245580c62e7ded7f5db41e'),
('0022K', 'MOHAMAD SAIFULLAH ADHA BIN MOHAMAD ISA', '070109055427', '01/09/2007', 'LELAKI', 'MELAYU', 'Pegoh, Melaka', 22, 22, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '6b867938b1112deae2007c1d01a1e6d5', '303bf4bf52ac2a3076e9dec82ed13e67'),
('0023B', 'LIM CHONG GEE', '000705016185', '07/05/2000', 'LELAKI', 'CINA', 'Bachang, Melaka', 57, 57, 'BELIA', 'SAH', 'ABM040001', 0, '0e84efcbe7454d58a4efa7ea8833022a', 'd1cc651692e7358f80713af78bcf10e1'),
('0023K', 'DZUL AKMAL BIN AKRAM', '070717025943', '01/01/1970', 'LELAKI', 'MELAYU', 'Ayer Hitam, Melaka', 23, 23, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '2f00df6c9b9fb48422dfcc586b297327', '51a745f7a93a443db24a4aea9f92dfb5'),
('0024B', 'LOW CHEN HAU', '000604055353', '06/04/2000', 'LELAKI', 'CINA', 'Bukit Rambai, Melaka', 58, 58, 'BELIA', 'SAH', 'ABM040001', 0, 'c4c1461fb5d4888f93e95191558b2a26', '7d870c6b26cc4b28b8b8f40b9cfa828b'),
('0024K', 'NORAZLIFAH ILYATI BINTI MUHAMAD', '060517035820', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Bachang, Melaka', 24, 24, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, 'e76267b1964f4230fbb47e7f5da4a79b', 'acacba57066a88e02b0c6c4c4a09d84f'),
('0025B', 'FATIN NUR HALILAH BINTI MOHD SAID', '000414085842', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Ayer Hitam, Melaka', 59, 59, 'BELIA', 'SAH', 'ABM040001', 0, '315524469d3861cf2b0f2ba435cc5452', 'fcd21d5f070a8d2fa2a5e4cffe1d3b74'),
('0025K', 'NURFATEHA BINTI NASIR', '921018065598', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Shah Alam, Selangor', 25, 25, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '4f6c786d37a80f312dcdeb1eb22ccc18', 'a08086555af1992c99a34e87aee64c77'),
('0026B', 'CHEN JIAN TAT', '990915146279', '01/01/1970', 'LELAKI', 'CINA', 'Sungai Udang, Melaka', 60, 60, 'BELIA', 'SAH', 'ABM040001', 0, '4299b4e95d26e907a03f93232c5f7801', '8833a30ed5232047ba2ee6ae38c04374'),
('0026K', 'PUTERI NUR AFIQAH BINTI ABDUL AZIZ', '061217145504', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Bachang, Melaka', 26, 26, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, 'a50da7e0c56d1be8c8f97b5d550d52f7', '31d99bb298578768f15e2f4247738f88'),
('0027B', 'LOW SHENG LOONG', '991012145501', '10/12/1999', 'LELAKI', 'CINA', 'Malim, Melaka', 61, 61, 'BELIA', 'SAH', 'ABM040001', 0, 'ccbfb882273c812e5c8a56d859a43f6a', '84e3519be939f7881792333ec56ec408'),
('0027K', 'MUHAMMAD IZZUDIN BIN ROZALI', '050809045379', '08/09/2005', 'LELAKI', 'MELAYU', 'Ayer Keroh, Melaka', 27, 27, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, 'caf52bd7a0fdfd11f0b8e933cb2a2857', 'd44e96762ee89f6951cdd978a683f045'),
('0028B', 'YEOH WAI HONG', '990318146123', '01/01/1970', 'LELAKI', 'CINA', 'Jasin, Melaka', 62, 62, 'BELIA', 'SAH', 'ABM040001', 0, '457eaacb7ed54ec3dbb7ae054f2ce8ab', '72e3821c69f89f7809e02d2cfab19962'),
('0028K', 'NORAMELIA BINTI RUSLI', '050726085066', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Air Hitam, Melaka', 28, 28, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '672fd037d5752a9d7398602ab2e402d7', '29a9137b11a0b20040ac377171fd2c64'),
('0029B', 'NURUL AMALINA BINTI MOHD ZULKIFRI', '990916025574', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Ayer Keroh, Melaka', 63, 63, 'BELIA', 'SAH', 'ABM040001', 0, 'cc6eac5d812e7283f29ecffe30348390', 'b4f1a35f6965d3a9ed49ac710677c8e1'),
('0029K', 'ZARIF DAYANA BINTI ISMAIL', '051013115012', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Paya rumput, Melaka', 29, 29, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '0b6cca3ad413b6ccda6b59453305342c', 'a519e1cf84193b9516a5a1527caa2b36'),
('0030B', 'KU NUR ATHIRAH BINTI KU ADNAN', '990626026114', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Slandar, Melaka', 64, 64, 'BELIA', 'SAH', 'ABM040001', 0, '7d9824af289f638a684bbfcd5d69ffdf', 'f236055e3d6bfbc88df278fb26aa3230'),
('0030K', 'NORSYAFIRA BINTI SAMSUN', '130329065504', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Bachang, Melaka', 30, 30, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, '908d6c22120d780237dd35338d944a86', '11c12fa1b328643229a7a90e74c952e8'),
('0031B', 'NURLIYANA BINTI AB KADIR', '980212055054', '02/12/1998', 'PEREMPUAN', 'MELAYU', 'Trandak, Melaka', 65, 65, 'BELIA', 'SAH', 'ABM040001', 0, 'a97a59f9914518cce72c88d167dc3e5b', '4080215adf9ce27ddc5ecaa4268bcf5d'),
('0031K', 'NUR SYAMIMI BINTI MOHD SHAFFRY', '130707145270', '07/07/2013', 'PEREMPUAN', 'MELAYU', 'Bukit Rambai, Melaka', 31, 31, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, 'f0956d8b5b0fb6fa3a035e5d8dce1abe', 'd6303720d2877e3bc0ab08924ca9f826'),
('0032B', 'NUR KHAIRUNNISA BINTI MD YUSOF', '980828025574', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Air Hitam, Melaka', 66, 66, 'BELIA', 'SAH', 'ABM040001', 0, '0c5e5fb11880beaff36adb4062039d57', '7e4c3f347c9e12996519cadb40c2d3d1'),
('0032K', 'NURUL SHAMEZA BINTI MOHAMMAD', '130712145698', '07/12/2013', 'PEREMPUAN', 'MELAYU', 'Telok Mas, Melaka', 32, 32, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, 'ca43ddd4b2b081155bfb57e92a2d4946', '4a3479adc094489d0b32f62dd99ab71d'),
('0033B', 'AMIRUL ASHRAF BIN AZHAR', '981221055537', '01/01/1970', 'LELAKI', 'MELAYU', 'Batu Berendam, Melaka', 67, 67, 'BELIA', 'SAH', 'ABM040001', 0, '69c0423a4b4fc0bccbf08160e048422e', '564af47666991297cb15fee2f79f3d43'),
('0033K', 'TAMARAI SELVEE A/P ELANCGOVAN', '120607086122', '06/07/2012', 'PEREMPUAN', 'INDIA', 'Batu Berendam, Melaka', 33, 33, 'KANAK-KANAK', 'SAH', 'ABM040001', 0, 'bf22f2ce5d21f6996d44e5f2f4c77eb0', '2acf732c83dd3a5bad8d7df541a3fe46'),
('0034B', 'NURUL SHAHIRAH BINTI SHARIFF', '980928115498', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Jasin, Melaka', 68, 68, 'BELIA', 'SAH', 'ABM040001', 0, '4ea78a4f18dec909023ddcdc86ac3b0b', 'a4c4b845af0cf50896f31089d6a31b9d'),
('0035B', 'WAN NURFARHAINIE BINTI WAN MUSTAFA', '980604035490', '06/04/1998', 'PEREMPUAN', 'MELAYU', 'Bukit Rambai, Melaka', 69, 69, 'BELIA', 'SAH', 'ABM040001', 0, 'ef7f939705a91eb09e570a4d7989ff4b', 'ff973cde03ca347673b01d199ae9187e'),
('0036B', 'NUR IZATIE BINTI HILMI', '981225025896', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Ayer Keroh, Melaka', 70, 70, 'BELIA', 'SAH', 'ABM040001', 0, 'c4aa5f99a0aa2b835aff3f7ed3d63500', '2016c601a3f0b77c5b620f0b842c3072'),
('0037B', 'SITI NURUL FADZILLAH BINTI MOHAMAD', '970922035980', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Alor Gajah, Melaka', 71, 71, 'BELIA', 'SAH', 'ABM040001', 0, 'ca2c8c1fef9c50eb0b242b0eba4c11e4', 'e60fdcdbaa20a61ed80d4c74c7344048'),
('0038B', 'NOR NURUL AIN BINTI HASSAN', '971208146014', '12/08/1997', 'PEREMPUAN', 'MELAYU', 'Air Hitam, Melaka', 72, 72, 'BELIA', 'SAH', 'ABM040001', 0, '3be8ddaea5fef35eeecfac6cc84d060c', '2cfe7b7bc4e9f282e6e5a95625d045f0'),
('0039B', 'NURUL HASLINDA BINTI MOHAMMAD', '971025115264', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Ayer Keroh, Melaka', 73, 73, 'BELIA', 'SAH', 'ABM040001', 0, '86ed2816f4935e069bc948d33e42a5d3', '7dbefc0d3532ae7a9cb9372600ac4f2b'),
('0040B', 'NORAMIRA BINTI MOHD AFFANDI', '971028055470', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Jasin, Melaka', 74, 74, 'BELIA', 'SAH', 'ABM040001', 0, '0b682c10d384c640bcf6b33d644a8b52', 'eb1b243eb45543c80ee808c2bdc14077'),
('0041B', 'NUR SYAZWANI BINTI MAHADZIR', '960329025986', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Cheng, Melaka', 75, 75, 'BELIA', 'SAH', 'ABM040001', 0, 'e3ffbdf93a72033c835e33457a8e40a1', '12957e19f144f19e9958a5403d65767c'),
('0042B', 'NURUL NADIAH BINTI ZAINUDDIN', '960820026240', '01/01/1970', 'PEREMPUAN', 'MELAYU', 'Malim, Melaka', 76, 76, 'BELIA', 'SAH', 'ABM040001', 0, 'c21f39e5ca9197ed90f7d42335ca119a', '2483c4771769e3dbc05209f4175aae5e'),
('0043B', 'ARMILA AZIRA BINTI MOHD SHARIFF', '960911045066', '09/11/1996', 'PEREMPUAN', 'MELAYU', 'Air Pabas, Melaka', 77, 77, 'BELIA', 'SAH', 'ABM040001', 0, '18f39ae3ce93b9f84ba2d30373fb8925', 'f6c0a1f7625004e375972f535cdeb96b');

--
-- Triggers `member`
--
DELIMITER //
CREATE TRIGGER `trigDeleteMember` BEFORE DELETE ON `member`
 FOR EACH ROW BEGIN

      SET FOREIGN_KEY_CHECKS = 0;

       DELETE FROM `psm`.`email` WHERE emailID=old.emailID; 
     
       DELETE FROM `psm`.`contact` WHERE contactID=old.contactID; 
       
       DELETE FROM `psm`.`blacklist` WHERE memberID=old.memberID; 
       
       DELETE FROM `psm`.`total_warning` WHERE memberID=old.memberID; 
       
       DELETE FROM `psm`.`member_date_register` WHERE memberID=old.memberID; 
       
       DELETE FROM `psm`.`borrow` WHERE memberID=old.memberID; 
       
       DELETE FROM `psm`.`form` WHERE memberID=old.memberID; 
     
      SET FOREIGN_KEY_CHECKS = 1;
      
    END
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `trigMemberDateRegister` AFTER INSERT ON `member`
 FOR EACH ROW INSERT INTO member_date_register VALUES('', NOW(), NOW()+INTERVAL 1 YEAR, new.memberID)
//
DELIMITER ;
DELIMITER //
CREATE TRIGGER `trigUpdateMemberStatus` AFTER UPDATE ON `member`
 FOR EACH ROW BEGIN

      IF(old.memberStatus = 'TAMAT TEMPOH') THEN
         INSERT INTO member_date_register VALUES('', NOW(),  NOW()+INTERVAL 1 YEAR, new.memberID);

      ELSEIF(new.memberStatus = 'DALAM PROSES') THEN
    INSERT INTO form(formID, memberID, dateUpload, formStatus, formComment) VALUES('', old.memberID, NOW(), 'DALAM PROSES', '');
        
		ELSEIF(new.memberStatus = 'DALAM PINJAMAN') THEN
    INSERT INTO form(formID, memberID, dateUpload, formStatus, formComment) VALUES('', old.memberID, NOW(), 'DALAM PROSES', '');
      END IF;
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `member_date_register`
--

CREATE TABLE IF NOT EXISTS `member_date_register` (
`memberDateRegisterID` int(11) NOT NULL,
  `memberDateRegister` date DEFAULT NULL,
  `memberDateExpired` date DEFAULT NULL,
  `memberID` varchar(5) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=118 ;

--
-- Dumping data for table `member_date_register`
--

INSERT INTO `member_date_register` (`memberDateRegisterID`, `memberDateRegister`, `memberDateExpired`, `memberID`) VALUES
(16, '2017-05-06', '2018-05-06', '0001K'),
(17, '2017-05-06', '2018-05-06', '0002K'),
(18, '2017-05-06', '2018-05-06', '0003K'),
(19, '2017-05-06', '2018-05-06', '0004K'),
(20, '2017-05-06', '2018-05-06', '0005K'),
(21, '2017-05-06', '2018-05-06', '0006K'),
(22, '2017-05-06', '2018-05-06', '0007K'),
(23, '2017-05-06', '2018-05-06', '0008K'),
(24, '2017-05-06', '2018-05-06', '0009K'),
(26, '2017-05-06', '2018-05-06', '0010K'),
(27, '2017-05-06', '2018-05-06', '0011K'),
(28, '2017-05-06', '2018-05-06', '0012K'),
(29, '2017-05-06', '2018-05-06', '0013K'),
(30, '2017-05-06', '2018-05-06', '0014K'),
(31, '2017-05-06', '2018-05-06', '0015K'),
(33, '2017-05-06', '2018-05-06', '0017K'),
(34, '2017-05-06', '2018-05-06', '0018K'),
(35, '2017-05-06', '2018-05-06', '0019K'),
(36, '2017-05-06', '2018-05-06', '0020K'),
(37, '2017-05-06', '2018-05-06', '0021K'),
(38, '2017-05-06', '2018-05-06', '0022K'),
(39, '2017-05-06', '2018-05-06', '0023K'),
(40, '2017-05-06', '2018-05-06', '0024K'),
(41, '2017-05-06', '2018-05-06', '0025K'),
(42, '2017-05-06', '2018-05-06', '0026K'),
(43, '2017-05-06', '2018-05-06', '0027K'),
(44, '2017-05-06', '2018-05-06', '0028K'),
(45, '2017-05-06', '2018-05-06', '0029K'),
(46, '2017-05-06', '2018-05-06', '0030K'),
(47, '2017-05-06', '2018-05-06', '0031K'),
(48, '2017-05-06', '2018-05-06', '0032K'),
(49, '2017-05-06', '2018-05-06', '0033K'),
(52, '2017-05-06', '2018-05-06', '0001B'),
(53, '2017-05-06', '2018-05-06', '0002B'),
(54, '2017-05-06', '2018-05-06', '0003B'),
(55, '2017-05-06', '2018-05-06', '0004B'),
(56, '2017-05-06', '2018-05-06', '0005B'),
(57, '2017-05-06', '2018-05-06', '0006B'),
(58, '2017-05-06', '2018-05-06', '0007B'),
(59, '2017-05-06', '2018-05-06', '0008B'),
(60, '2017-05-06', '2018-05-06', '0009B'),
(61, '2017-05-06', '2018-05-06', '0010B'),
(62, '2017-05-06', '2018-05-06', '0011B'),
(63, '2017-05-06', '2018-05-06', '0012B'),
(64, '2017-05-06', '2018-05-06', '0013B'),
(65, '2017-05-06', '2018-05-06', '0014B'),
(66, '2017-05-06', '2018-05-06', '0015B'),
(67, '2017-05-06', '2018-05-06', '0016B'),
(68, '2017-05-06', '2018-05-06', '0017B'),
(69, '2017-05-06', '2018-05-06', '0018B'),
(70, '2017-05-06', '2018-05-06', '0019B'),
(71, '2017-05-06', '2018-05-06', '0020B'),
(72, '2017-05-06', '2018-05-06', '0021B'),
(73, '2017-05-06', '2018-05-06', '0022B'),
(74, '2017-05-06', '2018-05-06', '0023B'),
(75, '2017-05-06', '2018-05-06', '0024B'),
(76, '2017-05-06', '2018-05-06', '0025B'),
(77, '2017-05-06', '2018-05-06', '0026B'),
(78, '2017-05-06', '2018-05-06', '0027B'),
(79, '2017-05-06', '2018-05-06', '0028B'),
(80, '2017-05-06', '2018-05-06', '0029B'),
(81, '2017-05-06', '2018-05-06', '0030B'),
(82, '2017-05-06', '2018-05-06', '0031B'),
(83, '2017-05-06', '2018-05-06', '0032B'),
(84, '2017-05-06', '2018-05-06', '0033B'),
(85, '2017-05-06', '2018-05-06', '0034B'),
(86, '2017-05-06', '2018-05-06', '0035B'),
(87, '2017-05-06', '2018-05-06', '0036B'),
(88, '2017-05-06', '2018-05-06', '0037B'),
(89, '2017-05-06', '2018-05-06', '0038B'),
(90, '2017-05-06', '2018-05-06', '0039B'),
(91, '2017-05-06', '2018-05-06', '0040B'),
(92, '2017-05-06', '2018-05-06', '0041B'),
(93, '2017-05-06', '2018-05-06', '0042B'),
(94, '2017-05-07', '2018-05-07', '0043B'),
(95, '2017-05-07', '2018-05-07', '0001D'),
(96, '2017-05-07', '2018-05-07', '0002D'),
(97, '2017-05-07', '2018-05-07', '0003D'),
(98, '2017-05-07', '2018-05-07', '0004D'),
(99, '2017-05-07', '2018-05-07', '0005D'),
(100, '2017-05-07', '2018-05-07', '0006D'),
(101, '2017-05-07', '2018-05-07', '0007D'),
(102, '2017-05-07', '2018-05-07', '0008D'),
(104, '2017-05-07', '2018-05-07', '0009D'),
(105, '2017-05-07', '2018-05-07', '0010D'),
(106, '2017-05-08', '2018-05-08', '0011D'),
(107, '2017-05-08', '2018-05-08', '0012D'),
(108, '2017-05-08', '2018-05-08', '0013D'),
(109, '2017-05-08', '2018-05-08', '0014D'),
(113, '2017-05-13', '2018-05-13', '0001B'),
(114, '2017-05-15', '2018-05-15', '0015D'),
(115, '2017-05-15', '2018-05-15', '0016D'),
(116, '2017-05-15', '2018-05-15', '0017D'),
(117, '2017-05-16', '2018-05-16', '0018D');

-- --------------------------------------------------------

--
-- Table structure for table `member_statistic`
--

CREATE TABLE IF NOT EXISTS `member_statistic` (
`memberStatisticID` int(11) NOT NULL,
  `month` varchar(20) NOT NULL,
  `monthNum` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `totalMale` int(11) DEFAULT '0',
  `totalFemale` int(11) DEFAULT '0',
  `raceMelayu` int(11) DEFAULT '0',
  `raceCina` int(11) DEFAULT '0',
  `raceIndia` int(11) DEFAULT '0',
  `raceOther` int(11) DEFAULT '0',
  `adult` int(11) DEFAULT '0',
  `youth` int(11) DEFAULT '0',
  `kid` int(11) DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `member_statistic`
--

INSERT INTO `member_statistic` (`memberStatisticID`, `month`, `monthNum`, `year`, `totalMale`, `totalFemale`, `raceMelayu`, `raceCina`, `raceIndia`, `raceOther`, `adult`, `youth`, `kid`) VALUES
(2, 'May', 5, 2017, 28, 66, 81, 8, 4, 1, 18, 43, 33);

-- --------------------------------------------------------

--
-- Table structure for table `recovery_log`
--

CREATE TABLE IF NOT EXISTS `recovery_log` (
`recoveryLogID` int(11) NOT NULL,
  `tableBackup` varchar(50) NOT NULL,
  `backupDateTime` datetime NOT NULL,
  `descriptionBackup` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `staffID` varchar(9) NOT NULL,
  `staffIDEncrypt` varchar(50) NOT NULL,
  `staffName` varchar(50) NOT NULL,
  `staffContact` varchar(12) NOT NULL,
  `staffEmail` varchar(50) NOT NULL,
  `staffPosition` varchar(50) NOT NULL,
  `staffPassword` varchar(50) NOT NULL,
  `staffRowLevel` int(11) NOT NULL,
  `branchID` int(11) NOT NULL,
  `staffImg` blob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffID`, `staffIDEncrypt`, `staffName`, `staffContact`, `staffEmail`, `staffPosition`, `staffPassword`, `staffRowLevel`, `branchID`, `staffImg`) VALUES
('ABM040001', '841dac83908ed485d5eb998d96f24aad', 'Zakwan Shaj bin AHmad Jamal', '013-6707731', 'zakwan1211@gmail.com', 'Staff Kanan', '202cb962ac59075b964b07152d234b70', 2, 1, 0xffd8ffe000104a46494600010201000100010000ffe112534578696600004d4d002a000000080007011200030000000100010000011a00050000000100000062011b0005000000010000006a012800030000000100020000013100020000001c0000007201320002000000140000008e8769000400000001000000a4000000d00000271000002710000027100000271041646f62652050686f746f73686f70204353342057696e646f777300323031353a30383a31312031363a32313a35300000000003a001000300000001ffff0000a002000400000001000000a7a003000400000001000000be0000000000000006010300030000000100060000011a0005000000010000011e011b0005000000010000012601280003000000010002000002010004000000010000012e02020004000000010000111d0000000000000048000000010000004800000001ffd8ffe000104a46494600010200004800480000ffed000c41646f62655f434d0002ffee000e41646f626500648000000001ffdb0084000c08080809080c09090c110b0a0b11150f0c0c0f1518131315131318110c0c0c0c0c0c110c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c010d0b0b0d0e0d100e0e10140e0e0e14140e0e0e0e14110c0c0c0c0c11110c0c0c0c0c0c110c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0cffc000110800a0008d03012200021101031101ffdd00040009ffc4013f0000010501010101010100000000000000030001020405060708090a0b0100010501010101010100000000000000010002030405060708090a0b1000010401030204020507060805030c33010002110304211231054151611322718132061491a1b14223241552c16233347282d14307259253f0e1f163733516a2b283264493546445c2a3743617d255e265f2b384c3d375e3f3462794a485b495c4d4e4f4a5b5c5d5e5f55666768696a6b6c6d6e6f637475767778797a7b7c7d7e7f711000202010204040304050607070605350100021103213112044151617122130532819114a1b14223c152d1f0332462e1728292435315637334f1250616a2b283072635c2d2449354a317644555367465e2f2b384c3d375e3f34694a485b495c4d4e4f4a5b5c5d5e5f55666768696a6b6c6d6e6f62737475767778797a7b7c7ffda000c03010002110311003f00175cff00977a973fd2acee7f92a97ccfde7fbd5ceba7fcbbd4bff0d59ff7d5465523b9f32f6787f9ac7fdc87fd1653e67ef3fde97dff0079fef4d294a4bd7f99fbcff7a5f7fde7fbd3248297fbfef3fde97dff0079fef4c99cf6b04b881f14544d0b2594e9dfef3fde90f89fbcff007aaceea18ede0977c10bf6a339f4cc78a22123d1af3e739781a96588fab7e7e3f79fef4df33f79fef55e9cda6de3da7c0e88f33c20411b864c79b1e4178e625e457fbfef3fde9f5f13f79fef4c920c8afbfef3fde97ccfde7fbd3279494af99fbcff007a7110753c8ee7cfcd34a40e87e5fc51517fffd0075dff00977a97fe1ab3fefaa8abdd763f6ef52ffc3567fdf5503e2a91dcf997b2c3fcd63fee43fe8b24a54529419194aaf939b4d020b817f82abd4b3cd2ddac3a9d25613ef73c924c90a5863bd4b97cefc4c6291c78c094ba93d1d77f53c971fd110079a05bebbfdd7585d3f9a0acf194e1a9d42b0cb687366773bba9a300360e2e6e6f365f9e648ed7e96477341da1cdf9a2e1fa8f78dae2f6f7945a3230b68734e9c38774cf3e9585f4c6bc4774e60b4cf30482c8776846ab29c1b0643c720acdb9f73fdc3474c1254a9ca75b35d836dedfa27c610201dd74324a078a24c4f70edd192cb5bcc11a234acac776e0d2d304e9634e907c55dc7bf7cb0e8e6fe2a19e2ad43b9c87c538c8c59be63a467fbdfde6c4a52a29d44ebaf29c707e23f8a8a4383f11fc50417fffd1afd74ff977a97fe1ab3f82a3f1573ae9ff002ff53ffc3567f054a5523b9f32f6587f9ac7fdc8ff00d1528978683bb800c94e4c2a3d532995505bf9c7b2311c4682ce633c70e3964974dbc4b899977a96bf5d371da3c9570c7083e2931dbad2e3a92755ad81d36fcc786b5b23c559b110f29232c9332eb236e6d78f73fdad6947674acb6fbf690bb5e9fd02ba637365cb72ae9343c6d73442af2e6b5a0cb1e5fbbe5e31cb1d2eac89e4849b6beb701121be2bd332beaa62d8d9688958797f537de5a0e9e29d1e607541c1d8bc6db925e7f747649b797105da39bc3872b633bea9e554d2fabdc1bd973f635d4bcb1c36b9bc82a584e32d8b0ca128ee1d563ddb45c383a9f8a357796bf703af2a9e3e481535875ddcfc13b1cd73f43ab4e89ca068ded4efd760b181e3ba9caa382e782e63be89d40571569c6a443d4f239ce6c1199f987a65fe0b2948707e23f8a6984e0fb49f31fc535b45ffd2a5d7cff97fa9ff00e1ab3f82a60ab9f5887f97fa97fe1ab3f82ce05523b9f32f6387f9ac7fdc8ffd14d20ae67a85aeb2f2c267585d1832b96bcfa59cef538699852e1dcf939bf1abf6b1f6e255750af21ace64af46e8784ca319876fb9c355c031a4e4d3691fce3e47c17a362e4d78f8cdb6ce00000f9267344e8075727960353d9d566338ea06aaf63e28204e87bac53f59bd3602cab7c27c5fad8cb5fb6c6ec9e155f6e43567e20747a96e0fb4499085774fadda85429eb02d1a3f84aeeabe9b49dda27f146aa8a3865bdad91835ed22171ff58fea83725aebe81b2d1ae9dd6ce4fd6915d8435bb826ff009c2fbab24d3cf64202713c5134a970914757cbada6ec7b7d2b01696e9aa6aee2d70f19e574ff00597169c9c77e5d4ddaf69f705c989d27b2bd8e7c51b3bf56a64870c9dfc0c80f7b5b32e2355a33f82c3e93b9d972cfa2d1a95b5ca8b37cdf477fe100fddcf8c8b294e0e87e5fc54521c1f88fe2a3744bffd3a9f5807f977a97fe1ab3f82cb3cad8ebc27ae752ff00c3567fdf56558d82a94b73e65ec710fd563fee43fe8b1048593d6f0c3c8c960d4e8e1f916a030a37305d5963b49d5284b84db17358466c3381ed63fbce6521969c5074b292011e41763924b71d85c09680340b8b6b5cccaa98d1eff5345ea38b86db31981c24ed1f912e665f2979fc31a321d8bca7ed6b71ea7dc31cbebafe9361513d5bedbfacb2835560c1311a95d865748cf32da5ad7b1dd8c0fe0961fd5dcc7336e53595d3cec6c1fe098250adb5f35c632bdf473fa0d393976ed613f02acf5bc4c9c61a93f00ba1e99814e25cdf4c7923754c4aeeb36d9c10a227432f15fd6bc1f2cc8cdc8a9eeb4565edacfb801aabb8d9b9b938c32595398c1a06aebaefab8d702719e18e3c880650e8e89915902e76e03b0103f052fb90e1f9755bc12e2bbfa3cf64d36ddd3af2f641d8495c3d8790071a7dcbd8eec361a1d59021c22179566e1b6bea37d03e807483db55272d304c87d58f3409e1af26d744ac3714d9f9ce2b4820e2b43286b40803845994a46e44bd17290e0c108d550649c1d0fc47f15098481f69f88fe29acc5fffd4abd6ec07eb075369ff00b9567f0549ed90a7f589e59f58ba99ff00bb567e542aac0f6f2a91dcf997b0c06f163fee47fe8a074829a51ad64eaab910505e566e11baf6e437435192bb8e97d403eb68260c00b8da725d8e1fb5a1dbc41056b61d84319637494cc966afa6ce373183db9c8d692360bdce33da44f253e55876c0e4f758fd3f37da012afbef1754f6b4fba34f8a8bc1afe2daa76d3b5f63c79c953cac8c4b9c21e35d395c1e4e17587641bfd57b837f304c219c6ea19636bb7b437b89e53e8555e855a5df50f73538576164ee1d8a25b634364ac7e8ed7d387b721f2f07427952cdcc2c644fc130a4b1ea39eca58e20ea02e1f2b0ea36bad7cb8da771056af52c871adee27b68b2058f7805e64a9318ad436f92c4273e222c457100689e536898bf580a475594a707da7e23f8a8681487d13f11fc52517fffd5cdfac8c9ebfd4fff000d58b2ebb1d5ba3b2d7fac43fcbfd4ff00f0d59fc164dac2750a91dcf997aec5fcd633fd48ff00d16db5e1ed43b19dd029b483055924109328361aa4f62b4ba4647a98db5df4985675add5471b21d8f66e1c1e420458a6a7378cce34371abd463e4ec43b3ab67536ee650e7d3dcb554aacdfb48d0396ce3871a3d28e7ba87407516e4c81bad9aadeb7d5ecfe670dc1a99dd53ab96eff00b3398d1d82778ea98ee3e87b9bf04cd7f57bdd160dadf82938b1d6cb87056b6d57751eb5924b1b57a6deee23b231cbb5cc0db1d2472ad3d8faabd9dcf2565587de40d4a6120ec2967545d4ae06bd80fd25443b44d9961fb53ab27568e3c90c3a7852445075b93118e3d0d93ba52e2521e499aa69cdb504e1da1f88fe2a24a43e89f88fe2828bffd6a1f580ff0097fa9ffe1ab3f82cd70d15ff00ac27fec87a9ffe1ab3f2acf9548ee7ccbd7613faac7fdc8ffd16bbda5ae945aeed20a4f6c84314d8dacdef05b48e1d1a4a22249a01665cd0c238a72118a5b1c089e00ee80cd9607b9a6768253f4dc3bba9e4d8fb24626237d4b3c08fa309bd279f58d7ed0340dfe4953470d6a5c9e67e2a660c7103107f4cfccec619f570ea7fe716f2afe3752750d0db04c70573fd13376b5f896e85a6584f82d6dcd8d75557246a441eec109f144175d9d7aa848f5dabb05856541df453d54ed32ee147c217596fe4f50b2e0430413dd546571a9e54838048380d652538bd58ba9ea6cb59126bd41e0ebdd2c82d6398fada763fe90f02879b61bfab10350d6401f35b77e353674dc2c9608de5ed7fc5ba2bd8b1838e225d9807359316494b1cabc3a398c32d909cb93e553761d55e757ad04fa768f077291f49ff00a461d2248f8f8212c047cbaba7cbfc5e12a8e61c07f787c8c46aa607b4fcbf8a76b1c5bb99ee1e5cfdc983c411de469dfba8a8dd56ae90cb030331206205f15e94ff00ffd7ccfac71ff387a99ffbb567e559ce706377bb46f8ad8fac15329fac7d43d51baeb326c7d759e3698dafdcb35d436e6deeb5dfa48f68f081c4282384c8927416ede5f8a4316384318e3988c75fd08fa5b0de9198cc6a3372585b8b906293e32256a3e965ff00527a8e2ed05f876d6e6bfbc38ee44659f68fa8f464349270af2d78e60010a9e3e5b1bd3733178399b4b478c0562300010038d9b3e4cb3e2c92323fcb665d3f1ce17d55de0459d42e2c3e26b2377fdf554a3a735f879f9966956206b43878b81dab63a986d58bd3718003d0c56bdc3f9524207d60ace07d55c3e9c34c8ea367a9778c35d2cffaa44b18788b4bea356432647d3f82d8c6cf16341250b2286b9efa8c35a1bb67c4acea83e976c3a6aabe6802cf8a55a3d1b1c1c241536eeeeb2aab5ed132adb721e5bcaa928d36416cd8f6b7baa9765c080a363dc78d535587758f0f734860d494631162d6c8e8d1c36bbed365e4490eda02e93a530e4f44ccc7226dc1735ec1e561dce5955b1a6bb5cd1a39d0b67eacdd5d1d69b4d9fcc750add5ba7f79ad867fd25a31140783489b25274ec4afa83323a4bb56e5d65f4cf1ea9f6b566fd53e9b1f594616657ead2d65adda7f7ab6bbc7f941686cbba664cf17f4eb377c48d53fd6d3774feb185d5fa78f6665676edfdf70fd3ffd522501cdb31ccbaec79adce71dac1e1fca578741ea3fb44f4fd957db7d1191be3d9b76b9ff00e7a863b66dc63f9ce78dedf8a00eb37ffce87666f3cb689ed1ee642463126cf45f0cb388908c8812044803a10fffd06faf2e6dbd4dfd458ddaca321d896bc78b0076e72c51b45f27f387df2babbafc3775beabd2f399385d4721f539d1f41fa1f5972b9b839bd3b32ce9f940badc670f4ec0347b0ead23faac4ed8f9adbb6ef41ca2ce9dd5fa5bb56b986c60f3242a7915d8eb3a70fa20dac0e1e5b9aaff00d5ea059f58bd23f4326900c8893caa4e2cc5c96db924fa58b6b8ba0127477b60228eaecf567b6cea8fadd15d6d77a5bddc068f72c8fae5f59716febbfabfe9a9c4adacaa3e8ced01dff49ab9deb59f9bd4f2722f66f6e3bad2eac411a79a5998570b587d370f51820c1d60204ae41d47272ecaebc927617bb706b7895670f331f23f9c064409f3f357eec1177d54f598c77ab8d9043f43f440580eaeea5ccbeb690d747629921c428ae8ca8d87ad662d6fada5bac8d149bd39c7843c27d95dd4d364bbd7ac59598d0498d8b6aa65911b4cfc151c9194254db8484c5b5717a7d6cf75a741c92b60e1319d39f7b1bb8106079051c7c175cf6b5e3da3528d91d731acccafa46230bab15bfd6ba080081f45aa5e571991e33b063e627438475dde22ecafb2631c8789a8dfb6073108d4e532da99938aedcfc6b1b608e409dce557abe33bec25e1a768be1bcf10a9f48c2c87d19b92c6b83296ea75eeaddb59f40eb86ac8bb1baab3f98ea3507be38f50e9b536f764fd5d3ecf56ee8ee73c34ebedb4ff00df5713d3feb6f51c7e90ce9b9149c8c76d9ea56e320b08f6c085d07d58faddd36bea05b901f5d392c35e402d31a8dac28de88ad5874dc8658ebf2de4815b4dac078d163fbbec87263ddeb8b27ca772b790dfb2db9d878af175277065c3e8ed3aed42f499f61357ba206906660a2a7fffd9ffed173050686f746f73686f7020332e30003842494d0425000000000010000000000000000000000000000000003842494d03ed000000000010000100000001000100010000000100013842494d042600000000000e000000000000000000003f8000003842494d040d000000000004000000783842494d04190000000000040000001e3842494d03f3000000000009000000000000000001003842494d271000000000000a000100000000000000023842494d03f5000000000048002f66660001006c66660006000000000001002f6666000100a1999a0006000000000001003200000001005a00000006000000000001003500000001002d000000060000000000013842494d03f80000000000700000ffffffffffffffffffffffffffffffffffffffffffff03e800000000ffffffffffffffffffffffffffffffffffffffffffff03e800000000ffffffffffffffffffffffffffffffffffffffffffff03e800000000ffffffffffffffffffffffffffffffffffffffffffff03e800003842494d040000000000000200013842494d0402000000000004000000003842494d043000000000000201013842494d042d0000000000060001000000023842494d0408000000000010000000010000024000000240000000003842494d041e000000000004000000003842494d041a000000000349000000060000000000000000000000be000000a70000000a0055006e007400690074006c00650064002d00310000000100000000000000000000000000000000000000010000000000000000000000a7000000be00000000000000000000000000000000010000000000000000000000000000000000000010000000010000000000006e756c6c0000000200000006626f756e64734f626a6300000001000000000000526374310000000400000000546f70206c6f6e6700000000000000004c6566746c6f6e67000000000000000042746f6d6c6f6e67000000be00000000526768746c6f6e67000000a700000006736c69636573566c4c73000000014f626a6300000001000000000005736c6963650000001200000007736c69636549446c6f6e67000000000000000767726f757049446c6f6e6700000000000000066f726967696e656e756d0000000c45536c6963654f726967696e0000000d6175746f47656e6572617465640000000054797065656e756d0000000a45536c6963655479706500000000496d672000000006626f756e64734f626a6300000001000000000000526374310000000400000000546f70206c6f6e6700000000000000004c6566746c6f6e67000000000000000042746f6d6c6f6e67000000be00000000526768746c6f6e67000000a70000000375726c54455854000000010000000000006e756c6c54455854000000010000000000004d7367655445585400000001000000000006616c74546167544558540000000100000000000e63656c6c54657874497348544d4c626f6f6c010000000863656c6c546578745445585400000001000000000009686f727a416c69676e656e756d0000000f45536c696365486f727a416c69676e0000000764656661756c740000000976657274416c69676e656e756d0000000f45536c69636556657274416c69676e0000000764656661756c740000000b6267436f6c6f7254797065656e756d0000001145536c6963654247436f6c6f7254797065000000004e6f6e6500000009746f704f75747365746c6f6e67000000000000000a6c6566744f75747365746c6f6e67000000000000000c626f74746f6d4f75747365746c6f6e67000000000000000b72696768744f75747365746c6f6e6700000000003842494d042800000000000c000000023ff00000000000003842494d041100000000000101003842494d0414000000000004000000023842494d040c000000001139000000010000008d000000a0000001a8000109000000111d00180001ffd8ffe000104a46494600010200004800480000ffed000c41646f62655f434d0002ffee000e41646f626500648000000001ffdb0084000c08080809080c09090c110b0a0b11150f0c0c0f1518131315131318110c0c0c0c0c0c110c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c010d0b0b0d0e0d100e0e10140e0e0e14140e0e0e0e14110c0c0c0c0c11110c0c0c0c0c0c110c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0cffc000110800a0008d03012200021101031101ffdd00040009ffc4013f0000010501010101010100000000000000030001020405060708090a0b0100010501010101010100000000000000010002030405060708090a0b1000010401030204020507060805030c33010002110304211231054151611322718132061491a1b14223241552c16233347282d14307259253f0e1f163733516a2b283264493546445c2a3743617d255e265f2b384c3d375e3f3462794a485b495c4d4e4f4a5b5c5d5e5f55666768696a6b6c6d6e6f637475767778797a7b7c7d7e7f711000202010204040304050607070605350100021103213112044151617122130532819114a1b14223c152d1f0332462e1728292435315637334f1250616a2b283072635c2d2449354a317644555367465e2f2b384c3d375e3f34694a485b495c4d4e4f4a5b5c5d5e5f55666768696a6b6c6d6e6f62737475767778797a7b7c7ffda000c03010002110311003f00175cff00977a973fd2acee7f92a97ccfde7fbd5ceba7fcbbd4bff0d59ff7d5465523b9f32f6787f9ac7fdc87fd1653e67ef3fde97dff0079fef4d294a4bd7f99fbcff7a5f7fde7fbd3248297fbfef3fde97dff0079fef4c99cf6b04b881f14544d0b2594e9dfef3fde90f89fbcff007aaceea18ede0977c10bf6a339f4cc78a22123d1af3e739781a96588fab7e7e3f79fef4df33f79fef55e9cda6de3da7c0e88f33c20411b864c79b1e4178e625e457fbfef3fde9f5f13f79fef4c920c8afbfef3fde97ccfde7fbd3279494af99fbcff007a7110753c8ee7cfcd34a40e87e5fc51517fffd0075dff00977a97fe1ab3fefaa8abdd763f6ef52ffc3567fdf5503e2a91dcf997b2c3fcd63fee43fe8b24a54529419194aaf939b4d020b817f82abd4b3cd2ddac3a9d25613ef73c924c90a5863bd4b97cefc4c6291c78c094ba93d1d77f53c971fd110079a05bebbfdd7585d3f9a0acf194e1a9d42b0cb687366773bba9a300360e2e6e6f365f9e648ed7e96477341da1cdf9a2e1fa8f78dae2f6f7945a3230b68734e9c38774cf3e9585f4c6bc4774e60b4cf30482c8776846ab29c1b0643c720acdb9f73fdc3474c1254a9ca75b35d836dedfa27c610201dd74324a078a24c4f70edd192cb5bcc11a234acac776e0d2d304e9634e907c55dc7bf7cb0e8e6fe2a19e2ad43b9c87c538c8c59be63a467fbdfde6c4a52a29d44ebaf29c707e23f8a8a4383f11fc50417fffd1afd74ff977a97fe1ab3f82a3f1573ae9ff002ff53ffc3567f054a5523b9f32f6587f9ac7fdc8ff00d1528978683bb800c94e4c2a3d532995505bf9c7b2311c4682ce633c70e3964974dbc4b899977a96bf5d371da3c9570c7083e2931dbad2e3a92755ad81d36fcc786b5b23c559b110f29232c9332eb236e6d78f73fdad6947674acb6fbf690bb5e9fd02ba637365cb72ae9343c6d73442af2e6b5a0cb1e5fbbe5e31cb1d2eac89e4849b6beb701121be2bd332beaa62d8d9688958797f537de5a0e9e29d1e607541c1d8bc6db925e7f747649b797105da39bc3872b633bea9e554d2fabdc1bd973f635d4bcb1c36b9bc82a584e32d8b0ca128ee1d563ddb45c383a9f8a357796bf703af2a9e3e481535875ddcfc13b1cd73f43ab4e89ca068ded4efd760b181e3ba9caa382e782e63be89d40571569c6a443d4f239ce6c1199f987a65fe0b2948707e23f8a6984e0fb49f31fc535b45ffd2a5d7cff97fa9ff00e1ab3f82a60ab9f5887f97fa97fe1ab3f82ce05523b9f32f6387f9ac7fdc8ffd14d20ae67a85aeb2f2c267585d1832b96bcfa59cef538699852e1dcf939bf1abf6b1f6e255750af21ace64af46e8784ca319876fb9c355c031a4e4d3691fce3e47c17a362e4d78f8cdb6ce00000f9267344e8075727960353d9d566338ea06aaf63e28204e87bac53f59bd3602cab7c27c5fad8cb5fb6c6ec9e155f6e43567e20747a96e0fb4499085774fadda85429eb02d1a3f84aeeabe9b49dda27f146aa8a3865bdad91835ed22171ff58fea83725aebe81b2d1ae9dd6ce4fd6915d8435bb826ff009c2fbab24d3cf64202713c5134a970914757cbada6ec7b7d2b01696e9aa6aee2d70f19e574ff00597169c9c77e5d4ddaf69f705c989d27b2bd8e7c51b3bf56a64870c9dfc0c80f7b5b32e2355a33f82c3e93b9d972cfa2d1a95b5ca8b37cdf477fe100fddcf8c8b294e0e87e5fc54521c1f88fe2a3744bffd3a9f5807f977a97fe1ab3f82cb3cad8ebc27ae752ff00c3567fdf56558d82a94b73e65ec710fd563fee43fe8b1048593d6f0c3c8c960d4e8e1f916a030a37305d5963b49d5284b84db17358466c3381ed63fbce6521969c5074b292011e41763924b71d85c09680340b8b6b5cccaa98d1eff5345ea38b86db31981c24ed1f912e665f2979fc31a321d8bca7ed6b71ea7dc31cbebafe9361513d5bedbfacb2835560c1311a95d865748cf32da5ad7b1dd8c0fe0961fd5dcc7336e53595d3cec6c1fe098250adb5f35c632bdf473fa0d393976ed613f02acf5bc4c9c61a93f00ba1e99814e25cdf4c7923754c4aeeb36d9c10a227432f15fd6bc1f2cc8cdc8a9eeb4565edacfb801aabb8d9b9b938c32595398c1a06aebaefab8d702719e18e3c880650e8e89915902e76e03b0103f052fb90e1f9755bc12e2bbfa3cf64d36ddd3af2f641d8495c3d8790071a7dcbd8eec361a1d59021c22179566e1b6bea37d03e807483db55272d304c87d58f3409e1af26d744ac3714d9f9ce2b4820e2b43286b40803845994a46e44bd17290e0c108d550649c1d0fc47f15098481f69f88fe29acc5fffd4abd6ec07eb075369ff00b9567f0549ed90a7f589e59f58ba99ff00bb567e542aac0f6f2a91dcf997b0c06f163fee47fe8a074829a51ad64eaab910505e566e11baf6e437435192bb8e97d403eb68260c00b8da725d8e1fb5a1dbc41056b61d84319637494cc966afa6ce373183db9c8d692360bdce33da44f253e55876c0e4f758fd3f37da012afbef1754f6b4fba34f8a8bc1afe2daa76d3b5f63c79c953cac8c4b9c21e35d395c1e4e17587641bfd57b837f304c219c6ea19636bb7b437b89e53e8555e855a5df50f73538576164ee1d8a25b634364ac7e8ed7d387b721f2f07427952cdcc2c644fc130a4b1ea39eca58e20ea02e1f2b0ea36bad7cb8da771056af52c871adee27b68b2058f7805e64a9318ad436f92c4273e222c457100689e536898bf580a475594a707da7e23f8a8681487d13f11fc52517fffd5cdfac8c9ebfd4fff000d58b2ebb1d5ba3b2d7fac43fcbfd4ff00f0d59fc164dac2750a91dcf997aec5fcd633fd48ff00d16db5e1ed43b19dd029b483055924109328361aa4f62b4ba4647a98db5df4985675add5471b21d8f66e1c1e420458a6a7378cce34371abd463e4ec43b3ab67536ee650e7d3dcb554aacdfb48d0396ce3871a3d28e7ba87407516e4c81bad9aadeb7d5ecfe670dc1a99dd53ab96eff00b3398d1d82778ea98ee3e87b9bf04cd7f57bdd160dadf82938b1d6cb87056b6d57751eb5924b1b57a6deee23b231cbb5cc0db1d2472ad3d8faabd9dcf2565587de40d4a6120ec2967545d4ae06bd80fd25443b44d9961fb53ab27568e3c90c3a7852445075b93118e3d0d93ba52e2521e499aa69cdb504e1da1f88fe2a24a43e89f88fe2828bffd6a1f580ff0097fa9ffe1ab3f82cd70d15ff00ac27fec87a9ffe1ab3f2acf9548ee7ccbd7613faac7fdc8ffd16bbda5ae945aeed20a4f6c84314d8dacdef05b48e1d1a4a22249a01665cd0c238a72118a5b1c089e00ee80cd9607b9a6768253f4dc3bba9e4d8fb24626237d4b3c08fa309bd279f58d7ed0340dfe4953470d6a5c9e67e2a660c7103107f4cfccec619f570ea7fe716f2afe3752750d0db04c70573fd13376b5f896e85a6584f82d6dcd8d75557246a441eec109f144175d9d7aa848f5dabb05856541df453d54ed32ee147c217596fe4f50b2e0430413dd546571a9e54838048380d652538bd58ba9ea6cb59126bd41e0ebdd2c82d6398fada763fe90f02879b61bfab10350d6401f35b77e353674dc2c9608de5ed7fc5ba2bd8b1838e225d9807359316494b1cabc3a398c32d909cb93e553761d55e757ad04fa768f077291f49ff00a461d2248f8f8212c047cbaba7cbfc5e12a8e61c07f787c8c46aa607b4fcbf8a76b1c5bb99ee1e5cfdc983c411de469dfba8a8dd56ae90cb030331206205f15e94ff00ffd7ccfac71ff387a99ffbb567e559ce706377bb46f8ad8fac15329fac7d43d51baeb326c7d759e3698dafdcb35d436e6deeb5dfa48f68f081c4282384c8927416ede5f8a4316384318e3988c75fd08fa5b0de9198cc6a3372585b8b906293e32256a3e965ff00527a8e2ed05f876d6e6bfbc38ee44659f68fa8f464349270af2d78e60010a9e3e5b1bd3733178399b4b478c0562300010038d9b3e4cb3e2c92323fcb665d3f1ce17d55de0459d42e2c3e26b2377fdf554a3a735f879f9966956206b43878b81dab63a986d58bd3718003d0c56bdc3f9524207d60ace07d55c3e9c34c8ea367a9778c35d2cffaa44b18788b4bea356432647d3f82d8c6cf16341250b2286b9efa8c35a1bb67c4acea83e976c3a6aabe6802cf8a55a3d1b1c1c241536eeeeb2aab5ed132adb721e5bcaa928d36416cd8f6b7baa9765c080a363dc78d535587758f0f734860d494631162d6c8e8d1c36bbed365e4490eda02e93a530e4f44ccc7226dc1735ec1e561dce5955b1a6bb5cd1a39d0b67eacdd5d1d69b4d9fcc750add5ba7f79ad867fd25a31140783489b25274ec4afa83323a4bb56e5d65f4cf1ea9f6b566fd53e9b1f594616657ead2d65adda7f7ab6bbc7f941686cbba664cf17f4eb377c48d53fd6d3774feb185d5fa78f6665676edfdf70fd3ffd522501cdb31ccbaec79adce71dac1e1fca578741ea3fb44f4fd957db7d1191be3d9b76b9ff00e7a863b66dc63f9ce78dedf8a00eb37ffce87666f3cb689ed1ee642463126cf45f0cb388908c8812044803a10fffd06faf2e6dbd4dfd458ddaca321d896bc78b0076e72c51b45f27f387df2babbafc3775beabd2f399385d4721f539d1f41fa1f5972b9b839bd3b32ce9f940badc670f4ec0347b0ead23faac4ed8f9adbb6ef41ca2ce9dd5fa5bb56b986c60f3242a7915d8eb3a70fa20dac0e1e5b9aaff00d5ea059f58bd23f4326900c8893caa4e2cc5c96db924fa58b6b8ba0127477b60228eaecf567b6cea8fadd15d6d77a5bddc068f72c8fae5f59716febbfabfe9a9c4adacaa3e8ced01dff49ab9deb59f9bd4f2722f66f6e3bad2eac411a79a5998570b587d370f51820c1d60204ae41d47272ecaebc927617bb706b7895670f331f23f9c064409f3f357eec1177d54f598c77ab8d9043f43f440580eaeea5ccbeb690d747629921c428ae8ca8d87ad662d6fada5bac8d149bd39c7843c27d95dd4d364bbd7ac59598d0498d8b6aa65911b4cfc151c9194254db8484c5b5717a7d6cf75a741c92b60e1319d39f7b1bb8106079051c7c175cf6b5e3da3528d91d731acccafa46230bab15bfd6ba080081f45aa5e571991e33b063e627438475dde22ecafb2631c8789a8dfb6073108d4e532da99938aedcfc6b1b608e409dce557abe33bec25e1a768be1bcf10a9f48c2c87d19b92c6b83296ea75eeaddb59f40eb86ac8bb1baab3f98ea3507be38f50e9b536f764fd5d3ecf56ee8ee73c34ebedb4ff00df5713d3feb6f51c7e90ce9b9149c8c76d9ea56e320b08f6c085d07d58faddd36bea05b901f5d392c35e402d31a8dac28de88ad5874dc8658ebf2de4815b4dac078d163fbbec87263ddeb8b27ca772b790dfb2db9d878af175277065c3e8ed3aed42f499f61357ba206906660a2a7fffd9003842494d042100000000005500000001010000000f00410064006f00620065002000500068006f0074006f00730068006f00700000001300410064006f00620065002000500068006f0074006f00730068006f0070002000430053003400000001003842494d04060000000000070004010100010100ffe11106687474703a2f2f6e732e61646f62652e636f6d2f7861702f312e302f003c3f787061636b657420626567696e3d22efbbbf222069643d2257354d304d7043656869487a7265537a4e54637a6b633964223f3e203c783a786d706d65746120786d6c6e733a783d2261646f62653a6e733a6d6574612f2220783a786d70746b3d2241646f626520584d5020436f726520342e322e322d633036332035332e3335323632342c20323030382f30372f33302d31383a31323a31382020202020202020223e203c7264663a52444620786d6c6e733a7264663d22687474703a2f2f7777772e77332e6f72672f313939392f30322f32322d7264662d73796e7461782d6e7323223e203c7264663a4465736372697074696f6e207264663a61626f75743d222220786d6c6e733a786d703d22687474703a2f2f6e732e61646f62652e636f6d2f7861702f312e302f2220786d6c6e733a786d704d4d3d22687474703a2f2f6e732e61646f62652e636f6d2f7861702f312e302f6d6d2f2220786d6c6e733a73744576743d22687474703a2f2f6e732e61646f62652e636f6d2f7861702f312e302f73547970652f5265736f757263654576656e74232220786d6c6e733a64633d22687474703a2f2f7075726c2e6f72672f64632f656c656d656e74732f312e312f2220786d6c6e733a70686f746f73686f703d22687474703a2f2f6e732e61646f62652e636f6d2f70686f746f73686f702f312e302f2220786d6c6e733a746966663d22687474703a2f2f6e732e61646f62652e636f6d2f746966662f312e302f2220786d6c6e733a657869663d22687474703a2f2f6e732e61646f62652e636f6d2f657869662f312e302f2220786d703a43726561746f72546f6f6c3d2241646f62652050686f746f73686f70204353342057696e646f77732220786d703a4d65746164617461446174653d22323031352d30382d31315431363a32313a35302b30383a30302220786d703a4d6f64696679446174653d22323031352d30382d31315431363a32313a35302b30383a30302220786d703a437265617465446174653d22323031352d30382d31315431363a32313a35302b30383a30302220786d704d4d3a496e7374616e636549443d22786d702e6969643a43304344333230343032343045353131413536444644373343334238364641342220786d704d4d3a446f63756d656e7449443d22786d702e6469643a42464344333230343032343045353131413536444644373343334238364641342220786d704d4d3a4f726967696e616c446f63756d656e7449443d22786d702e6469643a4246434433323034303234304535313141353644464437334333423836464134222064633a666f726d61743d22696d6167652f6a706567222070686f746f73686f703a436f6c6f724d6f64653d22332220746966663a4f7269656e746174696f6e3d22312220746966663a585265736f6c7574696f6e3d2231303030302f31303030302220746966663a595265736f6c7574696f6e3d2231303030302f31303030302220746966663a5265736f6c7574696f6e556e69743d22322220746966663a4e61746976654469676573743d223235362c3235372c3235382c3235392c3236322c3237342c3237372c3238342c3533302c3533312c3238322c3238332c3239362c3330312c3331382c3331392c3532392c3533322c3330362c3237302c3237312c3237322c3330352c3331352c33333433323b30413446373733384634464337414632314234303330373033453031393839352220657869663a506978656c5844696d656e73696f6e3d223136372220657869663a506978656c5944696d656e73696f6e3d223139302220657869663a436f6c6f7253706163653d2236353533352220657869663a4e61746976654469676573743d2233363836342c34303936302c34303936312c33373132312c33373132322c34303936322c34303936332c33373531302c34303936342c33363836372c33363836382c33333433342c33333433372c33343835302c33343835322c33343835352c33343835362c33373337372c33373337382c33373337392c33373338302c33373338312c33373338322c33373338332c33373338342c33373338352c33373338362c33373339362c34313438332c34313438342c34313438362c34313438372c34313438382c34313439322c34313439332c34313439352c34313732382c34313732392c34313733302c34313938352c34313938362c34313938372c34313938382c34313938392c34313939302c34313939312c34313939322c34313939332c34313939342c34313939352c34313939362c34323031362c302c322c342c352c362c372c382c392c31302c31312c31322c31332c31342c31352c31362c31372c31382c32302c32322c32332c32342c32352c32362c32372c32382c33303b3630453943463946354636463436343833304633314344394134364143464532223e203c786d704d4d3a486973746f72793e203c7264663a5365713e203c7264663a6c692073744576743a616374696f6e3d2263726561746564222073744576743a696e7374616e636549443d22786d702e6969643a4246434433323034303234304535313141353644464437334333423836464134222073744576743a7768656e3d22323031352d30382d31315431363a32313a35302b30383a3030222073744576743a736f6674776172654167656e743d2241646f62652050686f746f73686f70204353342057696e646f7773222f3e203c7264663a6c692073744576743a616374696f6e3d227361766564222073744576743a696e7374616e636549443d22786d702e6969643a4330434433323034303234304535313141353644464437334333423836464134222073744576743a7768656e3d22323031352d30382d31315431363a32313a35302b30383a3030222073744576743a736f6674776172654167656e743d2241646f62652050686f746f73686f70204353342057696e646f7773222073744576743a6368616e6765643d222f222f3e203c2f7264663a5365713e203c2f786d704d4d3a486973746f72793e203c2f7264663a4465736372697074696f6e3e203c2f7264663a5244463e203c2f783a786d706d6574613e2020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020203c3f787061636b657420656e643d2277223f3effee002141646f62650064000000000103001003020306000000000000000000000000ffdb0084000604040405040605050609060506090b080606080b0c0a0a0b0a0a0c100c0c0c0c0c0c100c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c010707070d0c0d18101018140e0e0e14140e0e0e0e14110c0c0c0c0c11110c0c0c0c0c0c110c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0cffc200110800be00a703011100021101031101ffc400c6000002020301010000000000000000000005060304000102070801000203010101000000000000000000000001020304050607100001040201040005030303050000000001000203041105061021120720313213344122273014244016372315261708110002010204010807060502070000000001020011032131120441105161712232130581b1d192b21406209142722374a1c15233646282e1a253243415251200010303050100020300000000000000010011212030031040310272122232516142ffda000c03010102110311000000d72bea8b95f47030368e43618cd868311b0c0c0c662303034cc0eda3d3e72dd7d2d86d181a16c31983c23195452ae757771b341b0c0d336181d08ed9cf5bafa3b4606060b4d5296219771c468f3d56ce7db74908e8339fd05dcdeafb86ac0c6f0312e987ace7ad57d0d8f058159e454d5e48568f3f6279b42902e0461642cc369ec5ee2c51ddc66060fa4986ce7ad43a3c25b089d485bbe7ebfa387c8ad34400aa2b8570e00c9220ac39cffa1cd576b0303a4982dc0b55f4341ca42ece679af4be6bc4aa9e332d4db24650db5c13aab35b0303b4a456bea30f3be8db56e33607ace7aed7d0d27c3ad277fcfd5b4705933dfe97cddcf996f236456ee8a6d95295f4a4edc651aba16958d9cffa1daa7b581d346ace7aed7d1ed3196f23ce3a7f35920fdf789d779c5a0a81fbaab7a2b155cc267b7c6b765f1dec72f7281826e387dbdecfe9f07d88ccf9eb35ef9060afe1a6f47e77729b7e95f3fdb6b51b524666ad5b1ab5cc1d32a92878d6ba7c53b1cb981db17b53d97d4ed9d0986cc0a356fdb29cf0f9bf53e66d14bf6ae275e95b5d36ae42c75a6d08d2468a0a8ba8cfc73abcc0d7d5e89cefa315abaf88e9a69b70a751ba271ec13b7789bd3e0fb270faab9aea5ad594d63d5edf92c446fcd3a598b1167c3afcaba3cf51d6fd339bf4b955ba0e84e176351a77d155e054b394135785fa8f83d3af38d3b53251633e8a0365d02ac8d168952fc63a19fce37ee6bc9ed364f41d4469bb002aba74142b11dca8d4bc57b4f366eaa04ec42e1617d1453a6dad095c505f1f92e9b94747ac95eac0c476d17b39a32beaca98d75c4448d7c568a386fb5d4d4a4916344b6be93f55cf39e2916c481a7b956cf41b468303b61cb39ca51dc615dc05055c0e96fcfe4d929cc448c932a5928c2ac6b9ea90795897abd576743894749c8391264bb02657b7422c5d5c88c79c8c384d99b917d57574596eed70463d66c63e20a9f440e8f4dd96f43913e878e2d766152af78e29b6e775583ca69bc8dd4f9a6aa333054c6ccb112ab4a372017dc3eef43257d2b25bb0e43a06ab30ab55d0aceba45371d90cf1c7abca3161ca672dd6d12a7a153646805a6a13d9e74347708e4f531d7bba1ce360b39eb35f4342ab2c716df25675702a108b1ea7de474b43a8cb31270d249dbb23175f9b14e019593e6ef778fd5f34f4586cc0b10dd368e115e878c332c64249694bce6b91de574587268b4a72c546d5094547ab81ab6e46d9c2200f19c5272e6eb11c9e9d635f9b71d1c6a72a8e0e71c2a5e4f0607269379351ccf75eaa43ec80dbabb5d4e6cf7d7e9ad4a24c2524a1794c8556a15b45e1b3288c7232cd465e4e81f9af2fcfdd7a9b658b2111a2ea143b7caea69f862a5031192b388a53f504bc8191b4ea2ac4975b4cae5cc0591fa262d4ebcbe8918bba0f7dce3787eba7cd53f4d077b204a2fce44153f62b60a344956d4fa84925e5754d8145c99e6a48ba3d1f8dd568cba4ee8cd4fd171d22b7e37091c0dd8bd41a04ca28ffda00080102000105009bebff00418eb9537d7f0e3e000af0288282c74c7c337d7d33d33d1ad2536b929b03420d03a18c14fae9cd23e2ca9bebf81adca640834043e1c27303949091f14df5e3a850b30b0b0b1f1b8654ccc1eb8537d79eb18c968c2ca2fc2758010b013650503f0c8cc870c1cf59beb45050c7819524b852592519329ae41e8582132d829ae0463a614cdc1eb37d68a886480a4381625c92e4131a4a0c29e0af355adf896481dd6c7cfacdf5f483e6a63fb64ee4444a31151c85a9d613a4cafb795f68855e42d2d390ac7cd67a4ff5aca8df820e44df481dcbf083f28b5109a13512517aaeecb4a95d93d66fafac327698fed07bb1cd59662520219298eef1bda14b2b54920549e087bb00fcf0b1d26fac8eac38321fd8e3ddae5e584e712a009e3bb1e539e89549d832bfa0e99537d7d074749d9cd402cf60142e0d4ff9f4c284f8af2256567acdf5fc0e6e53822894cc2382b20271e80263475c74054df58f80291b82535995f64a6c453a128c042f14101db1d0f59bebf80291b945ab24264d95e413a4013e52504c6fc737d63ae7a01952b705c1657dc28bca685f215c0717c647c537d6b1d309b192a2870ae0c3b2bc015f6d7db5f244aabf516029f5427c65bf04df5f46b09515708300442b51f90231d4f4c2a6cefd0b414fac0a7c2e6f49beb51d72547100b1dd109c322687b96e3a1e8d66555663a7e8bf5735181a4be32e7c758040766a23ba2885204f6273178a013542ded84d4514e2863006084137b2ca1d09530523d79e512117aaec2f735b818e856328a29c3f6b0e53ba92022e44f4b15f28f65943baab1788283967282f91fd4fcdbf21f37743f09c2b41b955837ca3c61e8a0879228a0bffda0008010300010500d47e27fa32b51f89fd024274ec6afefa24d998efe815a8fc4eb9e84e14db08a356b9131a27de4cf2fb523d7dd2a1bf24669f227055ae3261f00456a3f13e0b56db10b9be7b94d65cf59e8167a6555baf84eb370d9867e02b51f89d657f8b76b74c8e2efe80514858ed45ff00bccea56a3f132b3d36961ac8a47f9141a4a10128d721188a231d474d65b30c90ca1ede856a3f13a3dc1a373b032bc28e3ca64385e184e08b5184152554e691d0140f7d24de71742b51f899e9b894b217124c632618f0308a7382f309a42c29ebe53d85bd02e38efd9959456a7f132b2b7a7fe8a847ee6f605e8393a2f2420c2116117617dc52b0383860b571dfa4742b53f887a6c2bfdd8a688b1d0fd5fa782f14d2b2894e41a17829db82d6e4ea2b7db8ba15a91fe211d7775009221fb93da5063f2d0538e110549192a289c10185659834a12e921ecde856a3f10a3d36b0873030f9e3b63a00a729bdc16f4c2b31e46aaa9f263703a15a83fe2a23a586f9324830f3d91402fd258cb930100ac748e3f2757aed637a95a93fe2b4f43d2f5324bc20b0b3d83c841fdf28a0b5d5c390f80ad50ff141c20514549f2b3f522ec21dd7822d0117610394d1de8b3c58b3d4ad4fe2b935c814549f2b95914465460043c13dccc39a1054a1f37346002b0b1d0ad4fe294e184c774785210058734b8a0885859594cb4e8554bed9434a0b3d0ad4fe2a7059c10f562f4718d86d7eeaaeec8595e68bba0564fed8ac398aa7207b555d8c528ca08ad4fe2f4b33b2317778e29f339e5a55793043967ae56559776e91cae62a7bd918aaed6294178c6abf15ce005fddb2256afc931fd104d383149900a0567a172b0ee87ab242d31ee256b2b5f64352eeee4949394eea3a44535c83ba128a94e484420b087cd3a52e04208a011eb11098d5e3d3c54ef0d04e7a1e84a07a67bb8a69450f901f04136105847b2b127910b0827058ea7e7fa0f994debdfa7755cbb0ac1778943a0471d3b23f3fffda0008010100010500f641ff00cfb2564acac95dfe0fd5c49409c1715dfa77c92564ac90bba60efec73fc8195e5d810b38592b270b2bc80525bacc436544964b1b91281e992b3dc616530feef657fc80815dcacace0ba40d13eea95756f97c0d56379b49df36c49551f0db504b62b0abb4324714f1ca323e024267d5eca3fc80480bc967be55bd841599b5e553ca7fbb1298e781ad6c2f98cba9b0d8b542bb5b62d431c914858da57248e5ad6beeacac9e994c27cbd947f900f70bc95898451722db9967160bcb6593153706050efa4aef879047207b448eb3131cda9358a33549e388fdf11b2b4ed961cacace130feef651fe41ef93f372dfdd6c3ae9a4fbabfb670506bad4aeafc2f61307f1abf593eaced6476ac4066b8f91d15c7ad738cf1b27206ab62e6cbe4b2b299f3f65380f6265129cf681cbf691b9d4f01fa8d359bf268381b201aee375831fc135d699b6f5440f57bd52f70dd7adf655593c3257934d77ed09ed46f55438375f2be4ac0ace146efddecd7ff23072c8c6f6cbab53b664b93ea2b03738471daf5aa454413afa4e79a5ac993b4ee78b5c770b63c760745ec2f56ba66d8a96f5f209dcb4f7879eae66be3cace533e7ed118f62b64210902e6133d9aed50638f1e8b3bcd1867d8ab77531c71eff0046d7d2df578c3f7cd7367ded7f0b3c8755e73ec747619ecae2146e1983a39a8bdcd77119fceb925670987bfb45b9f613b20b5c33bca7fdeebaab2565ea753ed7269adc90eba074d30d8ebad515a9e5f6a36d1e4724f06ef9448d1636d258b50588208c624772ad788774d7b9aee3d51b575ed2b2133eaf67333cfe566082105bed5b63d9686c8b1b7b7a8b7352ff006d6e1d2d6e39cc67d9eab41b66dbe2bc52b3b53cdb8dcbf7ee70fddcd1f1de29b18e8e97895d637da3ac9e8ef6855966bf13711e4059ca613e5ecaf13cfec449e30412b675593d7d0472c9c8f554e37d6d8f0c16cd3f57da32d7e3baea6dd1c2d6d7bf4ab3a6b7c33557d90702af51edd7b2167bcb5f198b49543260ec0c95e584c2ef2f63591ffb1ded0e162320871cb8f6d6e98b2ff1dde3648b5d3c6f524c0470c6e9ecd1d853a8ad4d42cc94a611be699819b5d9c3147cd5d16eac475a085c5c02c95e4146efdded295d1fb36ad90f6ccdcb668cb4aa3b686b54d5d8731ba1db1f18b62c70e7f7b775cd4dc724aa0dae436ec7187d876ab61b431c5badac923af6c66fef3e69a004e90647ca3f9fb5e3f2f63c33ba17c161af6cf16448d2d2f761bc7edb6c6bb5b74c6eb9ca21a48f32d2d98a7e4bc56c21cab43136c7b1e9c6c97923eed5bb607db749e763cc04e9094d3843ba6119f690fe46b31aa96bc0c7287b6cb011312d5c62f8ace6592d34f5b5768eb7c63494ac335fc2dd15ba5c6256d6e3fa8ad0cf2963f6fb031c2d7f7f20535b941a01519fdded11fc8b2372276783a9da09ef0e6d96e4e5cd76aa47be968648a412ea61b914bc06ab8d4e2156a2da321884f21966e60e75681cc9591c47280ed908b947f3f67bbf921ddd4f107004c6f8acf6b772160a32c72bb884ed975cc74b5e56729bb091cd6c00796da9859b366d28a16b573a630ea344db0fa75db6227358f731cfeec0546cefed2763d95e48f752d67c926d219b591711e37359a2da524878ded24d6ed593b1ea42c7a7d305d5e16c23ee009af6e79e5ef367ae62864d8c9ad85b6aec36f41b77081e2385d231af225f6a7fc920e551a37b612eae80a96bde9ab827d9ee690d570cd3f1d3759b489e63d06f8bebc16db22f2784c2e729646b159d88637645f7369c7b61fd96e794ea1b5b77cab8f1e47c43d39ababb0da59d696c96b57b3ab07b2e84937b225804f63d2cf928f30dfb5d16df93bdbb67f3f7b1fbddbb071ef543e8c6d88c32d1bb46fbd54dab93b600b6d5a710f124cf8f5d1b6f4b01306fc3769c6b815a8e3d8bb6cfe15cddbe5e1cd390bec6efff00a075cda9cba591cd938fed5da8e73ec3a95ffdebc16dc97b97de95d7f907bb6ed776db91721ad59d5efc5b7875ba9972684d196b2c114b472da3ace21108ee08eaef6ab83ddeb199bb1e355ec4d5acfb378f6bb69b5a44dab534adbbce79bf1e9b93eee374c6b6d0934b7ae2f8f82ba28b915af6550d2ecb99721dbee7916bf4535ce37564b34cf14dcb646d68239c45ac8008a274475fab2cd26fd8dabbcd7723d86be5e21ce68e9796f29a95a0dcd2a27927afb8a5c7555a89c11c91dbc6fb3fda50e81dc9a7645ff63db0ac7d73626dfc74db5e903baafaf16bd7f1d63a3961a58e071d40fe2c27750af1c38d447ae16397d8e6b36cb93b2b3b7f2c358dbf6057d6b2cd61cf2377ab363ecd8b6bb82c9b7f4444359fffda0008010202063f003b53b5362698b076a76a76a687d89bb2a2b37993d46b8bc6ec583b534b5336ced4ed4ed4ed4d536a293ac29b4f446a7473b2745b7af75ecb8bb1c5983a4a8a65469fffda0008010302063f00c7e36b8fc5a92bf6506ce3f15c95f84ae59495ca7053774fd4d78fc52e5375e14d6fd4a6ed1daac7e2826db84c7f6a71f8a0ba7b63f8408a31f8d5caf91c0b1143d38fc6a593d98a08a31f8d89a31f8d4847a9b8c8518fc51f4358a614e8e832028c7e287a85bc7e6822a8a40514e3f34fd0b4e6ac7e76b8fc54e359b98fc553c2fc6b70bfbab1f9a64af9ebc59705376e141a31f9d5fb15f3d1393a35a829bb485cca758fca729bacf65f91d8423d09e42c6e67e1308ea9f6601ff3be63b69d22cfffda0008010101063f00f3f156ff00cb39311f857a6779bde6f6cef37bcded9de6f79bdb3bcdef1f6cef37bcded9de6f79bdb3bcdef37b6779bde6f6cef37bcded9de6f79bdb3bcdef37b6779bde3ed9de6f79bdb3bcdef37b6779bde3ed9de6f79bdb3bcdef37b6779bde6f6cef37bcded9de6c8fe23cc7a67d403fcb3f0af253edd4903ae55ee01282ec055830fb38f2613d07d4679ffeecfc2bcb9f2924d043e2389a76ebacf3cd66a1380ac1aadb31e3da94a1b678e309b572aab9c0585453132aa7d1f633949e83ea33cfff00767e15e4c32e4e985ee3529c214b5d949aae36a2784a2dbd4e79a771bd07282e5a388e7c6378bd97fc4215a90bcf5c26bb2faed118d207d5fa67d7287bdc9872610e1c0fa8cf3ffdd9f857ec1b8784a06aa630d4f54343889a5c549e303852f69bbdcf0295a5b7cb9c422d935e260175886ae3cd3493af6d730eaac6b4fdab577b4a788969ad31a8ceb030f4fd8cf81f519f507eecfc2b33984acb809ed1c841c5bf1406928a09066b36cd250212398c2af6b4919185bf843af333431aa7010819a65d534b1eee502d6b6df083a797d07d467d423fcb3f0af2e3c21b76ce2050ca675e316daa9696daf26300d029d50d506aea8c6d8a7a231d397447b96d0b2ac28e0aba9c418cc72ca2be44f7a30b67a5629b9de187dd30e43d47d467d443fcc3f0af2eb4e3818d4c4935316c9ceb4a44bcc835b018c1a44ca949551510ea118e9c23294a83847dd6cadd2e8c680671ec5e528ea684180365348c8c214d699caf27a0fa8cfa84ff00967e1598f20a644cb975cd00040eb960bfe335a7a65b514080080dcb8a08e351004be9ab98112aac083309a58e3cf0a3dd008cf18ca2e2b0a63888fb9d9d188058e98f65f028690e934e99709c4e22bcbe83ea33ea0fdd9f857931972dae2ca2ab176ee4a8d7a584dadb03b032316d5a243b018cf0eedfd35e99e3a6e030e02b8c5577269038c708c8a6866937a858f3c01ef31273a18da2e6b47520a9e99b950283561342e6d84414ed3627d3cbe83ea33ea03fe59f85797a3889e320d20f6abd336ab717b63ba79c456b02a69fca3f8b77403dd35c65cb5b8dc1f9553d96246558d69d752ab515b9c40f717b74c447f97534c728ef6dfc2be09d38d23ffec3705af9a84008303b312bc6b18d085b87032caa8ae38c45a534a80794f51f519e7e38fcd1f856544c391895adc1919b4b2302a713e988b4af647aa16b373c273e99e25fdd7e9f350416d541619b4745145a7f28e2ea8c4e10f634b738955c79a52990966e5b51e370fbe0c34dd198839e931e4af437a8cfa890f0de11ff002af2d0c3fc65bf314c029cc4452d46a0809359846666a28e10adcb8bd558c16e2d4e58c36c9d4064654c26a04d2e7b166b430e85c72af57d83d4dea33ea43c3e74fc0b295e5a18d61d4b6a22879a23a13431751c6015cf9e68f2d257c404ea1cf08dedd7763c7189b8b37ee2053dda9a44b9b96fd6e24c209a18c0134976d83d92713c98e3282630fe56f519f519e3f387e05801cb94caf3632db0388ce000c577b9403845b9babaa7980359a59505326a6734dbb681064693c3da96249a050308a586968cc4f0265d73c4f2504e732a653a1bd467d45fbb3f02ca89a4f21a4239e1dbb9a2b65010668dd0aa9e0652e256d7363480150ac3338cf0f6d6f1e8ac378591ace5085141c04d20e2df68f537a8cfa8bf787e0586544a1984e8834e7c0c572dae999828da5c4d2e44d42e52bc2a66a2c0d21ab0d2b0e9cab4acb3717ba48563d6625ca56db8a86131e5c21c7f0b7a8cfa8c70f9c3f02f219494328cd573928ce3965d240c018c95ab2b1a8e89e259343cd2841989359a412651c9d3cd29c6004e3ad69f7cbb674975238e34ea8c2e62a0e066b5ed2f389419cca11fe96f519f520ff30fc0bca12daea76340067345f464dc30aaab6184dcf9fef949b360e840d912d94dc303a1d72039a359b9fd9bb854e559a94d41ca5089512a4632b09acb5614fe35afdf06cef283e3db62b5e858d69c7675b06fbf09f27b9a9b17c07b64e546c443750e1c5467355a3abfd3c66820872080bc6b433ea3fde1f81791acec6d1bd71717031a4b1ba7c5f6d72b795ba3313c9379b6b611377b453451f89a93ca7ca54693bcb42e5fe7d4b3cc770fd9b5b303530cb18f7ad9ed5a76d3115cf68000c1430113186a610a65b4cc0ed7dd365b9eea252d13f9f0fe72f5a0296ee225c53d246a963cd6c8aeef60e45d233096f00679a59f34b5ad6c6d6e5db7515eee465ddced0f84359d0abc4566d377bedaaa3eec31d95c1896600d2b3ea4bae7c3b037a6affec589b6db2e8b543aae7f54bfb0a80db85d3438d698f19e61b663a1bc6b84f48d467d3362ba859f06db750a46b0a6b6b620da41cd512f5e3d9de79d529cfd93ff00196548abdcc5d7ae38c8135a744143007c67661c62aa83da3496eabdb0b8c7287fb7711d47e520cf25f3cb38b3d6dee08e013b38cddf945fc769e6f6bc040720cd8d67996d0ad2dddb5736c9d2ad2cdd1fdbb8e30eb33e9af28434b1b4ba88cbd0e403eb8dbdb0f5b77ae6adc28feb200c65bbd6b0e7f4cf2df302dd82fdb3d6235fb67f4f75645ca0e76c636c9b1b5b4437549e1a0cba6b5f98dc2fdd5a4f2efa7ad385dbec16ae380d4046b9b522e9b6b452320445bb4d3749a13ce615614e6980ca534c01842ed6f0515af4cbc8cd90623aa02314baad8cf3afa6ee9adeb09ab6a0f393a8d25add2f65f61773e95349e59e7a485b5736886e373dd2329f2d6d6b6ecb6aaf3058db826b6f6b7edb29fca47b27d55e581bfefacee8deda03fd16d412046b57868dded895bf6ce6083496b740f6ad302679679a5fa94b96addb07a74cf33de81a6d8dbdc52658bdb61e3df15032201af19b8dfeeee10f7e87b351379b84153614b3939d223a922d5721cf2b72e0299639d6062338090228b09576c1613b9ecb5daf6baf84dfeb52e552e0b7d5482ac5ed33e0a71205784f2ef3176366cee485dc063404114973e56e2ddd9ef105f464cb55ced526ff00cbcb11bed8335eb5cfe1a4dcbbb76eddb75b95fea9bddeb57590ee0f0aa82679abf9529b9bc1bb34b6a695b5a57554e51775e577d13ccdc7ff005bcbd43108fa7fea28f0cfbf37219d74614635ad6bd53ca0dd217722e2e806b88d386426f53c8f6eb7d5adb7cd5d2c14a2d3b540684fa259d7ba537750a82afab3fcb2d15dd29623f50157c30fcb3cfaddebb6c6c4edc7eb51b0cf852bfc25f0fb8516431f09a8f8f37e19ba17eea9b7a1bc26a3535d30cc441ba211c775b1351e8106aba07a1bd910bdd048ee8a3627ee9e5e9f2a76de4e97d29711d5f5e3c4216a7fba6f8de7087c27a0c4fe1e8065a0f7d56d7882ad47386ae859b05d96e56edaa2d1c2b8c69cc565a365af5e4a0f085cd4a29c295025e65f295dc5bf0586e905eb4a3c2fc4c4bb013ccee595f96b059bc5b00eba1fcc95597402a6c78773b42b5a6935ae13ffd90d0a0d0a3c2f626f64793e0d0a3c2f68746d6c3e0d0a0d0a0d0a);
INSERT INTO `staff` (`staffID`, `staffIDEncrypt`, `staffName`, `staffContact`, `staffEmail`, `staffPosition`, `staffPassword`, `staffRowLevel`, `branchID`, `staffImg`) VALUES
('ADMIN0001', '145915c1c0138369feef74eee20205a4', 'Administrator', '013-6707731', 'zakwan1211@gmail.com', 'Administrator', '202cb962ac59075b964b07152d234b70', 1, 1, 0xffd8ffe000104a46494600010100000100010000ffdb00840009060712101215101012151515151215151615151515151515181816161616151615181d2920181a251b1715213d2125292b2e2e2e191f3338332d37282d2e2b010a0a0a0e0d0e1a10101b2d251f262d2d2d2d2d2d2d2d2e2e2d2d2d2d2d2d2d2d2d2f2f2d2d2d2d2d2d2d2d2d2d2d2d2f2d2d2d2e2d2d2d2d2d2d2d2d2d2d2d2dffc000110800cc00cc03011100021101031101ffc4001c0001000105010100000000000000000000000402030506070108ffc4004c1000010302020509040704031100000000010002030411052106123141510713223261718191a142b1c1d10814526272829223a2e1f033344315162435445373748393a4b2b3c2c3d2e3ffc4001b01010002030101000000000000000000000003040102050607ffc400381100020201010505060504010500000000000102031104051221314113325171810614226191d1a1b1c1e1f023334252f11543627282ffda000c03010002110311003f00ee2802008020080200802008020080d7f49b4ce8b0ecaa6601e45c46d1ad211b8ea8d83b4ad5c9225ae99cfba8d1ab3972a61fd0d24cff00c6f647eed65a76a8b0b452eac8279763bb0fff0089ff00e4b1da927b86794bf0fdcadbcba71c3c8eea8bff00e24ed90ffa73f1fc3f72643cb8d3fb749337f0b98ef7d967b5468f413465a87962c324eb99623f7e3bfab090b6562237a4b11b6611a4d4757953d4c521fb21c35bf49cd6c9a6412ae51e68cb2c9a040100401004010040100401004010040100401010f17c521a489d3d43c32368cdc7d001bc9e0b0de0da3172784722c7397076b16d15337541c9f3137776f36db5bc4951bb7c0bd0d170f899c9f18c4e4aa9e4a898ddf238b9dc3b00ec02c3c144f8f12ec22a0b7511635ab26ad26f89796859080203c210c38a7ccf35378c8ad9488e55266f1a25ca7d6d096b2671a984645af3d368fb921cfc0dc29636142ed127c5703bee8f639057c0da8a776b31db47b4d3bdae1b8853a7939538383c3324b268100401004010040100401004010040100407cf9cb7e90baa2b7ea6d3fb2a70011c6470bb9c7b810df3e2a0b6475745570cf89cdde2ca24cbd38e196deb64413f10d72342322eb5e7bd6ae2588d92f32b04f03e4b5c1326fc1fd0f75bbfc9303792e7f91e6b84c331da44f45cec05382e6656f4bba8f1cd0debbedd836a279e48d6518c3fb93c7c8dfb912d20e62bc5307931d4b4b4b4e435c0d663876e44771ec0a7af793e272f5aaa9473079c7a1f44a9ce5840100401004010040100401004010040101f26e97d47395f54f3bea241e4e23e0aad9ccef695620bc8c2c8e5aa46f64f2f05175b11e4b6e7705b24432961f03258560b51522ec0432f6d626cdf0e2a1b6faebe7cc9aaaaeb793e1f432bfde4cffe747ef7cd41efd0ff0052c7b859feff009912a3462b23d8d2e1f75d7f42a48ea69973e068e8d543baf3e4cc7cb054c7d78e46f7b0fbeca55d94b935f523776a61cf3f4fd88cf9a4de48f45ba8448e5a9ba5c1c996085b95daea6e3a2586ba9b17a48ef7fdac6e0e02d70e17d9e63c1694d9da2c8d554ebca67d4cac9cd080200802008020080200802008020080203e44d203fe1753feb337fd472ab3e67774efe03124ac9a3678b2609b8261ff005899916e26ee3c1a05cfa0f5515d676707237aaadf9a89d768a95ad680d00002c00d8005c2727279675dfc2b08c9450ade2889c890da507729544d1d982bfee6b4ee5baacd7b768e73a7ed74d3c587d3b4bde5dae40db7cc345f801ac55bd3437732641a9b1cf11f52660bc988616beae40eb58f36c1d127839e768ee0b69deffc48a352ea6cd86605ce62f492819442573ac3606b46adfc5d64d1779c7d4c6d27fd352f43afae91c3080200802008020080200802008020080203e4ad368b9bafab670a893d5c4fc55792f88ebd12fe9980ba18c9530e68cda0f89b6e80c379247ef0c007e639fb973f5d2f8523a1a48fc4d9d0a9815cf48b723294e78a9628af232b4f102ac462559cb04c653a994481ccd4e2d169595e2be3d5764e8a48dc755c01161230ec26d6cbbd6d5a7bae2fc4cdb34da6bc0da6682cb0e22331a3dd1abfc51b87b8fc16da6e16fa18d67c5a7f268dc5748e2840100401004010040100401004010040101f2f72c14a62c5aa46e7ea483f331a4fadd4525c4e8512f830698d692b56c9a30722a1190b5c9baada79374e4f8e728fc1f15ced77f89d2d2f53a0d335528a269332b4d1a9e28ad366569e356228a93919381bc5598a2a4d9284214ca242e644a989473892d7220e1c2d5519fc43d0a8ebe16a2c5dc74f236f5d138c10040100401004010040100401004010040706fa456165b514f560652446271dd7638b9be243ddfa56922c50fa1a068c6102aa611b890c6b759d6db619587792a95f6ee47276e9af79a8f43a03700a668d51033c45cf99cd7365759cf2cbeaa82e85787611142f73a266aeb000804db2d991d8a39db39ac498508c78c4cf5335226926656982b112acccad32b112a4cc8c2ac44ab2246bd94c99163244a994151ca44b08b440a2feb31779f715143fba8b16ff006246dcba271c20080200802008020080200802008020080d2f95cd1f35d874ad636f245fb68c01724b3acd1da5bade365868deb9619c3793c9c09dcd3edc5976d8836f2bf92e66ad7c3ea7a3d24937e68e8842e6b2f1e3066a33564f816f1229192a72a783209a323039588b2ac913a2914ca457944a9f2a9378d54481572a8a4cb15c4b5813cbaa997dc1dff294d3f1b51b6a96ed12f43755d3386100401004010040100401004010040100400a03807291a11361d526be8985d017f384345f99713d26b80f60dce7baf6e0a0b6bde4ce9693538c27cd722660b8c4754cd761cc7599bda7e5dab8b6d4e0f0cefc2c5359464015599b325c0e5b2644d13e07a962c8a489f14aa78b2bca24964ca55222710f99677828106a665a4a44f089234446b5493f66371f568f8a9347c6df422da3c28f55fa9bbaea9c108020080200802008020080200802008020287cad6f5881de40432937c8d771ed2fa2898f8feb31ba42c735b1b0f38e2e20d810dbdbc54365b18c5f12d53a3ba4d3dd78f1e471d8a984120918d00902f616b8de0ae34a4dac367a0ab0b8a365a42d78b8ef55a489e4fc0bce362b45c0d17224c5229133468971caa55223712fb675bef1a3814493acef1950224f3ad5c89a3033fa0515ccb27e160f527e0af6823de91ccdad2c6ec3d4dc1748e3040100401004010040100401004069dca06997d41a2284033bdb717cc31bb3588de6e0d8762aba9d4767c1733bdb1763fbeb764f8417e2fc3ee727a8d30ae79bbaaa5bf63b547835b60173fb7b5f1c9eb96ccd043e155a234da4358f1fd6a6ee32393b79f5667fe97a57fdb82cf860c45454cd2e4f7c8f3c1ce73bd095bef36577442be492f4c1334628cbdfce1d8d240fc5bfc96b63c2c1cad45d9f851b94f477683c1566435be382c523cc46c761f45abe24ebc0cb3ba42e144d18e4ca2392cb5ce0cb44964ab7522368b9cf2d931ba50e996778ca89126956324b14746d11a4e6a999719bfa67f36cf4b2eee921bb52f9f13cced0b7b4bde3a70fa19a564a41004010040100401004010040101f38f29b8aba4ab9dc0e7ce18dbd819d1cbc8ae4b5da5cdbe48fa0424f47b32b8c384a4bf3e2d9a11076abb0839bc451e7edb156b7e6f04fc3eb0821ae24f03bc7f05bdbb324e0e4b9f87f3a92e83da38c6d55d8fe1ff67d3f633d45206c8d9381b1f116bfaae4c1eecb0cf5daba95b56f227d1bf9aa93f626e90e01e067e605fc14b6acaf23ccdf4b8cb7d727cfcff7376a3b3858f0551902658a8a41b1684ea45881e63363b11a24ce7812a48efd26ad1a09e3832d8715a60ce0195672305b74c9933829a4aba76cd136aa56c71b9f625db32cec4ee0765f666ac69abed6c517c88f5339574ca51e697f19d922702016904102c46608dd62bd1723c867256802008020080200802008020080f0a03e57d339af5125f6f3d292385de7f8aaba2d2cad9ca4f82c9ebb6d6d2ae8a29ae3c65bab8787058c9838612fcf77f3b17a0aa98c5622b81e0f53aa9ce599bcb27c5101b02b0a25194dbe64aa4a80e25bfc95e6f6be8f725dac393e7e7fb9f4bf64f6abbaaf75b9fc4b97ce3f75f919174a4b41f69a411de172d4b28eddfa64a4e2f93372c12b03da08de142d1e767070938be866dccd6175a34613c1166a7bac12291180730e5b160914b3c195195aeda2c7b3e48d1b24fa32d49aa3daf3165aee9b2cf530b8ae351c232e938ec03678b9490a5c892387c8d55d33aa1d23e537b44e206e1c0057aa8a872162e0978993d08e502a70b788de5d2d36c3093d51f6a271ea9ecd87d57a6b295359ea7cfa36e1b5d0fa1b04c5e1ac859514ef0f8de2e0ec20ef6b86e70e0b9f28b8bc32ca69f227ac1908020080200802008020080d07953d3b186c5cc4041aa95a75761e69a72e748395f6d81da4700a7a6adf797c88ec9eea3e7b6874ae2f792e2492e71372e273249de495d2840a36daf9be64f6354e914db2dd43edd11e2b26d08e78b2cc46c411b96b6531b20e125c196f4fa9b34f6c6dade1a794662393585c2f15a9d3cf4d6bae5e9f347d7f43acab68e9a37439f55e0faafe74331a375baaed43de3e21577c4e66d2a1a6ac5e4cdea8e6b851b39249736eb18328b1242b0d1ba910e7a50560dd48c555d22d91b64c2e3986de23f69bd2f98f25356f0cc576627f23566cdaa08e36bf7705d0d354edb1457f11bebef54512b1f45c3cdf22d4d1870cd7aa6b27cd63269e4d93931d2f761954192b8fd5e521b2b4f55a763651c08dfd84f00a9df56f2f997eab0fa541bec5ce2d9ea0080200802008020080838e628ca4a796a65ea44c73cf1361934769361e2b318ef3c230de164f94f19c525aea87d4cc6ef91d73c1a3734760192ead70496114a73eacae2658582b5145194b2f25d26c2eb734c65e08a05f32b2913722a016e91ab648a79354f62a5afd047555e3fc9727fce876762ed9b3675fbdce0fbcbf55f35fb13a37d887b7766bc5db4ce99b858b0d1f5385946ba8ed2a798cbf9f55e06e982e221cd07f90a268f337d32aa6e1233d1d505ae0843aa82c6011e6ab6a60ce481355b466b2a21c8c4576231fb4f68f10ad57a4be7dd83fa104f534c3bd24bd4d0aa0824db65caf51a1d1f610ccbbcf9fcbe47076aed2f7a9a8c3b8b97cdf8fd8b8d390ee57b070df322d5b77f828a689aa7d0fa5792ac58d5619039c6ee8da61713b4f3675413e165caba389b3a55bcc4db9446e100401004010040101ca397fc60c74f0d234e733dcf77e08ed97ea737c8ab3a68e5b64573e0715a56ef5d28239d6be84c629922bb2898ee5be0da0ba9e00b748cb2b016e91ae4a805b2305d8de46c55f53a2ab531ddb17af545fd9fb5353a09ef532c78ae8fcd7ebcc9d4588189d71b3785e7aef67ad4ffa524d7cf81eadfb53a5d5431a8838cbc63c57e8ccb3b4940d81c7c828ebf67f50fbf28afab39f66dcd3c784537f81126d2490f55a077e6aed7ecf56bbf36fcb814ecdbd37dc825e6439312a87fb44770b7aa9bdc76751dfc7ab330b36aea5ff004e32f48febfb919d1cafeb389ef715a3da5b3e9e104bff0098ff00c172af66b6bea38cf87fed2fd165fe01b87713e4a9dbb7d7fdb87d59d8d37b11d6fb7d22bf57f625d360c64c991b9ddc09b7c9732ddb7a8ca6e497cb81d85ecd6caa60d4d73eae5c7d3fe0835b40e8496b811636208b11debbfa0da55eaa3e12f0f1f23c36d9d836e85f6b07bd53e525d3e4fefc8c74fb0abb23890e676dfa3f4a4d14ed3ecd49b78c6c3ef5ccd52f891d2a7ba75255894200802008020080203e7ee5eea0bb118d9b994ac1e2e7c84fa6af92bfa65f095ae7c4d0e2d815f89425ccbed2a5444cb77bad91bf22a01488d597005ba352b0b6c1a9531b7200dfeee2aa6bb5b0d255bf2e7d1789d3d93b32cda3a854c382e6df82fe722636982f373f68af7dd8a5f567bdabd88d1c78ce727f446562c00180d49919aa32d51ac5dad7b06916163f05cbb7da1d64acecd36bc925fb93d7b0b65d57aa550e4fc64de31e3cf8fd08d4742e91c191b6ee3b87bcf62af76b2d6b364dfab677a3a5d16923bd1ae315f28a5fa1b450e85e579a4b1fb2cceddee3f00b9366bffd17d4a36eda4b8551fafd8c9c5a254c36879ef71f8281eb6d7e05396d7d43e585e863b1fd188e28ccd09235737349b8237907885674dab94e6a13ea5bd16d39d962aecebc99afd0d5490b83e371691e47b08de15eb2a8d8b124752eaa16c7766b28d9f13a4657d38a8634091a2ce1c6dd669e3c415468b27a5bb733c3a3fd7ee70eb7eed6bd3dbc612f1e5c7f9c4e698bd1737d21d53e9d8bdde835ddbc7765de5f8fccf1db77623d0d9da55fdb6fe8fc3ec766e41294b30f7bcff6952f23f2b5acf82d752f3339b52f84e96ab928401004010040100407ce9cb7ff008d5dfe821f715d0d3770ab77334d8cabc8a2cba4e4a54698e250d5ba32cba1488d19505b2305616c6a6430ba526c6dd279000ecd8d1f1f15e0f6beb3b7bdbcfc31e0bf567d73d9ad9d1d0e894e6b1297c4fcba2fa1d4a930489b03607b1ae16e912332e39937da0dd7909df37639a656b75b64ae76c5b5e1e46224d0d17219310c26faa5b73e77b1ef215b8eb9e38c7897e3b65e3e2865f899dc2b098e99bab18ccf59c7aceef3c3b154b6d95af32399a9d5d9a89666fc97444a7cad6ed7347790146a0df2440a327c93224d8c53b36cadee1d23e414d1d3592ff12c43477cb945fe46bd8f63e26618a20434f59cec891c00dc3bd5ed3e8dc1ef4b99d5d16cf75495963e2b9246bc18afe0ea6f198c1b1534f1c800bb9c5ba8370362093e992ad7e9fb5947c3a94357a557ce2df259c9a4691e21726369c81e9769db6f05e9b65e937576d2f4fb9e4fda6da8a6fdceb7c177bcd725e9d7e67d07c99e1ff57c32958458ba2123bbe4e9fb8852daf33679f82c451b428cd8200802008020080203e79e5d63b6260fdaa688fef483e0afe97ba55bf99a2b0abf12932e12a446a91535488c32b0a446acac2d91a9e9f95c7117cc7928b5109cea946b786d7027d24ebaef84ed598a69b5f2362c36a85db247b5ae06c77119d885f3dd4e9a75b75d8b0cfb369b5746b68dea9e62d63cbec747c33168a766b021a40e935c4023e63b5702dd34ab783cfea3496532c3595d1a3098d692904b20200191932cff00083bbb55ca344b1bd67d0e8e93662c6f5abd3ee6bb3e22f79bbe67bbbdee23cb62b918571e497d0eb434f18f08c12f4447350ce37f02b7ca2655cc7d6d9dbe49bc8765327d0d24935b9b8de47da2006f992a1b355543bccab75d5d5df92f2ea64aab0410c4659a56b6db9ad2eb9dc2e6ca186ba164d4608a95eb5db6285716fcde0d5b17c4c46cb3082f7643b38b8aede874def167c9732aedcda5ee147fe72e11fbfa7e66b985d11a99e2a71fdacac61e36738071f2b95e9a4d423c3a1f338e653cbe6cfade28c35a1ad16000000dc00b00b925f2b40100401004010040101c1be9031dab69dff6a96dfa6479ff00b95ed2f75f995af5c4e6ad2afa2a345dba913342a6a911ab2e02b7468ca815b2660aaeb64cc1546f2d3acd363c7e046f0ab6ab495ea61bb35ebd517743b42fd15aaca5e3c5747e64d86bcbfa2e36770be47bbe4bc5ebb67dba5971e31e8cfab6c5dbba6da11dd5f0cfac5fe9e25e5ce3d013f09c264a976ac7600759c760fe2a1baf8d4b322b6a7575e9e3997a236aa4d0e85bfd23dcf3d9d11f35cd9ed09beeac1c4b36c5b2ee24bf132d4b83d3c562c89b71bc8d63e65569ea2c9739328d9acbecef49fe462310d2e646f2c6465e1a6c5dad6048db6c959af4129472de0bf46c89d905294b19e86bba518f89ec402d8d82f63b4b8ed397905d0d168dc5eeae3265da6aaf67533b6d7cb9bf9787afe668f3ce5c4b8eff0041b82f7ba5d3c74f5282f5f33e5bb4f5f66bb512ba7e8bc17446c9c96c5af8ad2e57b3dcef263962f7f032b52be23e9d5cd2e040100401004010040101c4be90ecb4b46ee31ce3c9d11f8ab9a5e4c82fe47266957e2ca8cba0a9132368ada54899ab2b056c99ae0a815ba6630540ace4c60f75967263078ecf22b49c6338eec9651bd7395725283c35d517e9eb4b727ecdceff00dbe6bca6d1d8eebcd94f15e1e07d1b61fb571b314eb384ba4ba3f3f0f3377d0dc5e38b5a290ea8790e6bb75ed6b13b9791d75139e251e9d0f41b534b3b946caf8e3f9946eed21c2e331c4661721f0e679e7c383303a4f8d88586361bc8e16cbd81bc9ed57349a6764b79f2fcce96ced13ba6a725f0afc4d0176cf5061311aad7758755a7ccf15e976568fb38f6b2e6f9791f35f6a36c7bcdbeed53f822f8fcdfd9105ce5d76cf2691d6f906d1a7191f88c82cc6b4c517de71b6bbbb801abf98f0547533ff12cd31ea76d54cb01004010040100401004071efa43d392ca397d96ba6613dae11b87a31cade95f344172e4ce30d2af265565c054899a32b056e99ab4541cb64cc60a8396d93182ad659c98c0d659c98c0d64c8c1e6b2c64ce0bb4b5463cb6b7870eef92e36bf65d77fc70e12fc19ea362fb49768715dbf157e1d5797d8cd52d59b741e403c091e602f277e9e55cf76c8f13e97a7d469f595ab6bc497f3e8ccfc3a38d31f3efa966a01725a0b8f7676b15cf96ada96e283c9567b464aceca35bcfcff008f81a7e2f57aa351bb5de61bf35dfd9ba3774f7a5dd473bda4dafee7476507fd497e0babfb1852e5ea9b3e618c9bd7279c9c4d88b9b3ce0c74bb75b63a5fbb1f61fb5e4ab5b7a8f05cc9a1537ccfa1e868e38236430b0318c686b5ad16000d802a0db6f2cb45f5801004010040100401004060b4d347198952494ce3aae235a37917d478eabbbb71ec256f5cf7659359477960f9831ac266a299d4f50c2c91bb46e23739a77b4f15d2849496514e516b990c394899a60a8396e99ae0a8396d93182a0e59c98c1eeb2ce4c60f759378606b26f0c1e172c6f19c14eb2c6f19c15c354586e3cb7155b534577c7766bee8e86cfda17e86ced297e6ba3f332acc498585d7b11b5bf2e2bcd59b32d8daa0b8a7d7ee7d168f69b4b6696574b84a2b8c7ae7e5e29ffc94603a375989bcfd5a173c139c87a31b7b0bce597019af41055d10505c8f9d6aaeb75774aeb39bfc3e5e8761d0de4869e98896b48a8976865bf62c3dc7379ed39762af66a1cb8478188d49733a635a00b016032006c0ab929ea00802008020080200802008020313a45a394b8847cd55441e05f55db1ecbef6b86616d19b8bca30e29f3392e3fc89ccd25d453b646ee8e51a8f1d9ae32779056a3a95d5104a9f0344c5342f11a6bf3b492d87b4c6991bdf765ec3bd4f1b62f932375c918173ac6c723c0e47c94b934dd603d6778d7055acb3bc63035d637860f0c9da9bc6774f600643aac05e7834171f20b0e5836dc66770fd0ac4a7b73747358ef7b79b1fbf651cae8aea6caa9336bc2f917ae92c679628078caefd22c3d5432d547a122a5f53a068f724b87d2d9d28754bc6f96da97ec8c65e77504f51297c89635c51be431358d0d63435a05835a000070006c501215a0080200802008020080200802008020080203c4059a9a48e4ca48d8f1f79ad77bc2ca6d0c18d9f45681fd6a380ff00b260f70595397898dd4453a0d869ff002283f405b76b3f131b91f02b6684e1adcc5141feec2c7692f11b91f02643a3b46cea52c03ba267c9637a5e26708c8c7135a2cd6868e00003d16a64a901ea008020080200802008020080203fffd9);

-- --------------------------------------------------------

--
-- Table structure for table `statistic_year`
--

CREATE TABLE IF NOT EXISTS `statistic_year` (
`statisticYearID` int(11) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- Dumping data for table `statistic_year`
--

INSERT INTO `statistic_year` (`statisticYearID`, `year`) VALUES
(60, 2017);

-- --------------------------------------------------------

--
-- Table structure for table `total_warning`
--

CREATE TABLE IF NOT EXISTS `total_warning` (
`totalWarningID` int(11) NOT NULL,
  `memberID` varchar(5) NOT NULL,
  `totalWarning` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `type_book`
--

CREATE TABLE IF NOT EXISTS `type_book` (
`typeBookID` int(11) NOT NULL,
  `typeBookName` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `type_book`
--

INSERT INTO `type_book` (`typeBookID`, `typeBookName`) VALUES
(1, 'Kesusasterawan'),
(2, 'Karya Am'),
(3, 'Sains'),
(4, 'Teknologi'),
(5, 'Geografi dan Sejarah Am'),
(6, 'Falsafah'),
(7, 'Bahasa'),
(8, 'Kesenian'),
(9, 'Agama'),
(10, 'Sains Tulen');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
 ADD PRIMARY KEY (`attendanceID`), ADD KEY `staffID` (`staffID`);

--
-- Indexes for table `attendance_statistic`
--
ALTER TABLE `attendance_statistic`
 ADD PRIMARY KEY (`attendanceStatisticID`);

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
 ADD PRIMARY KEY (`auditLogID`);

--
-- Indexes for table `backup_log`
--
ALTER TABLE `backup_log`
 ADD PRIMARY KEY (`backupLogID`);

--
-- Indexes for table `blacklist`
--
ALTER TABLE `blacklist`
 ADD PRIMARY KEY (`blacklistID`), ADD KEY `memberID` (`memberID`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
 ADD PRIMARY KEY (`bookID`), ADD KEY `fk_typeBookID` (`typeBookID`), ADD KEY `fk_publisherID` (`publisher`), ADD KEY `fk_bookLanguageID` (`bookLanguageID`);

--
-- Indexes for table `book_language`
--
ALTER TABLE `book_language`
 ADD PRIMARY KEY (`bookLanguageID`);

--
-- Indexes for table `borrow`
--
ALTER TABLE `borrow`
 ADD PRIMARY KEY (`borrowID`), ADD KEY `fk_bookID` (`bookID`), ADD KEY `fk_memberID` (`memberID`);

--
-- Indexes for table `borrow_statistic`
--
ALTER TABLE `borrow_statistic`
 ADD PRIMARY KEY (`borrowStatisticID`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
 ADD PRIMARY KEY (`branchID`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
 ADD PRIMARY KEY (`contactID`);

--
-- Indexes for table `email`
--
ALTER TABLE `email`
 ADD PRIMARY KEY (`emailID`);

--
-- Indexes for table `form`
--
ALTER TABLE `form`
 ADD PRIMARY KEY (`formID`), ADD KEY `memberID` (`memberID`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
 ADD PRIMARY KEY (`memberID`), ADD UNIQUE KEY `memberIC` (`memberIC`), ADD KEY `emailID` (`emailID`), ADD KEY `contactID` (`contactID`), ADD KEY `staffID` (`staffID`);

--
-- Indexes for table `member_date_register`
--
ALTER TABLE `member_date_register`
 ADD PRIMARY KEY (`memberDateRegisterID`), ADD KEY `memberID` (`memberID`);

--
-- Indexes for table `member_statistic`
--
ALTER TABLE `member_statistic`
 ADD PRIMARY KEY (`memberStatisticID`);

--
-- Indexes for table `recovery_log`
--
ALTER TABLE `recovery_log`
 ADD PRIMARY KEY (`recoveryLogID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
 ADD PRIMARY KEY (`staffID`), ADD KEY `fk_branchID` (`branchID`);

--
-- Indexes for table `statistic_year`
--
ALTER TABLE `statistic_year`
 ADD PRIMARY KEY (`statisticYearID`);

--
-- Indexes for table `total_warning`
--
ALTER TABLE `total_warning`
 ADD PRIMARY KEY (`totalWarningID`), ADD KEY `memberID` (`memberID`);

--
-- Indexes for table `type_book`
--
ALTER TABLE `type_book`
 ADD PRIMARY KEY (`typeBookID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
MODIFY `attendanceID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `attendance_statistic`
--
ALTER TABLE `attendance_statistic`
MODIFY `attendanceStatisticID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
MODIFY `auditLogID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `backup_log`
--
ALTER TABLE `backup_log`
MODIFY `backupLogID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `blacklist`
--
ALTER TABLE `blacklist`
MODIFY `blacklistID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
MODIFY `bookID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `book_language`
--
ALTER TABLE `book_language`
MODIFY `bookLanguageID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `borrow`
--
ALTER TABLE `borrow`
MODIFY `borrowID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `borrow_statistic`
--
ALTER TABLE `borrow_statistic`
MODIFY `borrowStatisticID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
MODIFY `branchID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
MODIFY `contactID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `email`
--
ALTER TABLE `email`
MODIFY `emailID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `form`
--
ALTER TABLE `form`
MODIFY `formID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `member_date_register`
--
ALTER TABLE `member_date_register`
MODIFY `memberDateRegisterID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=118;
--
-- AUTO_INCREMENT for table `member_statistic`
--
ALTER TABLE `member_statistic`
MODIFY `memberStatisticID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `recovery_log`
--
ALTER TABLE `recovery_log`
MODIFY `recoveryLogID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `statistic_year`
--
ALTER TABLE `statistic_year`
MODIFY `statisticYearID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `total_warning`
--
ALTER TABLE `total_warning`
MODIFY `totalWarningID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `type_book`
--
ALTER TABLE `type_book`
MODIFY `typeBookID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`staffID`) REFERENCES `staff` (`staffID`);

--
-- Constraints for table `blacklist`
--
ALTER TABLE `blacklist`
ADD CONSTRAINT `blacklist_ibfk_1` FOREIGN KEY (`memberID`) REFERENCES `member` (`memberID`);

--
-- Constraints for table `book`
--
ALTER TABLE `book`
ADD CONSTRAINT `fk_bookLanguageID` FOREIGN KEY (`bookLanguageID`) REFERENCES `book_language` (`bookLanguageID`),
ADD CONSTRAINT `fk_typeBookID` FOREIGN KEY (`typeBookID`) REFERENCES `type_book` (`typeBookID`);

--
-- Constraints for table `borrow`
--
ALTER TABLE `borrow`
ADD CONSTRAINT `fk_bookID` FOREIGN KEY (`bookID`) REFERENCES `book` (`bookID`),
ADD CONSTRAINT `fk_memberID` FOREIGN KEY (`memberID`) REFERENCES `member` (`memberID`);

--
-- Constraints for table `form`
--
ALTER TABLE `form`
ADD CONSTRAINT `form_ibfk_1` FOREIGN KEY (`memberID`) REFERENCES `member` (`memberID`);

--
-- Constraints for table `member`
--
ALTER TABLE `member`
ADD CONSTRAINT `member_ibfk_1` FOREIGN KEY (`emailID`) REFERENCES `email` (`emailID`),
ADD CONSTRAINT `member_ibfk_2` FOREIGN KEY (`contactID`) REFERENCES `contact` (`contactID`),
ADD CONSTRAINT `member_ibfk_3` FOREIGN KEY (`staffID`) REFERENCES `staff` (`staffID`);

--
-- Constraints for table `member_date_register`
--
ALTER TABLE `member_date_register`
ADD CONSTRAINT `member_date_register_ibfk_1` FOREIGN KEY (`memberID`) REFERENCES `member` (`memberID`);

--
-- Constraints for table `staff`
--
ALTER TABLE `staff`
ADD CONSTRAINT `fk_branchID` FOREIGN KEY (`branchID`) REFERENCES `branch` (`branchID`);

--
-- Constraints for table `total_warning`
--
ALTER TABLE `total_warning`
ADD CONSTRAINT `total_warning_ibfk_1` FOREIGN KEY (`memberID`) REFERENCES `member` (`memberID`);

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`root`@`localhost` EVENT `eventUpdateBorrowStatus` ON SCHEDULE EVERY 1 DAY STARTS '2017-05-09 02:06:06' ON COMPLETION NOT PRESERVE ENABLE DO UPDATE borrow SET borrowStatus='LAMBAT PULANG' WHERE
    returnDate = CURDATE() + INTERVAL 1 DAY$$

CREATE DEFINER=`root`@`localhost` EVENT `eventUpdateMemberStatus` ON SCHEDULE EVERY 1 DAY STARTS '2017-05-03 15:13:15' ON COMPLETION NOT PRESERVE ENABLE DO UPDATE member AS m
	INNER JOIN member_date_register AS mdr ON m.memberID= mdr.memberID
	SET m.memberStatus = 'TAMAT TEMPOH'
	WHERE mdr.memberDateExpired = NOW()$$

CREATE DEFINER=`root`@`localhost` EVENT `eventAddYear` ON SCHEDULE EVERY 1 YEAR STARTS '2018-01-01 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO INSERT INTO statistic_year VALUE ('', YEAR(NOW()))$$

DELIMITER ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
