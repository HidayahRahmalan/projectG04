var chart = AmCharts.makeChart( "chartdivMuet", {
      "type": "pie",
      "theme": "light",
      "dataProvider": [ {
        "Band Type": "Band 1",
        "Total": 6
      }, {
        "Band Type": "Band 2",
        "Total": 10
      }, {
        "Band Type": "Band 3",
        "Total": 50
      }, {
        "Band Type": "Band 4",
        "Total": 61
      }, {
        "Band Type": "Band 5",
        "Total": 18
      },{
        "Band Type": "Band 6",
        "Total": 13
      } ],
      "valueField": "Total",
      "titleField": "Band Type",
       "balloon":{
       "fixedPosition":true
      },
      "export": {
        "enabled": true
      }
    } );

    var chart = AmCharts.makeChart( "chartdivStudent", {
      "type": "pie",
      "theme": "light",
      "dataProvider": [ {
        "Student Type": "Diploma",
        "Total": 324
      }, {
        "Student Type": "Degree",
        "Total": 1552
      }, {
        "Student Type": "Post Graduate",
        "Total": 206
      },],
      "valueField": "Total",
      "titleField": "Student Type",
       "balloon":{
       "fixedPosition":true
      },
      "export": {
        "enabled": true
      }
    } );