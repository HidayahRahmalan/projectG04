var chart = AmCharts.makeChart("chartdivFacultyIncome", {
        "type": "serial",
         "theme": "light",
        "categoryField": "year",
        "rotate": true,
        "startDuration": 1,
        "categoryAxis": {
            "gridPosition": "start",
            "position": "left"
        },
        "trendLines": [],
        "graphs": [
            {
                "balloonText": "Income:RM[[value]]",
                "fillAlphas": 0.8,
                "id": "AmGraph-1",
                "lineAlpha": 0.2,
                "title": "Income",
                "type": "column",
                "valueField": "income"
            },
            {
                "balloonText": "Expenses:RM[[value]]",
                "fillAlphas": 0.8,
                "id": "AmGraph-2",
                "lineAlpha": 0.2,
                "title": "Expenses",
                "type": "column",
                "valueField": "expenses"
            }
        ],
        "guides": [],
        "valueAxes": [
            {
                "id": "ValueAxis-1",
                "position": "top",
                "axisAlpha": 0
            }
        ],
        "allLabels": [],
        "balloon": {},
        "titles": [],
        "dataProvider": [
            {
                "year": 2012,
                "income": 23.50,
                "expenses": 18.1
            },
            {
                "year": 2013,
                "income": 26.20,
                "expenses": 22.80
            },
            {
                "year": 2014,
                "income": 30.10,
                "expenses": 23.90
            },
            {
                "year": 2015,
                "income": 29.50,
                "expenses": 25.10
            },
            {
                "year": 2016,
                "income": 24.60,
                "expenses": 25.00
            }
        ],
        "export": {
            "enabled": true
         }

    });