    //Bar Graph Student Attrim Rate
    var chart = AmCharts.makeChart("chartdivAttrimRate", {
    "type": "serial",
    "theme": "light",
    "legend": {
        "horizontalGap": 10,
        "maxColumns": 1,
        "position": "right",
        "useGraphSettings": true,
        "markerSize": 10
    },
    "dataProvider": [{
        "year": 2012,
        "value": 1200
    }, {
        "year": 2013,
        "value": 1250
    }, {
        "year": 2014,
        "value": 1240
    }, {
        "year": 2015,
        "value": 1250
    }, {
        "year": 2016,
        "value": 1650
    }],
    "valueAxes": [{
        "stackType": "regular",
        "axisAlpha": 0.3,
        "gridAlpha": 0
    }],
    "graphs": [{
        "balloonText": "<b>[[title]]</b><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>",
        "fillAlphas": 0.8,
        "labelText": "[[value]]",
        "lineAlpha": 0.3,
        "title": "Attrition Rate",
        "type": "column",
        "color": "#000000",
        "valueField": "value"
    }],
    "categoryField": "year",
    "categoryAxis": {
        "gridPosition": "start",
        "axisAlpha": 0,
        "gridAlpha": 0,
        "position": "left"
    },
    "export": {
        "enabled": true
     }

});



//Bar Graph GOT
    var chart = AmCharts.makeChart("chartdivGOT", {
    "type": "serial",
    "theme": "light",
    "legend": {
        "horizontalGap": 10,
        "maxColumns": 1,
        "position": "right",
        "useGraphSettings": true,
        "markerSize": 10
    },
    "dataProvider": [{
        "year": 2012,
        "value": 1200
    }, {
        "year": 2013,
        "value": 1250
    }, {
        "year": 2014,
        "value": 1240
    }, {
        "year": 2015,
        "value": 1250
    }, {
        "year": 2016,
        "value": 1650
    }],
    "valueAxes": [{
        "stackType": "regular",
        "axisAlpha": 0.3,
        "gridAlpha": 0
    }],
    "graphs": [{
        "balloonText": "<b>[[title]]</b><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>",
        "fillAlphas": 0.8,
        "labelText": "[[value]]",
        "lineAlpha": 0.3,
        "title": "GOT",
        "type": "column",
        "color": "#000000",
        "valueField": "value"
    }],
    "categoryField": "year",
    "categoryAxis": {
        "gridPosition": "start",
        "axisAlpha": 0,
        "gridAlpha": 0,
        "position": "left"
    },
    "export": {
        "enabled": true
     }

});