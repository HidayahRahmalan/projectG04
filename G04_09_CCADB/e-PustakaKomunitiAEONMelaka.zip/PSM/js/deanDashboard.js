var chart = AmCharts.makeChart( "chartdivStaff", {
      "type": "pie",
      "theme": "light",
      "dataProvider": [ {
        "Staff Type": "Professor",
        "Total": 6
      }, {
        "Staff Type": "Associates Professor",
        "Total": 10
      }, {
        "Staff Type": "Phd",
        "Total": 50
      }, {
        "Staff Type": "Msc",
        "Total": 61
      }, {
        "Staff Type": "Technician",
        "Total": 18
      },{
        "Staff Type": "Admin Staff",
        "Total": 13
      } ],
      "valueField": "Total",
      "titleField": "Staff Type",
       "balloon":{
       "fixedPosition":true
      },
      "export": {
        "enabled": true
      }
    } );

    var chart = AmCharts.makeChart( "chartdivStudent", {
      "type": "pie",
      "theme": "light",
      "dataProvider": [ {
        "Student Type": "Diploma",
        "Total": 324
      }, {
        "Student Type": "Degree",
        "Total": 1552
      }, {
        "Student Type": "Post Graduate",
        "Total": 206
      },],
      "valueField": "Total",
      "titleField": "Student Type",
       "balloon":{
       "fixedPosition":true
      },
      "export": {
        "enabled": true
      }
    } );