//Muet Student Pie Chart
var chart = AmCharts.makeChart( "chartdivMuet", {
      "type": "pie",
      "theme": "light",
      "dataProvider": [ {
        "Band Type": "Band 1",
        "Total": 6
      }, {
        "Band Type": "Band 2",
        "Total": 10
      }, {
        "Band Type": "Band 3",
        "Total": 50
      }, {
        "Band Type": "Band 4",
        "Total": 61
      }, {
        "Band Type": "Band 5",
        "Total": 18
      },{
        "Band Type": "Band 6",
        "Total": 13
      } ],
      "valueField": "Total",
      "titleField": "Band Type",
       "balloon":{
       "fixedPosition":true
      },
      "export": {
        "enabled": true
      }
    } );


//Local Student Pie Chart
var chart = AmCharts.makeChart( "chartdivLocal", {
      "type": "pie",
      "theme": "light",
      "dataProvider": [ {
        "Student Type": "Diploma",
        "Total": 324
      }, {
        "Student Type": "Degree",
        "Total": 1552
      }, {
        "Student Type": "Post Graduate",
        "Total": 206
      },],
      "valueField": "Total",
      "titleField": "Student Type",
       "balloon":{
       "fixedPosition":true
      },
      "export": {
        "enabled": true
      }
    } );

    var chart = AmCharts.makeChart( "chartdivInternational", {
      "type": "pie",
      "theme": "light",
      "dataProvider": [ {
        "Student Type": "Under Graduate",
        "Total": 22
      },{
        "Student Type": "Post Graduate",
        "Total": 51
      } ],
      "valueField": "Total",
      "titleField": "Student Type",
       "balloon":{
       "fixedPosition":true
      },
      "export": {
        "enabled": true
      }
    } );

    //Bar Graph Academic
    var chart = AmCharts.makeChart("chartdivBarGraph", {
    "type": "serial",
    "theme": "light",
    "legend": {
        "horizontalGap": 10,
        "maxColumns": 1,
        "position": "right",
        "useGraphSettings": true,
        "markerSize": 10
    },
    "dataProvider": [{
        "year": 2012,
        "diploma": 1200,
        "degree": 2500,
        "master": 120,
        "phd": 100
    }, {
        "year": 2013,
        "diploma": 1250,
        "degree": 2900,
        "master": 240,
        "phd": 230
    }, {
        "year": 2014,
        "diploma": 1240,
        "degree": 2400,
        "master": 140,
        "phd": 120
    }, {
        "year": 2015,
        "diploma": 1250,
        "degree": 2200,
        "master": 200,
        "phd": 130
    }, {
        "year": 2016,
        "diploma": 1650,
        "degree": 1900,
        "master": 200,
        "phd": 130
    }],
    "valueAxes": [{
        "stackType": "regular",
        "axisAlpha": 0.3,
        "gridAlpha": 0
    }],
    "graphs": [{
        "balloonText": "<b>[[title]]</b><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>",
        "fillAlphas": 0.8,
        "labelText": "[[value]]",
        "lineAlpha": 0.3,
        "title": "Diploma",
        "type": "column",
        "color": "#000000",
        "valueField": "diploma"
    }, {
        "balloonText": "<b>[[title]]</b><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>",
        "fillAlphas": 0.8,
        "labelText": "[[value]]",
        "lineAlpha": 0.3,
        "title": "Degree",
        "type": "column",
        "color": "#000000",
        "valueField": "degree"
    }, {
        "balloonText": "<b>[[title]]</b><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>",
        "fillAlphas": 0.8,
        "labelText": "[[value]]",
        "lineAlpha": 0.3,
        "title": "Master",
        "type": "column",
        "color": "#000000",
        "valueField": "master"
    }, {
        "balloonText": "<b>[[title]]</b><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>",
        "fillAlphas": 0.8,
        "labelText": "[[value]]",
        "lineAlpha": 0.3,
        "title": "Phd",
        "type": "column",
        "color": "#000000",
        "valueField": "phd"
    }],
    "categoryField": "year",
    "categoryAxis": {
        "gridPosition": "start",
        "axisAlpha": 0,
        "gridAlpha": 0,
        "position": "left"
    },
    "export": {
        "enabled": true
     }

});