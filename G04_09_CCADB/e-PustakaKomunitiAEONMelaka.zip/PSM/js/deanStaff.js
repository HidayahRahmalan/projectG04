var chart = AmCharts.makeChart( "chartdiv", {
      "type": "pie",
      "theme": "light",
      "dataProvider": [ {
        "Staff Type": "Professor",
        "Total": 6
      }, {
        "Staff Type": "Associates Professor",
        "Total": 10
      }, {
        "Staff Type": "Phd",
        "Total": 50
      }, {
        "Staff Type": "Msc",
        "Total": 61
      }, {
        "Staff Type": "Technician",
        "Total": 18
      },{
        "Staff Type": "Admin Staff",
        "Total": 13
      } ],
      "valueField": "Total",
      "titleField": "Staff Type",
       "balloon":{
       "fixedPosition":true
      },
      "export": {
        "enabled": true
      }
    } );

    var chart = AmCharts.makeChart( "chartdivAcademic", {
      "type": "pie",
      "theme": "light",
      "dataProvider": [ {
        "Staff Type": "Professor",
        "Total": 6
      }, {
        "Staff Type": "Associates Professor",
        "Total": 10
      }, {
        "Staff Type": "Phd",
        "Total": 50
      }, {
        "Staff Type": "Msc",
        "Total": 61
      }],
      "valueField": "Total",
      "titleField": "Staff Type",
       "balloon":{
       "fixedPosition":true
      },
      "export": {
        "enabled": true
      }
    } );

    var chart = AmCharts.makeChart( "chartdivNonAcademic", {
      "type": "pie",
      "theme": "light",
      "dataProvider": [ {
        "Staff Type": "Technician",
        "Total": 18
      },{
        "Staff Type": "Admin Staff",
        "Total": 13
      } ],
      "valueField": "Total",
      "titleField": "Staff Type",
       "balloon":{
       "fixedPosition":true
      },
      "export": {
        "enabled": true
      }
    } );