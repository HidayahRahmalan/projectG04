<script>
//Print Function Jantina
function printDivJantina(divName) {
 var printContents = document.getElementById(divName).innerHTML;
 var originalContents = document.body.innerHTML;

 document.body.innerHTML = printContents;

 window.print();

 document.body.innerHTML = originalContents;
}  

//Print Function Kategori
function printDivKategori(divName) {
 var printContents = document.getElementById(divName).innerHTML;
 var originalContents = document.body.innerHTML;

 document.body.innerHTML = printContents;

 window.print();

 document.body.innerHTML = originalContents;
}    

//Print Function Etnik
function printDivEtnik(divName) {
 var printContents = document.getElementById(divName).innerHTML;
 var originalContents = document.body.innerHTML;

 document.body.innerHTML = printContents;

 window.print();

 document.body.innerHTML = originalContents;
}       

// Graph Pecahan Mengikut Jantina
var chart = AmCharts.makeChart("chartdivJantina", {
    "type": "serial",
     "theme": "light",
    "categoryField": "bulan",
    "rotate": true,
    "startDuration": 1,
    "categoryAxis": {
        "gridPosition": "start",
        "position": "left"
    },
    "trendLines": [],
    "graphs": [
        {
            "balloonText": "Lelaki:[[value]]",
            "fillAlphas": 0.8,
            "id": "AmGraph-1",
            "lineAlpha": 0.2,
            "title": "Lelaki",
            "type": "column",
            "valueField": "Lelaki"
        },
        {
            "balloonText": "Perempuan:[[value]]",
            "fillAlphas": 0.8,
            "id": "AmGraph-2",
            "lineAlpha": 0.2,
            "title": "Perempuan",
            "type": "column",
            "valueField": "Perempuan"
        }
    ],
    "guides": [],
    "valueAxes": [
        {
            "id": "ValueAxis-1",
            "position": "top",
            "axisAlpha": 0
        }
    ],
    "allLabels": [],
    "balloon": {},
    "titles": [],
    "dataProvider": [
        <?php
          include("../connection/config.php");
          $year = date("Y");
          $select=mysql_query("CALL statisticNewMember('$year')")or die(mysql_error());

          while($row=mysql_fetch_array($select))
          {
           $month = $row['month'];
           $totalMale = $row['totalMale'];
           $totalFemale = $row['totalFemale'];
           echo'{
                   "bulan": "'.$month.'",
                   "Lelaki": '.$totalMale.',
                   "Perempuan": '.$totalFemale.'
                },';
          }
          mysql_close($con);
        ?>
    ],
    "export": {
        "enabled": true
     }

});


// Graph Pecahan Mengikut Kategori
var chart = AmCharts.makeChart("chartDivKategori", {
    "type": "serial",
     "theme": "light",
    "categoryField": "bulan",
    "rotate": true,
    "startDuration": 1,
    "categoryAxis": {
        "gridPosition": "start",
        "position": "left"
    },
    "trendLines": [],
    "graphs": [
        {
            "balloonText": "Dewasa:[[value]]",
            "fillAlphas": 0.8,
            "id": "AmGraph-1",
            "lineAlpha": 0.2,
            "title": "Dewasa",
            "type": "column",
            "valueField": "Dewasa"
        },
        {
            "balloonText": "Belia:[[value]]",
            "fillAlphas": 0.8,
            "id": "AmGraph-2",
            "lineAlpha": 0.2,
            "title": "Belia",
            "type": "column",
            "valueField": "Belia"
        },
        {
            "balloonText": "Kanak-Kanak:[[value]]",
            "fillAlphas": 0.8,
            "id": "AmGraph-3",
            "lineAlpha": 0.2,
            "title": "Kanak-Kanak",
            "type": "column",
            "valueField": "Kanak-Kanak"
        }
    ],
    "guides": [],
    "valueAxes": [
        {
            "id": "ValueAxis-1",
            "position": "top",
            "axisAlpha": 0
        }
    ],
    "allLabels": [],
    "balloon": {},
    "titles": [],
    "dataProvider": [
        <?php
          include("../connection/config.php");
          $year = date("Y");
          $select=mysql_query("CALL statisticNewMember('$year')")or die(mysql_error());

          while($row=mysql_fetch_array($select))
          {
           $month = $row['month'];
           $adult = $row['adult'];
           $youth = $row['youth'];
           $kid = $row['kid'];
           echo'{
                   "bulan": "'.$month.'",
                   "Dewasa": '.$adult.',
                   "Belia": '.$youth.',
                   "Kanak-Kanak": '.$kid.'
                },';
          }
          mysql_close($con);
         ?>
    ],
    "export": {
        "enabled": true
     }

});

// Graph Pecahan Mengikut Etnik
var chart = AmCharts.makeChart("chartdivEtnik", {
    "type": "serial",
     "theme": "light",
    "categoryField": "bulan",
    "rotate": true,
    "startDuration": 1,
    "categoryAxis": {
        "gridPosition": "start",
        "position": "left"
    },
    "trendLines": [],
    "graphs": [
        {
            "balloonText": "Melayu:[[value]]",
            "fillAlphas": 0.8,
            "id": "AmGraph-1",
            "lineAlpha": 0.2,
            "title": "Melayu",
            "type": "column",
            "valueField": "Melayu"
        },
        {
            "balloonText": "Cina:[[value]]",
            "fillAlphas": 0.8,
            "id": "AmGraph-2",
            "lineAlpha": 0.2,
            "title": "Cina",
            "type": "column",
            "valueField": "Cina"
        },
        {
            "balloonText": "India:[[value]]",
            "fillAlphas": 0.8,
            "id": "AmGraph-3",
            "lineAlpha": 0.2,
            "title": "India",
            "type": "column",
            "valueField": "India"
        },
        {
            "balloonText": "Lain:[[value]]",
            "fillAlphas": 0.8,
            "id": "AmGraph-4",
            "lineAlpha": 0.2,
            "title": "Lain",
            "type": "column",
            "valueField": "Lain"
        }
    ],
    "guides": [],
    "valueAxes": [
        {
            "id": "ValueAxis-1",
            "position": "top",
            "axisAlpha": 0
        }
    ],
    "allLabels": [],
    "balloon": {},
    "titles": [],
    "dataProvider": [
        <?php
          include("../connection/config.php");
          $year = date("Y");
          $select=mysql_query("CALL statisticNewMember('$year')")or die(mysql_error());

          while($row=mysql_fetch_array($select))
          {
           $month = $row['month'];
           $raceMelayu = $row['raceMelayu'];
           $raceCina = $row['raceCina'];
           $raceIndia = $row['raceIndia'];
           $raceOther = $row['raceOther'];
           echo'{
                   "bulan": "'.$month.'",
                   "Melayu": '.$raceMelayu.',
                   "Cina": '.$raceCina.',
                   "India": '.$raceIndia.',
                   "Lain": '.$raceOther.'
                },';
          }
          mysql_close($con);
         ?>
    ],
    "export": {
        "enabled": true
     }

});
</script>

<style>
.amcharts-chart-div a {
display:none !important;
}
#chartdivJantina {
width       : 100%;
height      : 500px;
font-size   : 11px;
}
#chartdivEtnik {
width       : 100%;
height      : 600px;
font-size   : 11px;
}
#chartDivKategori {
width       : 100%;
height      : 600px;
font-size   : 11px;
}
</style>