<?php
include("../connection/config.php");
$year = date("Y");

//Total Adult
$totalAdultYearly=mysql_query("CALL statisticTotalAdultYearly('$year')")or die(mysql_error());
$get = mysql_fetch_assoc($totalAdultYearly);
$totalAdult = $get['totalAdult'];
mysql_close($con);

include("../connection/config.php");
//Total Youth
$totalYouthYearly=mysql_query("CALL statisticTotalYouthYearly('$year')")or die(mysql_error());
$get1 = mysql_fetch_assoc($totalYouthYearly);
$totalYouth = $get1['totalYouth'];
mysql_close($con);

include("../connection/config.php");
//Total Adult
$totalKidYearly=mysql_query("CALL statisticTotalKidYearly('$year')")or die(mysql_error());
$get2 = mysql_fetch_assoc($totalKidYearly);
$totalKid = $get2['totalKid'];
mysql_close($con);
?>
<script>
 //Print Function Kategori
function printDivKategori(divName) {
 document.getElementById("buttonAreaKategori").hidden="hidden";
 var printContents = document.getElementById(divName).innerHTML;
 var originalContents = document.body.innerHTML;

 document.body.innerHTML = printContents;

 window.print();

 document.body.innerHTML = originalContents;
}       

//Pie Chart Peminjam Pecahan Kategori
var chart = AmCharts.makeChart( "chartDivKategori", {
      "type": "pie",
      "theme": "light",
      "dataProvider": [
       {
        "Kategori": "Dewasa",
        "Total": <?php echo $totalAdult; ?>
      }, {
        "Kategori": "Belia",
        "Total": <?php echo $totalYouth; ?>
      }, {
        "Kategori": "Kanak-Kanak",
        "Total": <?php echo $totalKid; ?>
      } ],
      "valueField": "Total",
      "titleField": "Kategori",
       "balloon":{
       "fixedPosition":true
      },
      "export": {
        "enabled": true
      }
    } );
</script>

<style>
.amcharts-chart-div a {
display:none !important;
}
#chartDivKategori {
width: 100%;
height: 375px;
}
</style>