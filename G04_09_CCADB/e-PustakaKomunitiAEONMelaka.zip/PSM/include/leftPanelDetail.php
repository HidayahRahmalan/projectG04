<html>
<head></head>

	<body>
		<table border="0" width="100%">
            <tr>
                <td colspan="2" width="50%" align="center">
                <?php
                $staffImg = $profileUsersData['staffImg'];
                if($staffImg != NULL){
                echo "<img src=data:image/png;base64,". base64_encode($profileUsersData['staffImg']) ." class='img-circle' alt='User Image' width='120px' height='120px'/>";
                }else{
                echo "<img src='../images/unknown.png' class='img-circle' alt='User Image' width='120px' height='120px'/>";
                }
                ?>
                </td>
            </tr>
            <tr>
                <td colspan="2"><br/></td>
            </tr>
            <tr>
                <td align="right" valign="top"><b>Nama :</b></td><td><b> <?php echo $profileUsersData['staffName']; ?> </b></td>
            </tr>
            <tr>
                <td align="right" valign="top"><b>ID :</b></td><td><b> <?php echo $profileUsersData['staffID']; ?> </b></td>
            </tr>
            <tr>
                <td align="right" valign="top"><b>Jawatan :</b></td><td><b> <?php echo $profileUsersData['staffPosition']; ?> </b></td>
            </tr>
	    </table>
	</body>
	
</html>