<?php 

$memberStatus = $profileUsersData['memberStatus'];

if($memberStatus == 'SAH' || $memberStatus == 'LAMBAT PULANG'){
echo'
<li>
    <a href="lamanUtamaMember.php"><i class="fa fa-info fa-fw"></i> Laman Utama </a>
</li>
<li>
    <a href="carianBuku.php"><i class="fa fa-book fa-fw"></i> Carian Buku</a>
</li>
<li>
    <a href="logPinjamanBukuMember.php"><i class="fa fa-list-alt fa-fw"></i> Log Pinjaman</a>
</li>
';
}

if($memberStatus == 'DALAM PROSES' || $memberStatus == 'TIDAK SAH'){
echo'
<li>
    <a href="lamanUtamaMember.php"><i class="fa fa-info fa-fw"></i> Laman Utama</a>
</li>
<li>
    <a href="borangPengesahan.php"><span class="blink_text"><i class="fa fa-edit fa-fw"></i> Borang Cop Pengesahan</a></span>
</li>
';
}

if($memberStatus == 'PROSES SENARAI HITAM' || $memberStatus == 'SENARAI HITAM'){
echo'
<li>
    <a href="lamanUtamaMember.php"><i class="fa fa-info fa-fw"></i> Laman Utama</a>
</li>
<li>
    <a href="logPinjamanBukuMember.php"><i class="fa fa-list-alt fa-fw"></i> Log Pinjaman</a>
</li>
';
}

if($memberStatus == 'TAMAT TEMPOH'){
echo'
<li>
    <a href="#"><span class="blink_text"><i class="fa fa-info fa-fw"></i> Sila Perbaharui Keahlian</span></a>
</li>
';
}
?>