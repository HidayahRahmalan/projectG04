<?php
  error_reporting(E_ALL & ~E_NOTICE & ~8192);
  include("../connection/config.php");

  $memberID=$_GET['memberID'];

  //Get Detail Member
  $getDetailMember = mysql_query("CALL getDetailMember('$memberID')");
  $get = mysql_fetch_assoc($getDetailMember);
  $memberType = $get['memberType'];
  mysql_close($con);

    include("../connection/config.php");
    $select=mysql_query("CALL incGetListBook('$memberID')")or die(mysql_error());

    echo' <label>Senarai Pinjaman Buku</label>
          <table class="table">
          <thead>
            <tr>
                <th>#</th>
                <th>Judul Buku</th>
                <th>Tarikh Pinjaman</th>
                <th>Tarikh Pemulangan</th>
                <th>Status Pinjaman</th>
            </tr>
          </thead>';

    while($row=mysql_fetch_array($select))
    {
    $bill++;
    $bookTitle = $row['bookTitle'];
    $bookID = $row['bookID'];
    $borrowDateTemp = $row['borrowDate'];
    $borrowDate = date("d/m/Y", strtotime($borrowDateTemp));
    $returnDateTemp = $row['returnDate'];
    $returnDate = date("d/m/Y", strtotime($returnDateTemp));
    $borrowStatus = $row['borrowStatus'];
    $memberID = $row['memberID'];
     echo '<tr>
            <td>'.$bill.'</td>
            <td>'.$bookTitle.'</td>
            <td>'.$borrowDate.'</td>
            <td>'.$returnDate.'</td>
            <td><label style="color:red">'.$borrowStatus.'</label></td>
           </tr>';
    }
    echo'</table><br>';
    if($memberType == 'DEWASA'){
    echo'<div class="form-group">
            <label>Tarikh Hantar InfoBlast 1</label>
            <input type="date" name="infoBlastDateDewasa" class="form-control" style="width:150px" required>
            <input type="hidden" name="memberID" value="'.$memberID.'" class="form-control" style="width:150px">
        </div>
        <button type="submit" name="btnHantarInfoBlastDewasa" class="btn btn-default">Hantar InfoBlast 1</button>';
    }

    if($memberType == 'KANAK-KANAK'){
    echo'
    <div class="form-group">
            <label>Tarikh Hantar Notis ke Sekolah</label>
            <input type="date" name="noticeDate" class="form-control" style="width:150px" required>
            <input type="hidden" name="memberID" value="'.$memberID.'" class="form-control" style="width:150px">
        </div>
        <button type="submit" name="btnHantarNotis" class="btn btn-default">Hantar Notis</button>';
    }

    if($memberType == 'BELIA'){
    echo'<div class="form-group">
            <label>Tarikh Hantar InfoBlast 1</label>
            <input type="date" name="infoBlastDateBelia" class="form-control" style="width:150px" required>
            <input type="hidden" name="memberID" value="'.$memberID.'" class="form-control" style="width:150px">
        </div>
        <button type="submit" name="btnHantarInfoBlastBelia" class="btn btn-default">Hantar InfoBlast 1</button>';
    }

    mysql_close($con);

 ?>