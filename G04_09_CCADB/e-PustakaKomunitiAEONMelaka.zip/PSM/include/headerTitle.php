<html>
	<head></head>

	<body>
	<table>
	<tr>
		<td style="padding-left: 5px"><img src="../images/logoPerpustam2.png" width="35px" height="35px" alt="logo"></td>
		<td><a class="navbar-brand" href="#">e-Perpustakaan Komuniti AEON Bandaraya Melaka</a></td>
	</tr>
	</table>
	</body>

</html>