<html>
<head></head>

	<body>
		<table border="0" width="100%">
            <tr>
                <td colspan="2" width="50%" align="center">
                    <?php
                    $memberGender = $profileUsersData['memberGender'];

                    if($memberGender == 'LELAKI'){  
                        echo'<img src="../images/male.jpg" class="img-circle" alt="User Image" width="120px" height="120px"/>';
                    }else{
                        echo'<img src="../images/women.jpg" class="img-circle" alt="User Image" width="120px" height="120px"/>';
                    }
                    ?>
                </td>
            </tr>
            <tr>
                <td colspan="2"><br/></td>
            </tr>
            <tr>
                <td align="right" valign="top"><b>Nama :</b></td><td><b> <?php echo $profileUsersData['memberName']; ?> </b></td>
            </tr>
            <tr>
                <td align="right" valign="top"><b>ID :</b></td><td><b> <?php echo $profileUsersData['memberID']; ?> </b></td>
            </tr>
	    </table>
	</body>
	
</html>