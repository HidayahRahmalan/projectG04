<?php 

$staffID = $profileUsersData['staffID'];
$staffRowLevel = $profileUsersData['staffRowLevel'];

if($staffRowLevel == 1){
echo'
<li>
    <a href="lamanUtamaAdmin.php"><i class="fa fa-home fa-fw"></i> Laman Utama</a>
</li>
<li>
    <a href="penggunaSistem.php"><i class="fa fa-group fa-fw"></i> Pengguna Sistem</a>
</li>
<li>
    <a href="cawanganAdmin.php"><i class="fa fa-sitemap fa-fw"></i> Cawangan</a>
</li>
<li>
    <a href="backupPangkalanData.php"><i class="fa fa-database fa-fw"></i> Backup Pangkalan Data</a>
</li>
<li>
<a href="pemulihanData.php"><i class="fa fa-cloud-upload fa-fw"></i> Pemulihan Data</a>
</li>
<li>
<a href="backupData.php"><i class="fa fa-cloud-download fa-fw"></i> Backup Keseluruhan Data</a>
</li>
';
}

if($staffRowLevel == 2){
echo'
<li>
    <a href="lamanUtamaStaf.php"><i class="fa fa-home fa-fw"></i> Laman Utama</a>
</li>
<li>
    <a href="#"><i class="fa fa-group fa-fw"></i> Ahli<span class="fa arrow"></span></a>
    <ul class="nav nav-second-level">
        <li>
            <a href="ahliBaru.php"><i class="fa fa-plus-circle fa-fw"></i> Ahli Baru</a>
        </li>
        <li>
            <a href="senaraiAhli.php"><i class="fa fa-th-list fa-fw"></i> Senarai Ahli</a>
        </li>
        <li>
            <a href="ahliSenaraiHitam.php"><i class="fa fa-ban fa-fw"></i> Ahli Senarai Hitam</a>
        </li>
    </ul>
    <!-- /.nav-second-level -->
</li>
<li>
    <a href="kedatanganPengunjung.php"><i class="fa fa-list-alt fa-fw"></i> Kedatangan Pengunjung</a>
</li>
<li>
    <a href="#"><i class="fa fa-book fa-fw"></i> Buku<span class="fa arrow"></span></a>
    <ul class="nav nav-second-level">
        <li>
            <a href="pinjamanPulanganBuku.php"><i class="fa fa-edit fa-fw"></i> Pinjaman/Pulangan Buku</a>
        </li>
        <li>
            <a href="inventoriBuku.php"><i class="fa fa-save fa-fw"></i> Inventori Buku</a>
        </li>
    </ul>
    <!-- /.nav-second-level -->
</li>
<li>
    <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Statistik<span class="fa arrow"></span></a>
    <ul class="nav nav-second-level">
        <li>
            <a href="#"><i class="fa fa-book fa-fw"></i> Pinjaman Buku <span class="fa arrow"></span></a>
            <ul class="nav nav-third-level">
                <li>
                    <a href="statistikPinjamanBukuUmum.php">Pinjaman Buku (Umum)</a>
                </li>
                <li>
                    <a href="statistikPinjamanBukuKategori.php">Pinjaman Buku (Kategori)</a>
                </li>
            </ul>
            <!-- /.nav-third-level -->
        </li>
        <li>
            <a href="statistikPengunjung.php"><i class="fa fa-group fa-fw"></i> Pengunjung</a>
        </li>   
        <li>
            <a href="statistikPendaftaranAhliBaru.php"><i class="fa fa-user fa-fw"></i> Pendaftaran Ahli Baru</a>
        </li>
    </ul>
    <!-- /.nav-second-level -->
</li>
';
}
?>