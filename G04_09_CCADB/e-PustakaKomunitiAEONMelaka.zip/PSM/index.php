<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Login | Portal Perpustakaan Komuniti AEON Bandaraya Melaka </title>
    <!-- Tab icon -->
    <link rel="shortcut icon" href="images/iconTab.ico" type="image/x-icon">
    <link href="css/loginStyle.css" rel="stylesheet" type="text/css"></link>
  </head>

  <body>
  <header id = "header">
  	<nav id="main menu" class="navbar navbar-default navbar-fixed-top" role="banner">
  	<div class="container">
  		<div class="navbar-header">
  				<a class="logo-brand2" href="#"><img src="images/logoPerpustam2.png" width="110" alt="logo" style="padding-top:10px"></a>
  		</div>
   	</div>
  	</nav>
  </header>

    <div class="body"></div>
		<div class="grad">
        	<h1>e-Perpustakaan Komuniti AEON Bandaraya Melaka</h1>
        </div>
		<div class="header">
			<div></div>
		</div>
		<br>
		<div class="login">
        <div id="result"></div>
        <form action="function/fnLogMasuk.php" method="POST">
          <input style="color:#454545" type="text" placeholder="Pengguna ID" name="staffID" required><br>
          <input style="color:#454545" type="password" placeholder="Kata Laluan" name="password" required>
          <input type="submit" name="btnLogin" value="Log Masuk">
          </form>
		</div>

    <div class="footer">
			<div>Copyright &copy; 2017-2018 UTeM | by <a href="http://ftmk.utem.edu.my" style="color:white">FTMK</a></div>
		</div>
    
    
  </body>
</html>
