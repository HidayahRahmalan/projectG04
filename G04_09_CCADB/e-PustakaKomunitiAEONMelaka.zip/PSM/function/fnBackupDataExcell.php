<?php
error_reporting(E_ALL & ~E_NOTICE & ~8192);
$tableName = $_GET['tableName'];
$date = date("d/m/Y");



if($tableName == 'attendance'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertAttendanceBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php');
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
    	  
    	// HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);
        $worksheet1->set_column(1, 4, 20);
        $worksheet1->set_column(1, 5, 30);

    	$qryreport = mysql_query("CALL getExcellBackupAttendance()") or die(mysql_error());
    	
    	$sqlrows=mysql_num_rows($qryreport);
    	$j=0;
    	
    	while ($reportdisp=mysql_fetch_array($qryreport)){
    	$j=$j+1;

        $attendanceID=$reportdisp['attendanceID'];
        $attendanceDate=$reportdisp['attendanceDate'];
        $attendanceTime=$reportdisp['attendanceTime'];
        $staffID=$reportdisp['staffID'];
        $attendanceRace=$reportdisp['attendanceRace'];
        $attendanceGender=$reportdisp['attendanceGender'];
        $attendanceCategory=$reportdisp['attendanceCategory'];
        $attendanceTotal=$reportdisp['attendanceTotal'];

        $worksheet1->write_string($j,0,"$attendanceID");
        $worksheet1->write_string($j,1,"$attendanceDate");
        $worksheet1->write_string($j,2,"$attendanceTime");
        $worksheet1->write_string($j,3,"$staffID");
        $worksheet1->write_string($j,4,"$attendanceRace");
        $worksheet1->write_string($j,5,"$attendanceGender");
        $worksheet1->write_string($j,6,"$attendanceCategory");
        $worksheet1->write_string($j,7,"$attendanceTotal");
    	}

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'attendance_statistic'){

      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertAttendanceStatisticBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php');
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel('attStat('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet('attStat('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);
        $worksheet1->set_column(1, 4, 20);
        $worksheet1->set_column(1, 5, 30);

        $qryreport = mysql_query("CALL getExcellBackupAttendanceStatistic()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $attendanceStatisticID=$reportdisp['attendanceStatisticID'];
        $month=$reportdisp['month'];
        $monthNum=$reportdisp['monthNum'];
        $year=$reportdisp['year'];
        $totalMale=$reportdisp['totalMale'];
        $totalFemale=$reportdisp['totalFemale'];
        $raceMelayu=$reportdisp['raceMelayu'];
        $raceCina=$reportdisp['raceCina'];
        $raceIndia=$reportdisp['raceIndia'];
        $raceOther=$reportdisp['raceOther'];
        $adult=$reportdisp['adult'];
        $youth=$reportdisp['youth'];
        $kid=$reportdisp['kid'];

        $worksheet1->write_string($j,0,"$attendanceStatisticID");
        $worksheet1->write_string($j,1,"$month");
        $worksheet1->write_string($j,2,"$monthNum");
        $worksheet1->write_string($j,3,"$year");
        $worksheet1->write_string($j,4,"$totalMale");
        $worksheet1->write_string($j,5,"$totalFemale");
        $worksheet1->write_string($j,6,"$raceMelayu");
        $worksheet1->write_string($j,7,"$raceCina");
        $worksheet1->write_string($j,8,"$raceIndia");
        $worksheet1->write_string($j,9,"$raceOther");
        $worksheet1->write_string($j,10,"$adult");
        $worksheet1->write_string($j,11,"$youth");
        $worksheet1->write_string($j,12,"$kid");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'audit_log'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertAuditLogBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php');
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);

        $qryreport = mysql_query("CALL getExcellBackupAuditLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $auditLogID=$reportdisp['auditLogID'];
        $staffID=$reportdisp['staffID'];
        $logInDate=$reportdisp['logInDate'];
        $logOutDate=$reportdisp['logOutDate'];

        $worksheet1->write_string($j,0,"$auditLogID");
        $worksheet1->write_string($j,1,"$staffID");
        $worksheet1->write_string($j,2,"$logInDate");
        $worksheet1->write_string($j,3,"$logOutDate");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'backup_log'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertBackupLogBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php');
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);

        $qryreport = mysql_query("CALL getExcellBackupBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $backupLogID=$reportdisp['backupLogID'];
        $tableBackup=$reportdisp['tableBackup'];
        $backupDateTime=$reportdisp['backupDateTime'];
        $descriptionBackup=$reportdisp['descriptionBackup'];

        $worksheet1->write_string($j,0,"$backupLogID");
        $worksheet1->write_string($j,1,"$tableBackup");
        $worksheet1->write_string($j,2,"$backupDateTime");
        $worksheet1->write_string($j,3,"$descriptionBackup");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'blacklist'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertBlacklistBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php');
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);

        $qryreport = mysql_query("CALL getExcellBlacklistBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $blacklistID=$reportdisp['blacklistID'];
        $memberID=$reportdisp['memberID'];
        $infoBlastDate1=$reportdisp['infoBlastDate1'];
        $infoBlastDate2=$reportdisp['infoBlastDate2'];
        $infoBlastDate3=$reportdisp['infoBlastDate3'];
        $noticeDate=$reportdisp['noticeDate'];
        $signBoardDate=$reportdisp['signBoardDate'];
        $warningDate=$reportdisp['warningDate'];

        $worksheet1->write_string($j,0,"$blacklistID");
        $worksheet1->write_string($j,1,"$memberID");
        $worksheet1->write_string($j,2,"$infoBlastDate1");
        $worksheet1->write_string($j,3,"$infoBlastDate2");
        $worksheet1->write_string($j,4,"$infoBlastDate3");
        $worksheet1->write_string($j,5,"$noticeDate");
        $worksheet1->write_string($j,6,"$signBoardDate");
        $worksheet1->write_string($j,7,"$warningDate");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'book'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertBookBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php'); 
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);

        $qryreport = mysql_query("CALL getExcellBookBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $bookID=$reportdisp['bookID'];
        $bookTitle=$reportdisp['bookTitle'];
        $bookISBN=$reportdisp['bookISBN'];
        $typeBookID=$reportdisp['typeBookID'];
        $author=$reportdisp['author'];
        $placeOfIssue=$reportdisp['placeOfIssue'];
        $publisher=$reportdisp['publisher'];
        $yearsOfIssue=$reportdisp['yearsOfIssue'];
        $noOfAcquisition=$reportdisp['noOfAcquisition'];
        $dateOfAcquisition=$reportdisp['dateOfAcquisition'];
        $callNo=$reportdisp['callNo'];
        $bookPrice=$reportdisp['bookPrice'];
        $registerDate=$reportdisp['registerDate'];
        $registerTime=$reportdisp['registerTime'];
        $bookLanguageID=$reportdisp['bookLanguageID'];
        $bookStatus=$reportdisp['bookStatus'];
        $memberID=$reportdisp['memberID'];

        $worksheet1->write_string($j,0,"$bookID");
        $worksheet1->write_string($j,1,"$bookTitle");
        $worksheet1->write_string($j,2,"$bookISBN");
        $worksheet1->write_string($j,3,"$typeBookID");
        $worksheet1->write_string($j,4,"$author");
        $worksheet1->write_string($j,5,"$placeOfIssue");
        $worksheet1->write_string($j,6,"$publisher");
        $worksheet1->write_string($j,7,"$yearsOfIssue");
        $worksheet1->write_string($j,8,"$noOfAcquisition");
        $worksheet1->write_string($j,9,"$dateOfAcquisition");
        $worksheet1->write_string($j,10,"$callNo");
        $worksheet1->write_string($j,11,"$bookPrice");
        $worksheet1->write_string($j,12,"$registerDate");
        $worksheet1->write_string($j,13,"$registerTime");
        $worksheet1->write_string($j,14,"$bookLanguageID");
        $worksheet1->write_string($j,15,"$bookStatus");
        $worksheet1->write_string($j,16,"$memberID");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'book_language'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertBookLanguageBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php'); 
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);

        $qryreport = mysql_query("CALL getExcellBookLanguageBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $bookLanguageID=$reportdisp['bookLanguageID'];
        $bookLanguageName=$reportdisp['bookLanguageName'];

        $worksheet1->write_string($j,0,"$bookLanguageID");
        $worksheet1->write_string($j,1,"$bookLanguageName");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'borrow'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertBorrowBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php'); 
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);

        $qryreport = mysql_query("CALL getExcellBorrowBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $borrowID=$reportdisp['borrowID'];
        $bookID=$reportdisp['bookID'];
        $memberID=$reportdisp['memberID'];
        $borrowStatus=$reportdisp['borrowStatus'];
        $borrowDate=$reportdisp['borrowDate'];
        $returnDate=$reportdisp['returnDate'];

        $worksheet1->write_string($j,0,"$borrowID");
        $worksheet1->write_string($j,1,"$bookID");
        $worksheet1->write_string($j,2,"$memberID");
        $worksheet1->write_string($j,3,"$borrowStatus");
        $worksheet1->write_string($j,4,"$borrowDate");
        $worksheet1->write_string($j,5,"$returnDate");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'borrow_statistic'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertBorrowStatisticBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php'); 
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);

        $qryreport = mysql_query("CALL getExcellBorrowStatisticBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $borrowStatisticID=$reportdisp['borrowStatisticID'];
        $month=$reportdisp['month'];
        $monthNum=$reportdisp['monthNum'];
        $year=$reportdisp['year'];
        $totalMale=$reportdisp['totalMale'];
        $totalFemale=$reportdisp['totalFemale'];
        $raceMelayu=$reportdisp['raceMelayu'];
        $raceCina=$reportdisp['raceCina'];
        $raceIndia=$reportdisp['raceIndia'];
        $raceOther=$reportdisp['raceOther'];
        $adult=$reportdisp['adult'];
        $youth=$reportdisp['youth'];
        $kid=$reportdisp['kid'];

        $worksheet1->write_string($j,0,"$borrowStatisticID");
        $worksheet1->write_string($j,1,"$month");
        $worksheet1->write_string($j,2,"$monthNum");
        $worksheet1->write_string($j,3,"$year");
        $worksheet1->write_string($j,4,"$totalMale");
        $worksheet1->write_string($j,5,"$totalFemale");
        $worksheet1->write_string($j,6,"$raceMelayu");
        $worksheet1->write_string($j,7,"$raceCina");
        $worksheet1->write_string($j,8,"$raceIndia");
        $worksheet1->write_string($j,9,"$raceOther");
        $worksheet1->write_string($j,10,"$adult");
        $worksheet1->write_string($j,11,"$youth");
        $worksheet1->write_string($j,12,"$kid");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'branch'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertBranchBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php'); 
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);

        $qryreport = mysql_query("CALL getExcellBranchBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $branchID=$reportdisp['branchID'];
        $branchName=$reportdisp['branchName'];

        $worksheet1->write_string($j,0,"$branchID");
        $worksheet1->write_string($j,1,"$branchName");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'contact'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertContactBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php'); 
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);

        $qryreport = mysql_query("") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $contactID=$reportdisp['contactID'];
        $contactFatherH=$reportdisp['contactFatherH'];
        $contactFatherO=$reportdisp['contactFatherO'];
        $contactFatherM=$reportdisp['contactFatherM'];
        $contactMotherH=$reportdisp['contactMotherH'];
        $contactMotherO=$reportdisp['contactMotherO'];
        $contactMotherM=$reportdisp['contactMotherM'];
        $contactSelfH=$reportdisp['contactSelfH'];
        $contactSelfO=$reportdisp['contactSelfO'];
        $contactSelfM=$reportdisp['contactSelfM'];

        $worksheet1->write_string($j,0,"$contactID");
        $worksheet1->write_string($j,1,"$contactFatherH");
        $worksheet1->write_string($j,2,"$contactFatherO");
        $worksheet1->write_string($j,3,"$contactFatherM");
        $worksheet1->write_string($j,4,"$contactMotherH");
        $worksheet1->write_string($j,5,"$contactMotherO");
        $worksheet1->write_string($j,6,"$contactMotherM");
        $worksheet1->write_string($j,7,"$contactSelfH");
        $worksheet1->write_string($j,8,"$contactSelfO");
        $worksheet1->write_string($j,9,"$contactSelfM");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'email'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertEmailBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php'); 
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);

        $qryreport = mysql_query("") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $emailID=$reportdisp['emailID'];
        $emailFather=$reportdisp['emailFather'];
        $emailMother=$reportdisp['emailMother'];
        $emailSelf=$reportdisp['emailSelf'];

        $worksheet1->write_string($j,0,"$emailID");
        $worksheet1->write_string($j,1,"$emailFather");
        $worksheet1->write_string($j,2,"$emailMother");
        $worksheet1->write_string($j,3,"$emailSelf");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'form'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertFormBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php'); 
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);

        $qryreport = mysql_query("CALL getExcellFormBackupLog") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $formID=$reportdisp['formID'];
        $memberID=$reportdisp['memberID'];
        $dateUpload=$reportdisp['dateUpload'];
        $formStatus=$reportdisp['formStatus'];
        $formComment=$reportdisp['formComment'];

        $worksheet1->write_string($j,0,"$formID");
        $worksheet1->write_string($j,1,"$memberID");
        $worksheet1->write_string($j,2,"$dateUpload");
        $worksheet1->write_string($j,3,"$formStatus");
        $worksheet1->write_string($j,4,"$formComment");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'member'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertMemberBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php'); 
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);

        $qryreport = mysql_query("CALL getExcellMemberBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $memberID=$reportdisp['memberID'];
        $memberName=$reportdisp['memberName'];
        $memberIC=$reportdisp['memberIC'];
        $memberBOD=$reportdisp['memberBOD'];
        $memberGender=$reportdisp['memberGender'];
        $memberRace=$reportdisp['memberRace'];
        $memberAddress=$reportdisp['memberAddress'];
        $emailID=$reportdisp['emailID'];
        $contactID=$reportdisp['contactID'];
        $memberType=$reportdisp['memberType'];
        $memberStatus=$reportdisp['memberStatus'];
        $staffID=$reportdisp['staffID'];
        $totalBorrow=$reportdisp['totalBorrow'];
        $memberPassword=$reportdisp['memberPassword'];
        $memberIDEncrypt=$reportdisp['memberIDEncrypt'];

        $worksheet1->write_string($j,0,"$memberID");
        $worksheet1->write_string($j,1,"$memberName");
        $worksheet1->write_string($j,2,"$memberIC");
        $worksheet1->write_string($j,3,"$memberBOD");
        $worksheet1->write_string($j,4,"$memberGender");
        $worksheet1->write_string($j,5,"$memberRace");
        $worksheet1->write_string($j,6,"$memberAddress");
        $worksheet1->write_string($j,7,"$emailID");
        $worksheet1->write_string($j,8,"$contactID");
        $worksheet1->write_string($j,9,"$memberType");
        $worksheet1->write_string($j,10,"$memberStatus");
        $worksheet1->write_string($j,11,"$staffID");
        $worksheet1->write_string($j,12,"$totalBorrow");
        $worksheet1->write_string($j,13,"$memberPassword");
        $worksheet1->write_string($j,14,"$memberIDEncrypt");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'member_date_register'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertMemberDateRegisterBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php'); 
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel('memberDateReg('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet('memberDateReg('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);

        $qryreport = mysql_query("CALL getExcellMemberDateRegisterBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $memberDateRegisterID=$reportdisp['memberDateRegisterID'];
        $memberDateRegister=$reportdisp['memberDateRegister'];
        $memberDateExpired=$reportdisp['memberDateExpired'];
        $memberID=$reportdisp['memberID'];
        $staffID=$reportdisp['staffID'];

        $worksheet1->write_string($j,0,"$memberDateRegisterID");
        $worksheet1->write_string($j,1,"$memberDateRegister");
        $worksheet1->write_string($j,2,"$memberDateExpired");
        $worksheet1->write_string($j,3,"$memberID");
        $worksheet1->write_string($j,4,"$staffID");
        }

    $workbook->close();
}

elseif($tableName == 'member_statistic'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertMemberStatisticBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php');
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel('memberStat('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet('memberStat('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);
        $worksheet1->set_column(1, 4, 20);
        $worksheet1->set_column(1, 5, 30);

        $qryreport = mysql_query("CALL getExcellMemberStatisticBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $memberStatisticID=$reportdisp['memberStatisticID'];
        $month=$reportdisp['month'];
        $monthNum=$reportdisp['monthNum'];
        $year=$reportdisp['year'];
        $totalMale=$reportdisp['totalMale'];
        $totalFemale=$reportdisp['totalFemale'];
        $raceMelayu=$reportdisp['raceMelayu'];
        $raceCina=$reportdisp['raceCina'];
        $raceIndia=$reportdisp['raceIndia'];
        $raceOther=$reportdisp['raceOther'];
        $adult=$reportdisp['adult'];
        $youth=$reportdisp['youth'];
        $kid=$reportdisp['kid'];

        $worksheet1->write_string($j,0,"$memberStatisticID");
        $worksheet1->write_string($j,1,"$month");
        $worksheet1->write_string($j,2,"$monthNum");
        $worksheet1->write_string($j,3,"$year");
        $worksheet1->write_string($j,4,"$totalMale");
        $worksheet1->write_string($j,5,"$totalFemale");
        $worksheet1->write_string($j,6,"$raceMelayu");
        $worksheet1->write_string($j,7,"$raceCina");
        $worksheet1->write_string($j,8,"$raceIndia");
        $worksheet1->write_string($j,9,"$raceOther");
        $worksheet1->write_string($j,10,"$adult");
        $worksheet1->write_string($j,11,"$youth");
        $worksheet1->write_string($j,12,"$kid");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'recovery_log'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertRecoveryLogBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php');
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel('recoveryLog('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet('recoveryLog('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);
        $worksheet1->set_column(1, 4, 20);
        $worksheet1->set_column(1, 5, 30);

        $qryreport = mysql_query("CALL getExcellRecoveryLogBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $recoveryLogID=$reportdisp['recoveryLogID'];
        $tableBackup=$reportdisp['tableBackup'];
        $backupDateTime=$reportdisp['backupDateTime'];
        $descriptionBackup=$reportdisp['descriptionBackup'];

        $worksheet1->write_string($j,0,"$recoveryLogID");
        $worksheet1->write_string($j,1,"$tableBackup");
        $worksheet1->write_string($j,2,"$backupDateTime");
        $worksheet1->write_string($j,3,"$descriptionBackup");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'staff'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertStaffBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php');
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);
        $worksheet1->set_column(1, 4, 20);
        $worksheet1->set_column(1, 5, 30);

        $qryreport = mysql_query("CALL getExcellStaffBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $staffID=$reportdisp['staffID'];
        $staffIDEncrypt=$reportdisp['staffIDEncrypt'];
        $staffName=$reportdisp['staffName'];
        $staffContact=$reportdisp['staffContact'];
        $staffEmail=$reportdisp['staffEmail'];
        $staffPosition=$reportdisp['staffPosition'];
        $staffPassword=$reportdisp['staffPassword'];
        $staffRowLevel=$reportdisp['staffRowLevel'];
        $branchID=$reportdisp['branchID'];
        $staffImg=$reportdisp['staffImg'];

        $worksheet1->write_string($j,0,"$staffID");
        $worksheet1->write_string($j,1,"$staffIDEncrypt");
        $worksheet1->write_string($j,2,"$staffName");
        $worksheet1->write_string($j,3,"$staffContact");
        $worksheet1->write_string($j,4,"$staffEmail");
        $worksheet1->write_string($j,5,"$staffPosition");
        $worksheet1->write_string($j,6,"$staffPassword");
        $worksheet1->write_string($j,7,"$staffRowLevel");
        $worksheet1->write_string($j,8,"$branchID");
        $worksheet1->write_string($j,9,"$staffImg");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'statistic_year'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertStatisticYearBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php');
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel('statYear('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet('statYear('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);
        $worksheet1->set_column(1, 4, 20);
        $worksheet1->set_column(1, 5, 30);

        $qryreport = mysql_query("CALL getExcellStatisticYearBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $statisticYearID=$reportdisp['statisticYearID'];
        $year=$reportdisp['year'];

        $worksheet1->write_string($j,0,"$statisticYearID");
        $worksheet1->write_string($j,1,"$year");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'total_warning'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertTotalWarningBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php');
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel('totWarning('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet('totWarning('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);
        $worksheet1->set_column(1, 4, 20);
        $worksheet1->set_column(1, 5, 30);

        $qryreport = mysql_query("CALL getExcellTotalWarningBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $totalWarningID=$reportdisp['totalWarningID'];
        $memberID=$reportdisp['memberID'];
        $totalWarning=$reportdisp['totalWarning'];

        $worksheet1->write_string($j,0,"$totalWarningID");
        $worksheet1->write_string($j,1,"$memberID");
        $worksheet1->write_string($j,2,"$totalWarning");
        }

    $workbook->close();
    mysql_close($con);
}

elseif($tableName == 'type_book'){
      include("../connection/config.php");
      //INSERT INTO backup_data_log
      mysql_query("CALL insertTypeBookBackupLog()")or die(mysql_error());
      mysql_close($con);

      include("../connection/config.php");
      require_once('../excel/OLEwriter.php');
      require_once('../excel/BIFFwriter.php');
      require_once('../excel/Worksheet.php');
      require_once('../excel/Workbook.php');
      
        function HeaderingExcel($filename) {
          header("Content-type: application/vnd.ms-excel");
          header("Content-Disposition: attachment; filename=$filename" );
          header("Expires: 0");
          header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
          header("Pragma: public");
        }
          
        // HTTP headers
        HeaderingExcel(''.$tableName.'('.$date.').xls');// Creating a workbook
        $workbook = new excel("-");
        // Creating the first worksheet
        $worksheet1 =& $workbook->add_worksheet(''.$tableName.'('.$date.')');
        $worksheet1->freeze_panes(1, 0);
        $worksheet1->set_column(0, 0, 18);
        $worksheet1->set_column(1, 1, 20);
        $worksheet1->set_column(1, 2, 20);
        $worksheet1->set_column(1, 3, 20);
        $worksheet1->set_column(1, 4, 20);
        $worksheet1->set_column(1, 5, 30);

        $qryreport = mysql_query("CALL getExcellTypeBookBackupLog()") or die(mysql_error());
        
        $sqlrows=mysql_num_rows($qryreport);
        $j=0;
        
        while ($reportdisp=mysql_fetch_array($qryreport)){
        $j=$j+1;

        $typeBookID=$reportdisp['typeBookID'];
        $typeBookName=$reportdisp['typeBookName'];

        $worksheet1->write_string($j,0,"$typeBookID");
        $worksheet1->write_string($j,1,"$typeBookName");
        }

    $workbook->close();
    mysql_close($con);
}
?>