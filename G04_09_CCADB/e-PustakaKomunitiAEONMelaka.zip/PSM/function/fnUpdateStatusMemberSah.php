<?php
	include("../connection/config.php");

	$memberID = $_GET['memberID'];	

		$fnUpdateStatusMemberSah = mysql_query("CALL fnUpdateStatusMemberSah('$memberID')")or die(mysql_error());
		
		if($fnUpdateStatusMemberSah){
			echo '<script language = "JavaScript">alert("Maklumat ahli sah berjaya disimpan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/ahliBaru.php">';
		}else{
			echo '<script language = "JavaScript">alert("Harap Maaf, Maklumat ahli sah tidak berjaya disimpan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/ahliBaru.php">';
		}
?>