<?php

$year = $_GET['year'];
$date = date("d/m/Y");
$header1 = "PERBADANAN PERPUSTAKAAN AWAM MELAKA (PERPUSTAM)";
$header2 = "PERPUSTAKAAN KOMUNITI AEON BANDARAYA MELAKA";
$header3 = "STATISTIK PENGUNJUNG MENGIKUT PECAHAN JANTINA $year";

  require_once('../excel/OLEwriter.php');
  require_once('../excel/BIFFwriter.php');
  require_once('../excel/Worksheet.php');
  require_once('../excel/Workbook.php');
  include("../connection/config.php");
  
    function HeaderingExcel($filename) {
      header("Content-type: application/vnd.ms-excel");
      header("Content-Disposition: attachment; filename=$filename" );
      header("Expires: 0");
      header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
      header("Pragma: public");
      }
	  
	  // HTTP headers
HeaderingExcel('PengunjungJantina('.$date.').xls');// Creating a workbook
$workbook = new excel("-");
// Creating the first worksheet
$worksheet1 =& $workbook->add_worksheet('PengunjungJantina('.$date.')');
$worksheet1->freeze_panes(1, 0);

	//Header table
   $worksheet1->write_string(0,1,"$header1");
   $worksheet1->write_string(1,1,"$header2");
   $worksheet1->write_string(2,1,"$header3");
   $worksheet1->write_string(4,0,"KATEGORI\BULAN");
   $worksheet1->write_string(4,1,"JAN");
   $worksheet1->write_string(4,2,"FEB");
   $worksheet1->write_string(4,3,"MAC");
   $worksheet1->write_string(4,4,"APR");
   $worksheet1->write_string(4,5,"MEI");
   $worksheet1->write_string(4,6,"JUN");
   $worksheet1->write_string(4,7,"JUL");
   $worksheet1->write_string(4,8,"AUG");
   $worksheet1->write_string(4,9,"SEPT");
   $worksheet1->write_string(4,10,"OKT");
   $worksheet1->write_string(4,11,"NOV");
   $worksheet1->write_string(4,12,"DIS");
   $worksheet1->write_string(4,13,"JUMLAH");

   $worksheet1->write_string(5,0,"LELAKI");
   $worksheet1->write_string(6,0,"PEREMPUAN");
   $worksheet1->write_string(7,0,"JUMLAH");

    include("../connection/config.php");
    //Get for month  Jan
  	$getDetailJan =mysql_query("CALL getDetailJanVisitorGender('$year')")or die(mysql_error());
    $get1 = mysql_fetch_assoc($getDetailJan);
    $totalMaleJan = $get1['totalMale'];
    $totalFemaleJan = $get1['totalFemale'];
    $totalAllGenderJan = $totalMaleJan + $totalFemaleJan;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month Feb
    $getDetailFeb =mysql_query("CALL getDetailFebVisitorGender('$year')")or die(mysql_error());
    $get2 = mysql_fetch_assoc($getDetailFeb);
    $totalMaleFeb = $get2['totalMale'];
    $totalFemaleFeb = $get2['totalFemale'];
    $totalAllGenderFeb = $totalMaleFeb + $totalMaleFeb;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month March
    $getDetailMar =mysql_query("CALL getDetailMarVisitorGender('$year')")or die(mysql_error());
    $get3 = mysql_fetch_assoc($getDetailMar);
    $totalMaleMar = $get3['totalMale'];
    $totalFemaleMar = $get3['totalFemale'];
    $totalAllGenderMar = $totalMaleMar + $totalFemaleMar;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month April
    $getDetailApr =mysql_query("CALL getDetailAprVisitorGender('$year')")or die(mysql_error());
    $get4 = mysql_fetch_assoc($getDetailApr);
    $totalMaleApr = $get4['totalMale'];
    $totalFemaleApr = $get4['totalFemale'];
    $totalAllGenderApr =  $totalMaleApr + $totalFemaleApr;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month May
    $getDetailMay =mysql_query("CALL getDetailMayVisitorGender('$year')")or die(mysql_error());
    $get5 = mysql_fetch_assoc($getDetailMay);
    $totalMaleMay = $get5['totalMale'];
    $totalFemaleMay = $get5['totalFemale'];
    $totalAllGenderMay = $totalMaleMay + $totalFemaleMay;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month Jun
    $getDetailJun =mysql_query("CALL getDetailJunVisitorGender('$year')")or die(mysql_error());
    $get6 = mysql_fetch_assoc($getDetailJun);
    $totalMaleJun = $get6['totalMale'];
    $totalFemaleJun = $get6['totalFemale'];
    $totalAllGenderJun = $totalMaleJun + $totalFemaleJun;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month July
    $getDetailJul =mysql_query("CALL getDetailJulVisitorGender('$year')")or die(mysql_error());
    $get7 = mysql_fetch_assoc($getDetailJul);
    $totalMaleJul = $get7['totalMale'];
    $totalFemaleJul = $get7['totalFemale'];
    $totalAllGenderJul = $totalMaleJul + $totalFemaleJul;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month August  
    $getDetailAug =mysql_query("CALL getDetailAugVisitorGender('$year')")or die(mysql_error());
    $get8 = mysql_fetch_assoc($getDetailAug);
    $totalMaleAug = $get8['totalMale'];
    $totalFemaleAug = $get8['totalFemale'];
    $totalAllGenderAug = $totalMaleAug + $totalFemaleAug;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month September
    $getDetailSep =mysql_query("CALL getDetailSepVisitorGender('$year')")or die(mysql_error());
    $get9 = mysql_fetch_assoc($getDetailSep);
    $totalMaleSep = $get9['totalMale'];
    $totalFemaleSep = $get9['totalFemale'];
    $totalAllGenderSep = $totalMaleSep + $totalFemaleSep;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month October
    $getDetailOct =mysql_query("CALL getDetailOctVisitorGender('$year')")or die(mysql_error());
    $get10 = mysql_fetch_assoc($getDetailOct);
    $totalMaleOct = $get10['totalMale'];
    $totalFemaleOct = $get10['totalFemale'];
    $totalAllGenderOct =  $totalMaleOct + $totalFemaleOct;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month November
    $getDetailNov =mysql_query("CALL getDetailNovVisitorGender('$year')")or die(mysql_error());
    $get11 = mysql_fetch_assoc($getDetailNov);
    $totalMaleNov = $get11['raceMelayu'];
    $totalFemaleNov = $get11['raceCina'];
    $totalAllGenderNov =  $totalMaleNov + $totalFemaleNov;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month December
    $getDetailDec =mysql_query("CALL getDetailDecVisitorGender('$year')")or die(mysql_error());
    $get12 = mysql_fetch_assoc($getDetailDec);
    $totalMaleDec = $get12['totalMale'];
    $totalFemaleDec = $get12['totalFemale'];
    $totalAllGenderDec =  $totalMaleDec + $totalFemaleDec;
    mysql_close($con);

    include("../connection/config.php");
    //Get for total Overall Male
    $getOverallMale =mysql_query("CALL getOverallMaleVisitorGender('$year')")or die(mysql_error());
    $get13 = mysql_fetch_assoc($getOverallMale);
    $totalOverallMale = $get13['totalOverallMale'];
    mysql_close($con);

    include("../connection/config.php");
    //Get for total Overall Female
    $getOverallFemale =mysql_query("CALL getOverallFemaleVisitorGender('$year')")or die(mysql_error());
    $get14 = mysql_fetch_assoc($getOverallFemale);
    $totalOverallFemale = $get14['totalOverallFemale'];
    mysql_close($con);

    //Get for total Overall Gender Year
    $getOverallGenderPerYear = $totalAllGenderJan + $totalAllGenderFeb + $totalAllGenderMar + $totalAllGenderApr + $totalAllGenderMay + $totalAllGenderJun + $totalAllGenderJul + $totalAllGenderAug + $totalAllGenderSep + $totalAllGenderOct + $totalAllGenderNov + $totalAllGenderDec;

  include("../connection/config.php");
	$qryreport = mysql_query("CALL getExcellVisitorGender('$year')") or die(mysql_error());
	
	$sqlrows=mysql_num_rows($qryreport);
	$j=4;
  $k=5;
  $l=6;
	
	while ($reportdisp=mysql_fetch_array($qryreport)) {
	$j=$j+1;
  $k=$k+1;
  $l=$l+1;

         //Row Lelaki
			   $worksheet1->write_string($j,1,"$totalMaleJan");
         $worksheet1->write_string($j,2,"$totalMaleFeb");
			   $worksheet1->write_string($j,3,"$totalMaleMar");
			   $worksheet1->write_string($j,4,"$totalMaleApr");
			   $worksheet1->write_string($j,5,"$totalMaleMay");
			   $worksheet1->write_string($j,6,"$totalMaleJun");
			   $worksheet1->write_string($j,7,"$totalMaleJul");
			   $worksheet1->write_string($j,8,"$totalMaleAug");
			   $worksheet1->write_string($j,9,"$totalMaleSep");
			   $worksheet1->write_string($j,10,"$totalMaleOct");
			   $worksheet1->write_string($j,11,"$totalMaleNov");
			   $worksheet1->write_string($j,12,"$totalMaleDec");
         $worksheet1->write_string($j,13,"$totalOverallMale");

         //Row Perempuan
         $worksheet1->write_string($k,1,"$totalFemaleJan");
         $worksheet1->write_string($k,2,"$totalFemaleFeb");
         $worksheet1->write_string($k,3,"$totalFemaleMar");
         $worksheet1->write_string($k,4,"$totalFemaleApr");
         $worksheet1->write_string($k,5,"$totalFemaleMay");
         $worksheet1->write_string($k,6,"$totalFemaleJun");
         $worksheet1->write_string($k,7,"$totalFemaleJul");
         $worksheet1->write_string($k,8,"$totalFemaleAug");
         $worksheet1->write_string($k,9,"$totalFemaleSep");
         $worksheet1->write_string($k,10,"$totalFemaleOct");
         $worksheet1->write_string($k,11,"$totalFemaleNov");
         $worksheet1->write_string($k,12,"$totalFemaleDec");
         $worksheet1->write_string($k,13,"$totalOverallFemale");

         //Row Jumlah
         $worksheet1->write_string($l,1,"$totalAllGenderJan");
         $worksheet1->write_string($l,2,"$totalAllGenderFeb");
         $worksheet1->write_string($l,3,"$totalAllGenderMar");
         $worksheet1->write_string($l,4,"$totalAllGenderApr");
         $worksheet1->write_string($l,5,"$totalAllGenderMay");
         $worksheet1->write_string($l,6,"$totalAllGenderJun");
         $worksheet1->write_string($l,7,"$totalAllGenderJul");
         $worksheet1->write_string($l,8,"$totalAllGenderAug");
         $worksheet1->write_string($l,9,"$totalAllGenderSep");
         $worksheet1->write_string($l,10,"$totalAllGenderOct");
         $worksheet1->write_string($l,11,"$totalAllGenderNov");
         $worksheet1->write_string($l,12,"$totalAllGenderDec");
         $worksheet1->write_string($l,13,"$getOverallGenderPerYear");
	}
	
$workbook->close();
mysql_close($con);
?>