<!-- register data -->
<?php
if(isset($_POST['btnEditAkaun'])){

include("../connection/config.php");

$staffID = $_POST['staffID'];
$staffName= $_POST['staffName'];
$staffEmail = $_POST['staffEmail'];
$staffContact = $_POST['staffContact'];
$staffPosition = $_POST['staffPosition'];

	$fnUpdateAkaunStaff = "CALL fnUpdateAkaunStaff('$staffName', '$staffEmail', '$staffContact', '$staffID')";

echo '<script language = "JavaScript">alert("Berjaya update penetapan Akaun!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/penetapanAkaun.php">';

mysql_query($fnUpdateAkaunStaff,$con)or die(mysql_error());
mysql_close($con);
}
?>