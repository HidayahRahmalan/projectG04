<!-- register data -->
<?php

include("../connection/config.php");

$memberID = $_POST['memberID'];
$borrowDate = $_POST['borrowDate'];
$returnDate = $_POST['returnDate'];
$bookID = $_POST['bookID'];
$monthNum = date("m");
$monthNameTemp = date("F", mktime(0, 0, 0, $monthNum, 10));
$year = date("Y");
$monthName = substr($monthNameTemp, 0, 3);
	
	//Check memberID exist or not
	$sql = "SELECT * FROM member WHERE memberID='$memberID'";

	if(mysql_num_rows(mysql_query($sql))) {

		//Count Jumlah Senarai Hitam Keseluruhan
		$getTotalBalcklistAll = mysql_query("SELECT memberID, memberStatus, totalBorrow, memberGender, memberRace, memberType FROM member WHERE memberID='$memberID'");
		$get = mysql_fetch_assoc($getTotalBalcklistAll);
		$memberStatus = $get['memberStatus'];
		$totalBorrow = $get['totalBorrow'];
		$memberGender = $get['memberGender'];
		$memberRace = $get['memberRace'];
		$memberType = $get['memberType'];

		if($memberStatus == 'SENARAI HITAM'){
			echo '<script language = "JavaScript">alert("Harap Maaf No Ahli: '.$memberID.' adalah SENARAI HITAM!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
		}
		elseif($memberStatus == 'PROSES SENARAI HITAM'){
			echo '<script language = "JavaScript">alert("Harap Maaf No Ahli: '.$memberID.' adalah dalam PROSES SENARAI HITAM!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
		}
		elseif($memberStatus == 'DALAM PROSES'){
			echo '<script language = "JavaScript">alert("Harap Maaf No Ahli: '.$memberID.' adalah DALAM PROSES, sila semak pengesahan borang ahli dan update status ahli semula!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
		}
		elseif($totalBorrow == 8){
			echo '<script language = "JavaScript">alert("Harap Maaf Jumlah Pinjaman Ahli Masih di tahap maksima, syarat pinjaman tidak melebihi 8 buah buku!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
		}
		elseif($memberStatus == 'LAMBAT PULANG'){
			echo '<script language = "JavaScript">alert("Harap Maaf Ahli Mempunyai Buku yang Masih Tidak Dipulangkan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
		}
		else{
			$sql = "INSERT INTO borrow VALUES('', '$bookID', '$memberID', 'DALAM PINJAMAN', NOW(), '$returnDate')";

			//Trigger occur here trigInsertBorrow

			//Update Table borrow_statistic
			$sqlIfExistMonthAndYear = mysql_query("SELECT * FROM borrow_statistic WHERE month='$monthName' AND year='$year'")or die(mysql_error());
				if(mysql_num_rows($sqlIfExistMonthAndYear)) {
					if($memberGender=='LELAKI' && $memberRace == 'MELAYU' && $memberType == 'DEWASA'){
						//Update month and year for male + 1
						mysql_query("UPDATE borrow_statistic SET totalMale=totalMale+1, raceMelayu=raceMelayu+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'MELAYU' && $memberType == 'DEWASA'){
						//Update month and year for female + 1
						mysql_query("UPDATE borrow_statistic SET totalFemale=totalFemale+1, raceMelayu=raceMelayu+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'MELAYU' && $memberType == 'BELIA'){
						//Update month and year for male + 1
						mysql_query("UPDATE borrow_statistic SET totalMale=totalMale+1, raceMelayu=raceMelayu+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'MELAYU' && $memberType == 'BELIA'){
						//Update month and year for female + 1
						mysql_query("UPDATE borrow_statistic SET totalFemale=totalFemale+1, raceMelayu=raceMelayu+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'MELAYU' && $memberType == 'KANAK-KANAK'){
						//Update month and year for male + 1
						mysql_query("UPDATE borrow_statistic SET totalMale=totalMale+1, raceMelayu=raceMelayu+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'MELAYU' && $memberType == 'KANAK-KANAK'){
						//Update month and year for female + 1
						mysql_query("UPDATE borrow_statistic SET totalFemale=totalFemale+1, raceMelayu=raceMelayu+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'CINA' && $memberType == 'DEWASA'){
						//Update month and year for male + 1
						mysql_query("UPDATE borrow_statistic SET totalMale=totalMale+1, raceCina=raceCina+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'CINA' && $memberType == 'DEWASA'){
						//Update month and year for female + 1
						mysql_query("UPDATE borrow_statistic SET totalFemale=totalFemale+1, raceCina=raceCina+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'CINA' && $memberType == 'BELIA'){
						//Update month and year for male + 1
						mysql_query("UPDATE borrow_statistic SET totalMale=totalMale+1, raceCina=raceCina+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'CINA' && $memberType == 'BELIA'){
						//Update month and year for female + 1
						mysql_query("UPDATE borrow_statistic SET totalFemale=totalFemale+1, raceCina=raceCina+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'CINA' && $memberType == 'KANAK-KANAK'){
						//Update month and year for male + 1
						mysql_query("UPDATE borrow_statistic SET totalMale=totalMale+1, raceCina=raceCina+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'CINA' && $memberType == 'KANAK-KANAK'){
						//Update month and year for female + 1
						mysql_query("UPDATE borrow_statistic SET totalFemale=totalFemale+1, raceCina=raceCina+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'INDIA' && $memberType == 'DEWASA'){
						//Update month and year for male + 1
						mysql_query("UPDATE borrow_statistic SET totalMale=totalMale+1, raceIndia=raceIndia+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'INDIA' && $memberType == 'DEWASA'){
						//Update month and year for female + 1
						mysql_query("UPDATE borrow_statistic SET totalFemale=totalFemale+1, raceIndia=raceIndia+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'INDIA' && $memberType == 'BELIA'){
						//Update month and year for male + 1
						mysql_query("UPDATE borrow_statistic SET totalMale=totalMale+1, raceIndia=raceIndia+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'INDIA' && $memberType == 'BELIA'){
						//Update month and year for female + 1
						mysql_query("UPDATE borrow_statistic SET totalFemale=totalFemale+1, raceIndia=raceIndia+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'INDIA' && $memberType == 'KANAK-KANAK'){
						//Update month and year for male + 1
						mysql_query("UPDATE borrow_statistic SET totalMale=totalMale+1, raceIndia=raceIndia+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'INDIA' && $memberType == 'KANAK-KANAK'){
						//Update month and year for female + 1
						mysql_query("UPDATE borrow_statistic SET totalFemale=totalFemale+1, raceIndia=raceIndia+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'LAIN-LAIN' && $memberType == 'DEWASA'){
						//Update month and year for male + 1
						mysql_query("UPDATE borrow_statistic SET totalMale=totalMale+1, raceOther=raceOther+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'LAIN-LAIN' && $memberType == 'DEWASA'){
						//Update month and year for female + 1
						mysql_query("UPDATE borrow_statistic SET totalFemale=totalFemale+1, raceOther=raceOther+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'LAIN-LAIN' && $memberType == 'BELIA'){
						//Update month and year for male + 1
						mysql_query("UPDATE borrow_statistic SET totalMale=totalMale+1, raceOther=raceOther+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'LAIN-LAIN' && $memberType == 'BELIA'){
						//Update month and year for female + 1
						mysql_query("UPDATE borrow_statistic SET totalFemale=totalFemale+1, raceOther=raceOther+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'LAIN-LAIN' && $memberType == 'KANAK-KANAK'){
						//Update month and year for male + 1
						mysql_query("UPDATE borrow_statistic SET totalMale=totalMale+1, raceOther=raceOther+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'LAIN-LAIN' && $memberType == 'KANAK-KANAK'){
						//Update month and year for female + 1
						mysql_query("UPDATE borrow_statistic SET totalFemale=totalFemale+1, raceOther=raceOther+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
					}
				} else {
				if($memberGender == 'LELAKI' && $memberRace == 'MELAYU' && $memberType == 'DEWASA'){
					//Insert Into Table borrow_statistic male
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '1', '', '1', '', '', '', '1', '', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'PEREMPUAN' && $memberRace == 'MELAYU' && $memberType == 'DEWASA'){
					//Insert Into Table borrow_statistic
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '', '1', '1', '', '', '', '1', '', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'LELAKI' && $memberRace == 'MELAYU' && $memberType == 'BELIA'){
					//Insert Into Table borrow_statistic male
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '1', '', '1', '', '', '', '', '1', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'PEREMPUAN' && $memberRace == 'MELAYU' && $memberType == 'BELIA'){
					//Insert Into Table borrow_statistic
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '', '1', '1', '', '', '', '0', '1', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'LELAKI' && $memberRace == 'MELAYU' && $memberType == 'KANAK-KANAK'){
					//Insert Into Table borrow_statistic male
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '1', '', '1', '', '', '', '', '', '1')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'PEREMPUAN' && $memberRace == 'MELAYU' && $memberType == 'KANAK-KANAK'){
					//Insert Into Table borrow_statistic
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '', '1', '1', '', '', '', '', '', '1')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'LELAKI' && $memberRace == 'CINA' && $memberType == 'DEWASA'){
					//Insert Into Table borrow_statistic male
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '1', '', '', '1', '', '', '1', '', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'PEREMPUAN' && $memberRace == 'CINA' && $memberType == 'DEWASA'){
					//Insert Into Table borrow_statistic
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '', '1', '', '1', '', '', '1', '', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'LELAKI' && $memberRace == 'CINA' && $memberType == 'BELIA'){
					//Insert Into Table borrow_statistic male
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '1', '', '', '1', '', '', '', '1', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'PEREMPUAN' && $memberRace == 'CINA' && $memberType == 'BELIA'){
					//Insert Into Table borrow_statistic
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '', '1', '', '1', '', '', '', '1', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'LELAKI' && $memberRace == 'CINA' && $memberType == 'KANAK-KANAK'){
					//Insert Into Table borrow_statistic male
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '1', '', '', '1', '', '', '', '', '1')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'PEREMPUAN' && $memberRace == 'CINA' && $memberType == 'KANAK-KANAK'){
					//Insert Into Table borrow_statistic
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '', '1', '', '1', '', '', '', '', '1')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'LELAKI' && $memberRace == 'INDIA' && $memberType == 'DEWASA'){
					//Insert Into Table borrow_statistic male
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '1', '', '', '', '1', '', '1', '', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'PEREMPUAN' && $memberRace == 'INDIA' && $memberType == 'DEWASA'){
					//Insert Into Table borrow_statistic
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '', '1', '', '', '1', '', '1', '', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'LELAKI' && $memberRace == 'INDIA' && $memberType == 'BELIA'){
					//Insert Into Table borrow_statistic male
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '1', '', '', '', '1', '', '', '1', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'PEREMPUAN' && $memberRace == 'INDIA' && $memberType == 'BELIA'){
					//Insert Into Table borrow_statistic
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '', '1', '', '', '1', '', '', '1', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'LELAKI' && $memberRace == 'INDIA' && $memberType == 'KANAK-KANAK'){
					//Insert Into Table borrow_statistic male
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '1', '', '', '', '1', '', '', '', '1')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'PEREMPUAN' && $memberRace == 'INDIA' && $memberType == 'KANAK-KANAK'){
					//Insert Into Table borrow_statistic
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '', '1', '', '', '1', '', '', '', '1')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'LELAKI' && $memberRace == 'LAIN-LAIN' && $memberType == 'DEWASA'){
					//Insert Into Table borrow_statistic male
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '1', '', '', '', '', '1', '1', '', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'PEREMPUAN' && $memberRace == 'LAIN-LAIN' && $memberType == 'DEWASA'){
					//Insert Into Table borrow_statistic
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '', '1', '0', '', '', '1', '1', '', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'LELAKI' && $memberRace == 'LAIN-LAIN' && $memberType == 'BELIA'){
					//Insert Into Table borrow_statistic male
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '1', '', '', '', '', '1', '', '1', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'PEREMPUAN' && $memberRace == 'LAIN-LAIN' && $memberType == 'BELIA'){
					//Insert Into Table borrow_statistic
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '', '1', '0', '', '', '1', '', '1', '')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'LELAKI' && $memberRace == 'LAIN-LAIN' && $memberType == 'KANAK-KANAK'){
					//Insert Into Table borrow_statistic male
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '1', '', '', '', '', '1', '', '', '1')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
				elseif($memberGender == 'PEREMPUAN' && $memberRace == 'LAIN-LAIN' && $memberType == 'KANAK-KANAK'){
					//Insert Into Table borrow_statistic
					mysql_query("INSERT INTO borrow_statistic VALUES('', '$monthName', '$monthNum', '$year', '', '1', '0', '', '', '1', '', '', '1')");

					echo '<script language = "JavaScript">alert(" Data Berjaya disimpan!")</script>';
						print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
				}
			}
		}

	}else {

		echo '<script language = "JavaScript">alert("No Ahli pengguna: '.$memberID.' tidak wujud!")</script>';
			print '<meta http-equiv="refresh" content="0;URL=../pages/pinjamanPulanganBuku.php">';
	}

mysql_query($sql,$con);
mysql_close($con);
?>