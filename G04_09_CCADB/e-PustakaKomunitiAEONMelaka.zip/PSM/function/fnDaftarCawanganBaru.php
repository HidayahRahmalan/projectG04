<!-- register data -->
<?php

include("../connection/config.php");

$branchName = $_POST['branchName'];

	$sql = "CALL inserNewBranch('$branchName')";

	echo '<script language = "JavaScript">alert("Berjaya daftar cawangan '.$branchName.'!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/cawanganAdmin.php">';

mysql_query($sql,$con);
mysql_close($con);
?>