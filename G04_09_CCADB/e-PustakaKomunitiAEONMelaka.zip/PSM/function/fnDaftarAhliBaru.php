<!-- register data -->
<?php
if(isset($_POST['btnDaftarAhliBaru'])){

include("../connection/config.php");

$memberName = mysql_real_escape_string($_POST['memberName']);
$memberIDKanak= $_POST['memberIDKanak'];
$memberIDKanakDecrypt= md5($_POST['memberIDKanak']);
$memberIDBelia= $_POST['memberIDBelia'];
$memberIDBeliaDecrypt= md5($_POST['memberIDBelia']);
$memberIDDewasa= $_POST['memberIDDewasa'];
$memberIDDewasaDecrypt= md5($_POST['memberIDDewasa']);
$memberIC = $_POST['memberIC'];
$memberPassword = md5($_POST['memberIC']);
$memberBOD = $_POST['memberBOD'];
//$memberBODTemp = $_POST['memberBOD'];
//$memberBOD = date("d/m/Y", strtotime($memberBODTemp));
$memberGender = $_POST['memberGender'];
$memberRace = $_POST['memberRace'];
$memberAddress = $_POST['memberAddress'];

//Email Detail
$emailID = $_POST['emailID'];
$emailFather = $_POST['emailFather'];
$emailMother = $_POST['emailMother'];
$emailSelf = $_POST['emailSelf'];

//Contact Detail
$contactID = $_POST['contactID'];
$contactFatherH = $_POST['contactFatherH'];
$contactFatherO = $_POST['contactFatherO'];
$contactFatherM = $_POST['contactFatherM'];
$contactMotherH = $_POST['contactMotherH'];
$contactMotherO = $_POST['contactMotherO'];
$contactMotherM = $_POST['contactMotherM'];
$contactSelfH = $_POST['contactSelfH'];
$contactSelfO = $_POST['contactSelfO'];
$contactSelfM = $_POST['contactSelfM'];

$memberType = $_POST['memberType'];
$staffID = $_POST['staffID'];


$monthNum = date("m");
$monthNameTemp = date("F", mktime(0, 0, 0, $monthNum, 10));
$year = date("Y");
$monthName = substr($monthNameTemp, 0, 3);


	if(strlen($memberIC) < 9)
	  {
		echo '<script language = "JavaScript">alert("No Kad Pengenalan mestilah 12 angka!")</script>';
			print '<meta http-equiv="refresh" content="0;URL=../pages/ahliBaru.php">';
	  }

	else{

	$sql = "SELECT memberIC FROM member WHERE memberIC='$memberIC'";
	
		if(mysql_num_rows(mysql_query($sql))) {
			echo '<script language = "JavaScript">alert("IC ahli '.$memberIC.' telah wujud!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/ahliBaru.php">';
		}else{


			$sql2 = "SELECT * FROM member_statistic WHERE month='$monthName' AND year='$year'";

				//Statistic Already Exist Just Update
				if(mysql_num_rows(mysql_query($sql2))){

					if($memberGender=='LELAKI' && $memberRace == 'MELAYU' && $memberType == 'DEWASA'){
						mysql_query("UPDATE member_statistic SET totalMale=totalMale+1, raceMelayu=raceMelayu+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

							echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'MELAYU' && $memberType == 'DEWASA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalFemale=totalFemale+1, raceMelayu=raceMelayu+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'MELAYU' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalMale=totalMale+1, raceMelayu=raceMelayu+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'MELAYU' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalFemale=totalFemale+1, raceMelayu=raceMelayu+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'MELAYU' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalMale=totalMale+1, raceMelayu=raceMelayu+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'MELAYU' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalFemale=totalFemale+1, raceMelayu=raceMelayu+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'CINA' && $memberType == 'DEWASA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalMale=totalMale+1, raceCINA=raceCINA+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'CINA' && $memberType == 'DEWASA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalFemale=totalFemale+1, raceCINA=raceCINA+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'CINA' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalMale=totalMale+1, raceCINA=raceCINA+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'CINA' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalFemale=totalFemale+1, raceCINA=raceCINA+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'CINA' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalMale=totalMale+1, raceCINA=raceCINA+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'CINA' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalFemale=totalFemale+1, raceCINA=raceCINA+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'INDIA' && $memberType == 'DEWASA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalMale=totalMale+1, raceINDIA=raceINDIA+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'INDIA' && $memberType == 'DEWASA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalFemale=totalFemale+1, raceINDIA=raceINDIA+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'INDIA' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalMale=totalMale+1, raceINDIA=raceINDIA+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'INDIA' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalFemale=totalFemale+1, raceINDIA=raceINDIA+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'INDIA' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalMale=totalMale+1, raceINDIA=raceINDIA+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'INDIA' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalFemale=totalFemale+1, raceINDIA=raceINDIA+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'LAIN-LAIN' && $memberType == 'DEWASA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalMale=totalMale+1, raceOther=raceOther+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'LAIN-LAIN' && $memberType == 'DEWASA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalFemale=totalFemale+1, raceOther=raceOther+1, adult=adult+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'LAIN-LAIN' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalMale=totalMale+1, raceOther=raceOther+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'LAIN-LAIN' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalFemale=totalFemale+1, raceOther=raceOther+1, youth=youth+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'LAIN-LAIN' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalMale=totalMale+1, raceOther=raceOther+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'LAIN-LAIN' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("UPDATE member_statistic SET totalFemale=totalFemale+1, raceOther=raceOther+1, kid=kid+1 WHERE month='$monthName' AND year='$year'");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
				}
				//Insert new record on member_statistic
				else{

					if($memberGender=='LELAKI' && $memberRace == 'MELAYU' && $memberType == 'DEWASA'){
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalMale, raceMelayu, adult) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

							echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'MELAYU' && $memberType == 'DEWASA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalFemale, raceMelayu, adult) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'MELAYU' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalMale, raceMelayu, youth) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'MELAYU' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalFemale, raceMelayu, youth) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'MELAYU' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalMale, raceMelayu, kid) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'MELAYU' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalFemale, raceMelayu, kid) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'CINA' && $memberType == 'DEWASA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalMale, raceCina, adult) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'CINA' && $memberType == 'DEWASA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalFemale, raceCina, adult) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'CINA' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalMale, raceCina, youth) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'CINA' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalFemale, raceCina, youth) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'CINA' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalMale, raceCina, kid) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'CINA' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalFemale, raceCina, kid) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'INDIA' && $memberType == 'DEWASA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalMale, raceIndia, adult) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'INDIA' && $memberType == 'DEWASA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalFemale, raceIndia, adult) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'INDIA' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalMale, raceIndia, youth) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'INDIA' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalFemale, raceIndia, youth) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'INDIA' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalMale, raceIndia, kid) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'INDIA' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalFemale, raceIndia, kid) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'LAIN-LAIN' && $memberType == 'DEWASA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalMale, raceOther, adult) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'LAIN-LAIN' && $memberType == 'DEWASA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalFemale, raceOther, adult) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDDewasa', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDDewasaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDDewasa.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'LAIN-LAIN' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalMale, raceOther, youth) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'LAIN-LAIN' && $memberType == 'BELIA'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalFemale, raceOther, youth) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDBelia', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDBeliaDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDBelia.'">';
					}
					elseif($memberGender=='LELAKI' && $memberRace == 'LAIN-LAIN' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalMale, raceOther, kid) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
					elseif($memberGender=='PEREMPUAN' && $memberRace == 'LAIN-LAIN' && $memberType == 'KANAK-KANAK'){
						//Update Table member_statistic
						mysql_query("INSERT INTO member_statistic(memberStatisticID, month, monthNum, year, totalFemale, raceOther, kid) VALUES('', '$monthName', '$monthNum', '$year', '1', '1', '1')");

						mysql_query("INSERT INTO email VALUES('$emailID', '$emailFather', '$emailMother', '$emailSelf')")or die(mysql_error());

						mysql_query("INSERT INTO contact VALUES('$contactID', '$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')")or die(mysql_error());

						mysql_query("INSERT INTO member VALUES('$memberIDKanak', '$memberName', '$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '', '$staffID', '0', '$memberPassword', '$memberIDKanakDecrypt')")or die(mysql_error());

						echo '<script language = "JavaScript">alert("Berjaya daftar ahli baru '.$memberName.'!")</script>';
							print '<meta http-equiv="refresh" content="0;URL=../pages/paparanBorangAhli.php?memberID='.$memberIDKanak.'">';
					}
				}




			
		}
	}

}
?>