<?php

$memberID = $_POST['memberID'];
$formComment = $_POST['formComment'];

if(isset($_POST['btnSah'])){
 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk mengesahkan cop pengesahan ahli ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnUpdateCopPengesahanMemberSah.php?memberID='.$memberID.'&formComment='.$formComment.'";
	  }
	  
	 else
	 {
		  self.location="../pages/paparanBorangCopPengesahanAhli.php?memberID='.$memberID.'";
	 }
	  
	  </script>';
}

if(isset($_POST['btnTidakSah'])){
 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk menolak cop pengesahan ahli ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnUpdateCopPengesahanMemberTidakSah.php?memberID='.$memberID.'&formComment='.$formComment.'";
	  }
	  
	 else
	 {
		  self.location="../pages/paparanBorangCopPengesahanAhli.php?memberID='.$memberID.'";
	 }
	  
	  </script>';
}
?>