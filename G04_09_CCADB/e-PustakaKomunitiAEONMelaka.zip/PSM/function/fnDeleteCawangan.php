<!-- register data -->
<?php

include("../connection/config.php");

$branchID = $_GET['branchID'];

	$fnDeleteBranch = mysql_query("CALL fnDeleteBranch('$branchID')")or die(mysql_error());

		print '<meta http-equiv="refresh" content="0;URL=../pages/cawanganAdmin.php">';

mysql_query($fnDeleteBranch,$con);
mysql_close($con);
?>