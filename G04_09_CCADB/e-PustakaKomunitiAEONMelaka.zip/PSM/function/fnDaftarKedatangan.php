<!-- register data -->
<?php

include("../connection/config.php");

$attendanceDate = $_POST['attendanceDate'];
$attendanceTime = $_POST['attendanceTime'];
$attendanceCategory = $_POST['attendanceCategory'];
$attendanceTotal = $_POST['attendanceTotal'];
$attendanceGender = $_POST['attendanceGender'];
$attendanceRace = $_POST['attendanceRace'];
$staffID = $_POST['staffID'];
$monthNum = date("m");
$monthNameTemp = date("F", mktime(0, 0, 0, $monthNum, 10));
$year = date("Y");
$monthName = substr($monthNameTemp, 0, 3);

	//Check if Date && Time exist just update no need add new row data
	$sql = "SELECT attendanceDate, attendanceTime, attendanceGender, attendanceRace, attendanceCategory FROM attendance WHERE attendanceDate='$attendanceDate' AND attendanceTime='$attendanceTime' AND attendanceRace='$attendanceRace' AND attendanceGender='$attendanceGender' AND attendanceCategory='$attendanceCategory'";
	
	if(mysql_num_rows(mysql_query($sql))) {
		//Just update existing row Date && Time
			mysql_query("UPDATE attendance SET attendanceTotal=attendanceTotal+'$attendanceTotal' WHERE attendanceDate='$attendanceDate' AND attendanceTime='$attendanceTime' AND attendanceRace='$attendanceRace' AND attendanceGender='$attendanceGender' AND attendanceCategory='$attendanceCategory'");

		if($attendanceGender=='Lelaki' && $attendanceRace == 'Melayu' && $attendanceCategory == 'Dewasa'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale+'$attendanceTotal', raceMelayu=raceMelayu+'$attendanceTotal', adult=adult+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Perempuan' && $attendanceRace == 'Melayu' && $attendanceCategory == 'Dewasa'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale+'$attendanceTotal', raceMelayu=raceMelayu+'$attendanceTotal', adult=adult+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Lelaki' && $attendanceRace == 'Melayu' && $attendanceCategory == 'Belia'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale+'$attendanceTotal', raceMelayu=raceMelayu+'$attendanceTotal', youth=youth+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Perempuan' && $attendanceRace == 'Melayu' && $attendanceCategory == 'Belia'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale+'$attendanceTotal', raceMelayu=raceMelayu+'$attendanceTotal', youth=youth+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Lelaki' && $attendanceRace == 'Melayu' && $attendanceCategory == 'Kanak-Kanak'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale+'$attendanceTotal', raceMelayu=raceMelayu+'$attendanceTotal', kid=kid+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Perempuan' && $attendanceRace == 'Melayu' && $attendanceCategory == 'Kanak-Kanak'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale+'$attendanceTotal', raceMelayu=raceMelayu+'$attendanceTotal', kid=kid+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Lelaki' && $attendanceRace == 'Cina' && $attendanceCategory == 'Dewasa'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale+'$attendanceTotal', raceCina=raceCina+'$attendanceTotal', adult=adult+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Perempuan' && $attendanceRace == 'Cina' && $attendanceCategory == 'Dewasa'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale+'$attendanceTotal', raceCina=raceCina+'$attendanceTotal', adult=adult+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Lelaki' && $attendanceRace == 'Cina' && $attendanceCategory == 'Belia'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale+'$attendanceTotal', raceCina=raceCina+'$attendanceTotal', youth=youth+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Perempuan' && $attendanceRace == 'Cina' && $attendanceCategory == 'Belia'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale+'$attendanceTotal', raceCina=raceCina+'$attendanceTotal', youth=youth+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Lelaki' && $attendanceRace == 'Cina' && $attendanceCategory == 'Kanak-Kanak'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale+'$attendanceTotal', raceCina=raceCina+'$attendanceTotal', kid=kid+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Perempuan' && $attendanceRace == 'Cina' && $attendanceCategory == 'Kanak-Kanak'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale+'$attendanceTotal', raceCina=raceCina+'$attendanceTotal', kid=kid+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Lelaki' && $attendanceRace == 'India' && $attendanceCategory == 'Dewasa'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale+'$attendanceTotal', raceIndia=raceIndia+'$attendanceTotal', adult=adult+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Perempuan' && $attendanceRace == 'India' && $attendanceCategory == 'Dewasa'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale+'$attendanceTotal', raceIndia=raceIndia+'$attendanceTotal', adult=adult+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Lelaki' && $attendanceRace == 'India' && $attendanceCategory == 'Belia'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale+'$attendanceTotal', raceIndia=raceIndia+'$attendanceTotal', youth=youth+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Perempuan' && $attendanceRace == 'India' && $attendanceCategory == 'Belia'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale+'$attendanceTotal', raceIndia=raceIndia+'$attendanceTotal', youth=youth+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Lelaki' && $attendanceRace == 'India' && $attendanceCategory == 'Kanak-Kanak'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale+'$attendanceTotal', raceIndia=raceIndia+'$attendanceTotal', kid=kid+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Perempuan' && $attendanceRace == 'India' && $attendanceCategory == 'Kanak-Kanak'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale+'$attendanceTotal', raceIndia=raceIndia+'$attendanceTotal', kid=kid+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Lelaki' && $attendanceRace == 'Lain-Lain' && $attendanceCategory == 'Dewasa'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale+'$attendanceTotal', raceOther=raceOther+'$attendanceTotal', adult=adult+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Perempuan' && $attendanceRace == 'Lain-Lain' && $attendanceCategory == 'Dewasa'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale+'$attendanceTotal', raceOther=raceOther+'$attendanceTotal', adult=adult+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Lelaki' && $attendanceRace == 'Lain-Lain' && $attendanceCategory == 'Belia'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale+'$attendanceTotal', raceOther=raceOther+'$attendanceTotal', youth=youth+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Perempuan' && $attendanceRace == 'Lain-Lain' && $attendanceCategory == 'Belia'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale+'$attendanceTotal', raceOther=raceOther+'$attendanceTotal', youth=youth+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Lelaki' && $attendanceRace == 'Lain-Lain' && $attendanceCategory == 'Kanak-Kanak'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale+'$attendanceTotal', raceOther=raceOther+'$attendanceTotal', kid=kid+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender=='Perempuan' && $attendanceRace == 'Lain-Lain' && $attendanceCategory == 'Kanak-Kanak'){
			//Update Table attendance_statistic
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale+'$attendanceTotal', raceOther=raceOther+'$attendanceTotal', kid=kid+'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
	} 

	else {

		if($attendanceGender == 'Lelaki' && $attendanceRace == 'Melayu' && $attendanceCategory == 'Dewasa'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalMale, raceMelayu, adult) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Perempuan' && $attendanceRace == 'Melayu' && $attendanceCategory == 'Dewasa'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalFemale, raceMelayu, adult) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace == 'Melayu' && $attendanceCategory == 'Belia'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalMale, raceMelayu, youth) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Perempuan' && $attendanceRace == 'Melayu' && $attendanceCategory == 'Belia'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalFemale, raceMelayu, youth) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace == 'Melayu' && $attendanceCategory == 'Kanak-Kanak'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalMale, raceMelayu, kid) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Perempuan' && $attendanceRace == 'Melayu' && $attendanceCategory == 'Kanak-Kanak'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalFemale, raceMelayu, kid) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace == 'Cina' && $attendanceCategory == 'Dewasa'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalMale, raceCina, adult) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Perempuan' && $attendanceRace == 'Cina' && $attendanceCategory == 'Dewasa'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalFemale, raceCina, adult) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace == 'Cina' && $attendanceCategory == 'Belia'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalMale, raceCina, youth) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Perempuan' && $attendanceRace == 'Cina' && $attendanceCategory == 'Belia'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalFemale, raceCina, youth) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace == 'Cina' && $attendanceCategory == 'Kanak-Kanak'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalMale, raceCina, kid) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Perempuan' && $attendanceRace == 'Cina' && $attendanceCategory == 'Kanak-Kanak'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalFemale, raceCina, kid) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace == 'India' && $attendanceCategory == 'Dewasa'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalMale, raceIndia, adult) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Perempuan' && $attendanceRace == 'India' && $attendanceCategory == 'Dewasa'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalFemale, raceIndia, adult) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace == 'India' && $attendanceCategory == 'Belia'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalMale, raceIndia, youth) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Perempuan' && $attendanceRace == 'India' && $attendanceCategory == 'Belia'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalFemale, raceIndia, youth) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace == 'India' && $attendanceCategory == 'Kanak-Kanak'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalMale, raceIndia, kid) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Perempuan' && $attendanceRace == 'India' && $attendanceCategory == 'Kanak-Kanak'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalFemale, raceIndia, kid) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace == 'Lain-Lain' && $attendanceCategory == 'Dewasa'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalMale, raceOther, adult) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Perempuan' && $attendanceRace == 'Lain-Lain' && $attendanceCategory == 'Dewasa'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalFemale, raceOther, adult) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace == 'Lain-Lain' && $attendanceCategory == 'Belia'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalMale, raceOther, youth) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Perempuan' && $attendanceRace == 'Lain-Lain' && $attendanceCategory == 'Belia'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalFemale, raceOther, youth) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace == 'Lain-Lain' && $attendanceCategory == 'Kanak-Kanak'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalMale, raceOther, kid) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Perempuan' && $attendanceRace == 'Lain-Lain' && $attendanceCategory == 'Kanak-Kanak'){
			//Data does not has yet and insert for the first record
			mysql_query("INSERT INTO attendance VALUES('', NOW(), '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");

			//Insert into table attendance_statistic
			mysql_query("INSERT INTO attendance_statistic(attendanceStatisticID, month, monthNum, year, totalFemale, raceOther, kid) VALUES('', '$monthName', '$monthNum', '$year', '$attendanceTotal', '$attendanceTotal', '$attendanceTotal')");

			echo '<script language = "JavaScript">alert("Berjaya rekod kedatangan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}

	}

mysql_query($sql,$con);
mysql_close($con);
?>