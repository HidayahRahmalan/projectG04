<?php
	include("../connection/config.php");
	
	$imageName = mysql_real_escape_string($_FILES["image"]["name"]);
	$imageData = mysql_real_escape_string(file_get_contents($_FILES["image"]["tmp_name"]));
	$imageType = mysql_real_escape_string($_FILES["image"]["type"]);
	$memberID = mysql_real_escape_string($_POST['memberID']);
	
	if(substr($imageType,0,5) == "image")
	{
		$fnUploadCopPengesahan = mysql_query("CALL fnUploadCopPengesahan('$memberID', '$imageData')")or die(mysql_error());
		
		if($fnUploadCopPengesahan){
			echo '<script language = "JavaScript">alert("Berjaya muat naik cop pengesahan, borang anda akan disemak oleh pihak perpustakaan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/borangPengesahan.php">';
		}else{
			echo '<script language = "JavaScript">alert("Harap Maaf, Tidak Berjaya muat naik cop pengesahan, borang anda akan disemak oleh pihak perpustakaan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/borangPengesahan.php">';
		}
	}
	
	else
	{
		echo '<script language = "JavaScript">alert("Hanya format (.jpg/.jpeg/.png) sahaja!")</script>';
			print '<meta http-equiv="refresh" content="0;URL=../pages/borangPengesahan.php">';	
	}
?>