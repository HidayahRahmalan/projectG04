<?php

include("../connection/config.php");

function getUsersData($id)
{
	$array = array();
	$q = mysql_query("SELECT * FROM staff WHERE staffIDEncrypt='$id'");
	while($r = mysql_fetch_assoc($q))
	{
		$array['staffID'] = $r['staffID'];
		$array['staffIDEncrypt'] = $r['staffIDEncrypt'];
		$array['staffName'] = $r['staffName'];
		$array['staffContact'] = $r['staffContact'];
		$array['staffEmail'] = $r['staffEmail'];
		$array['staffPosition'] = $r['staffPosition'];
		$array['staffPassword'] = $r['staffPassword'];
		$array['staffRowLevel'] = $r['staffRowLevel'];
		$array['branchID'] = $r['branchID'];
		$array['staffImg'] = $r['staffImg'];
	}
	return $array;
}

function getId($id)
{
	$q = mysql_query("SELECT `staffIDEncrypt` FROM `staff` WHERE `staffIDEncrypt`='".$id."'");
	while($r = mysql_fetch_assoc($q))
	{
		return $r['staffIDEncrypt'];
	}
}

function userExists($id)
{
	$numrows = mysql_num_rows(mysql_query("SELECT staffIDEncrypt FROM staff WHERE staffIDEncrypt='$id'"));
	if($numrows==1)
		return true;
	else
		return false;	
}
?>