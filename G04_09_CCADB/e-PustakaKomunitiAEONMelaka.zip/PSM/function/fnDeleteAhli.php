<!-- register data -->
<?php

include("../connection/config.php");

$memberID = $_GET['memberID'];

	$fnDeleteMember = "CALL fnDeleteMember('$memberID')";

		print '<meta http-equiv="refresh" content="0;URL=../pages/senaraiAhli.php">';

mysql_query($fnDeleteMember,$con)or die(mysql_error());
mysql_close($con);
?>