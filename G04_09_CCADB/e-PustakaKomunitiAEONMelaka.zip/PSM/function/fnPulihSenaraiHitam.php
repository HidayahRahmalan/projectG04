<!-- register data -->
<?php
include("../connection/config.php");

$memberID = $_GET['memberID'];
	
	$fnPulihSenaraiHitam = mysql_query("CALL fnPulihSenaraiHitam('$memberID')")or die(mysql_error());

	if($fnPulihSenaraiHitam){
		echo '<script language = "JavaScript">alert("Berjaya Pulih Ahli: '.$memberID.'!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/ahliSenaraiHitam.php">';
	}else{
		echo '<script language = "JavaScript">alert("Harap Maaf, Tidak Berjaya Pulih Ahli: '.$memberID.'!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/ahliSenaraiHitam.php">';
	}

	mysql_close($con);
?>