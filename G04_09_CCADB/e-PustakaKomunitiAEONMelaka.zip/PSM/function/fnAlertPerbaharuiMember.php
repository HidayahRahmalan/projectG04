<?php

$memberID = $_POST['memberID'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti memperbaharui ahli '.$memberID.'?");
	  
	  if(papar1==true)
	  {
		 self.location="fnPerbaharuiMember.php?memberID='.$memberID.'";
	  }
	  
	 else
	 {
		  self.location="../pages/paparanButiranAhli.php?memberID='.$memberID.'";
	 }
	  
	  </script>';
?>