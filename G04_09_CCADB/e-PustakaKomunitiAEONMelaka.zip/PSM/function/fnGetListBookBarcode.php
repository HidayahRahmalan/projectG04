<?php
  $bookISBN=$_GET['bookISBN'];

  include("../connection/config.php");
  error_reporting(E_ALL & ~E_NOTICE & ~8192);

  $fnGetListBarcode=mysql_query("CALL fnGetListBarcode('$bookISBN')")or die(mysql_error());

  echo'<div class="table-responsive">
      <table class="table">
          <thead>
              <tr>
                  <th>#</th>
                  <th>Book Title</th>
                  <th>Status</th>
                  <th>Action</th>
              </tr>
          </thead>
        <tbody>';
  while($row=mysql_fetch_array($fnGetListBarcode))
  {
  $bill++;
  $bookTitle = $row['bookTitle'];
  $bookStatus = $row['bookStatus'];
  $bookID = $row['bookID'];

    if($bookStatus == 'SEDIA ADA'){
    echo'<tr>
          <td>'.$bill.'</td>
          <td>'.$bookTitle.'</td>
          <td><label style="color: green">'.$bookStatus.'</label></td>
          <td><div class="checkbox">
                  <label>
                      <input type="checkbox" name="bookID" value="'.$bookID.'" checked="checked">
                  </label>
              </div>
          </td>
        </tr>';
    }
    if($bookStatus == 'DALAM PINJAMAN'){
    echo'<tr>
          <td>'.$bill.'</td>
          <td>'.$bookTitle.'</td>
          <td><label style="color: red">'.$bookStatus.'</label></td>
          <td><div class="checkbox">
                  <label>
                      <input type="checkbox" name="bookID" value="'.$bookID.'" id="disabledInput" disabled>
                  </label>
              </div>
          </td>
        </tr>';
    }
    if($bookStatus == 'TIADA'){
    echo'<tr>
          <td>'.$bill.'</td>
          <td>'.$bookTitle.'</td>
          <td><label style="color: orange">'.$bookStatus.'</label></td>
          <td><div class="checkbox">
                  <label>
                      <input type="checkbox" name="bookID" value="'.$bookID.'" id="disabledInput" disabled>
                  </label>
              </div>
          </td>
        </tr>';
    }

  }
  echo'</tbody>
    </table>
  </div>
</div>';
 ?>