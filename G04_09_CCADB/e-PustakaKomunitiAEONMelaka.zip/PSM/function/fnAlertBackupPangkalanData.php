<?php

$tableName = $_POST['tableName'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk muat turun Struktur Rajah '.$tableName.'?");
	  
	  if(papar1==true)
	  {
		 self.location="../backup/fnBackupPangkalanData.php?tableName='.$tableName.'";
	  }
	  
	 else
	 {
		  self.location="../pages/backupPangkalanData.php";
	 }
	  
	  </script>';
?>