<!-- register data -->
<?php

include("../connection/config.php");

$branchID = $_POST['branchID'];
$branchName = $_POST['branchName'];

	$fnEditCawangan = mysql_query("CALL fnEditCawangan('$branchID', '$branchName')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya update nama cawangan: '.$branchName.'!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/paparanSenaraiStaffMengikutCawangan.php?branchID='.$branchID.'">';

mysql_close($con);
?>