<?php

include("../connection/config.php");

$memberID = $_GET['memberID'];
$noticeDate = $_GET['noticeDate'];

	$checkExistOrNotMemberBlacklist = mysql_query("CALL checkExistOrNotMemberBlacklist('$memberID')")or die(mysql_error());
	mysql_close($con);

if(mysql_num_rows($checkExistOrNotMemberBlacklist)){

	echo '<script language = "JavaScript">alert("Harap Maaf no Ahli Sudah dihantar Notis! Sila semak Senarai Ahli Hitam untuk proses seterusnya!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/ahliSenaraiHitam.php">';
}else{

	include("../connection/config.php");
	mysql_query("CALL fnInsertNotisSekolahKanak('$memberID', '$noticeDate')")or die(mysql_error());
	mysql_close($con);

	//HERE TRIGGER AFTER INSERT ON BLACKLIST, INSERT INTO TABLE TOTAL_WARNING

	echo '<script language = "JavaScript">alert("Berjaya simpan maklumat!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/ahliSenaraiHitam.php">';
}
?>