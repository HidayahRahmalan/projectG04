<!-- register data -->
<?php
if(isset($_POST['btnTukarKataLaluan'])){

include("../connection/config.php");

$staffID = $_POST['staffID'];
$newPassword= $_POST['newPassword'];
$newPasswordEncrypt = md5($_POST['newPassword']);
$retypePassword = $_POST['retypePassword'];


	if($newPassword != $retypePassword){
		echo '<script language = "JavaScript">alert("Kata Laluan tidak padan!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/penetapanAkaun.php">';
	}

	else{

		mysql_query("CALL fnUpdatePenetapanKataLaluanStaff('$newPasswordEncrypt', '$staffID')")or die(mysql_error());

echo '<script language = "JavaScript">alert("Berjaya update kata laluan baru, silalog masuk semula!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=logout.php">';
	mysql_close($con);
	}

}
?>