<?php

    require('../connection/config.php');
    //error_reporting(E_ALL & ~E_NOTICE & ~8192);

    if(isset($_POST['staffID']) && isset($_POST['password']))
    {

            $userID= mysql_real_escape_string($_POST['staffID']);
            $password = md5(mysql_real_escape_string($_POST['password']));

        //User Login
        if(strlen($userID) <= 5){
            if($userID== "" || $password == ""){
                echo '<script language = "JavaScript">alert("Semua Ruangan Diperlukan!")</script>';
                            print '<meta http-equiv="refresh" content="0;URL=../index.php">';
            }

            else{
            include("../connection/config.php");
            $selectMemberLogin = mysql_query("CALL selectMemberLogin('$userID')")or die(mysql_error());
            $numrow = mysql_num_rows($selectMemberLogin);
            mysql_close($con);
            
                if($numrow!=0)
                {
                    while($row = mysql_fetch_assoc($selectMemberLogin))
                    {
                        $dbMemberID = $row['memberID'];
                        $dbMemberIDEncrypt = $row['memberIDEncrypt'];
                        $dbMemberPassword = $row['memberPassword'];
                    }
                
                    if($userID==$dbMemberID && $password==$dbMemberPassword)
                    {   

                        include("../connection/config.php");
                        //Insert audit_log
                        //mysql_query("CALL insertAuditLog('$userID')")or die(mysql_error());

                        session_start();
                        $_SESSION['memberIDEncrypt']=$dbMemberIDEncrypt;
                        //mysql_close($con);  

                            print '<meta http-equiv="refresh" content="0;URL=../pages/lamanUtamaMember.php">';             
                    }
                    else
                    {
                        echo '<script language = "JavaScript">alert("Kata Laluan dan ID:'.$userID.' Pengguna Member tidak sah!")</script>';
                            print '<meta http-equiv="refresh" content="0;URL=../index.php">';
                    }
                }
                else
                {
                    echo '<script language = "JavaScript">alert("Pengguna Tidak Wujud!")</script>';
                            print '<meta http-equiv="refresh" content="0;URL=../index.php">';
                }
            }
        }

        //Staff Login
        else{
            include("../connection/config.php");
            if($userID== "" || $password == ""){
                echo '<script language = "JavaScript">alert("Semua Ruangan Diperlukan!")</script>';
                            print '<meta http-equiv="refresh" content="0;URL=../index.php">';
            }

            else{
            $selectStaffLogin = mysql_query("CALL selectStaffLogin('$userID')")or die(mysql_error());
            $numrow = mysql_num_rows($selectStaffLogin);
            mysql_close($con);
            
                if($numrow!=0)
                {
                    while($row = mysql_fetch_assoc($selectStaffLogin))
                    {
                        $dbStaffID = $row['staffID'];
                        $dbStaffIDEncrypt = $row['staffIDEncrypt'];
                        $dbStaffPassword = $row['staffPassword'];
                        $dbStaffRowLevel = $row['staffRowLevel'];
                    }
                
                    if($userID==$dbStaffID && $password==$dbStaffPassword && $dbStaffRowLevel == 2)
                    {              
                        include("../connection/config.php"); 
                        //Insert audit_log
                        // mysql_query("CALL insertAuditLog('$userID')")or die(mysql_error());
                        // mysql_close($con);

                        session_start();
                        $_SESSION['staffIDEncrypt']=$dbStaffIDEncrypt;
                        mysql_close($con);

                            print '<meta http-equiv="refresh" content="0;URL=../pages/lamanUtamaStaf.php">';                     
                    }
                    if($userID==$dbStaffID && $password==$dbStaffPassword && $dbStaffRowLevel == 1)
                    {
                        include("../connection/config.php");
                        //Insert audit_log
                        //mysql_query("CALL insertAuditLog('$userID')")or die(mysql_error());
                        //mysql_close($con);

                        session_start();
                        $_SESSION['staffIDEncrypt']=$dbStaffIDEncrypt;
                        

                            print '<meta http-equiv="refresh" content="0;URL=../pages/lamanUtamaAdmin.php">';
                    }
                    //else
                    // {
                    //     echo '<script language = "JavaScript">alert("Kata Laluan dan ID:'.$userID.' Pengguna tidak sah!")</script>';
                    //             print '<meta http-equiv="refresh" content="0;URL=../index.php">';
                    // }
                }
                else
                {
                    echo '<script language = "JavaScript">alert("Pengguna Tidak Wujud!")</script>';
                            print '<meta http-equiv="refresh" content="0;URL=../index.php">';
                }
            }

        }
    }
    

?>