<?php

$branchID = $_GET['branchID'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk padam cawangan ini? Sekiranya anda padam cawangan ini, staff dibawah cawangan ini juga akan dipadam.");
	  
	  if(papar1==true)
	  {
		 self.location="fnDeleteCawangan.php?branchID='.$branchID.'";
	  }
	  
	 else
	 {
		  self.location="../pages/cawanganAdmin.php";
	 }
	  
	  </script>';
?>