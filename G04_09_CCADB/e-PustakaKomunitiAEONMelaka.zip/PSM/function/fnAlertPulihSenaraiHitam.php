<?php

$memberID = $_GET['memberID'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk pulihkan ahli: '.$memberID.' ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnPulihSenaraiHitam.php?memberID='.$memberID.'";
	  }
	  
	 else
	 {
		  self.location="../pages/ahliSenaraiHitam.php";
	 }
	  
	  </script>';
?>