<?php

include("../connection/config.php");


// BELIA || DEWASA InfoBlast 2 with 1 InfoBlast
if(isset($_POST['btnSubmitWarning2'])){

	$memberID = $_POST['memberID'];
	$infoBlastDate2 = $_POST['infoBlastDate2'];

	mysql_query("CALL insertInfoBlast2BeliaDewasa('$infoBlastDate2', '$memberID')")or die(mysql_error());

	//Here Occur Trigger trigUpdateInfoBlastBlacklist Update Total Warning +1

	echo '<script language = "JavaScript">alert("Berjaya update maklumat Tarikh Hantar Info Blast 2!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/ahliSenaraiHitam.php">';
}

// BELIA || DEWASA InfoBlast 3 with 2 InfoBlast
if(isset($_POST['btnSubmitWarning3'])){

	$memberID = $_POST['memberID'];
	$infoBlastDate3 = $_POST['infoBlastDate3'];

	mysql_query("CALL insertInfoBlast3BeliaDewasa('$infoBlastDate3', '$memberID')")or die(mysql_error());

	//Here Occur Trigger trigUpdateInfoBlastBlacklist Update Total Warning +1

	echo '<script language = "JavaScript">alert("Berjaya update maklumat Tarikh Hantar Info Blast 3!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/ahliSenaraiHitam.php">';
}

// BELIA || DEWASA Warning Letter with 3 InfoBlast
if(isset($_POST['btnSubmitWarningDewasaBelia'])){

	$memberID = $_POST['memberID'];
	$warningDate = $_POST['warningDate'];

	mysql_query("CALL insertWarningLetterBeliaDewasa3BeliaDewasa('$warningDate', '$memberID')")or die(mysql_error());

	//Here Occur Trigger trigUpdateInfoBlastBlacklist Update Total Warning +1

	echo '<script language = "JavaScript">alert("Berjaya update maklumat Tarikh Hantar Surat Amaran!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/ahliSenaraiHitam.php">';
}

// KANAK-KANAK SignBoard with 1 warning
if(isset($_POST['btnSubmitPapanTanda'])){

	$memberID = $_POST['memberID'];
	$signBoardDate = $_POST['signBoardDate'];

	mysql_query("CALL insertSignBoardDateKanak('$signBoardDate', '$memberID')")or die(mysql_error());

	//Here Occur Trigger trigUpdateInfoBlastBlacklist Update Total Warning +1

	echo '<script language = "JavaScript">alert("Berjaya update maklumat Tarikh Papan Tanda!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/ahliSenaraiHitam.php">';
}

// KANAK-KANAK warning letter with 2 warning
if(isset($_POST['btnSubmitWarningKanak'])){

	$memberID = $_POST['memberID'];
	$warningDate = $_POST['warningDate'];

	mysql_query("CALL insertWarningDateKanak('$warningDate', '$memberID')")or die(mysql_error());

	//Here Occur Trigger trigUpdateInfoBlastBlacklist Update Total Warning +1

	echo '<script language = "JavaScript">alert("Berjaya update maklumat Tarikh Surat Amaran!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/ahliSenaraiHitam.php">';
}
?>