<?php

$year = $_GET['year'];
$date = date("d/m/Y");
$header1 = "PERBADANAN PERPUSTAKAAN AWAM MELAKA (PERPUSTAM)";
$header2 = "PERPUSTAKAAN KOMUNITI AEON BANDARAYA MELAKA";
$header3 = "STATISTIK AHLI BARU MENGIKUT PECAHAN ETNIK $year";

  require_once('../excel/OLEwriter.php');
  require_once('../excel/BIFFwriter.php');
  require_once('../excel/Worksheet.php');
  require_once('../excel/Workbook.php');
  include("../connection/config.php");
  
    function HeaderingExcel($filename) {
      header("Content-type: application/vnd.ms-excel");
      header("Content-Disposition: attachment; filename=$filename" );
      header("Expires: 0");
      header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
      header("Pragma: public");
      }
	  
	  // HTTP headers
HeaderingExcel('AhliEtnik('.$date.').xls');// Creating a workbook
$workbook = new excel("-");
// Creating the first worksheet
$worksheet1 =& $workbook->add_worksheet('AhliEtnik('.$date.')');
$worksheet1->freeze_panes(1, 0);

	//Header table
   $worksheet1->write_string(0,1,"$header1");
   $worksheet1->write_string(1,1,"$header2");
   $worksheet1->write_string(2,1,"$header3");
   $worksheet1->write_string(4,0,"KATEGORI\BULAN");
   $worksheet1->write_string(4,1,"JAN");
   $worksheet1->write_string(4,2,"FEB");
   $worksheet1->write_string(4,3,"MAC");
   $worksheet1->write_string(4,4,"APR");
   $worksheet1->write_string(4,5,"MEI");
   $worksheet1->write_string(4,6,"JUN");
   $worksheet1->write_string(4,7,"JUL");
   $worksheet1->write_string(4,8,"AUG");
   $worksheet1->write_string(4,9,"SEPT");
   $worksheet1->write_string(4,10,"OKT");
   $worksheet1->write_string(4,11,"NOV");
   $worksheet1->write_string(4,12,"DIS");
   $worksheet1->write_string(4,13,"JUMLAH");

   $worksheet1->write_string(5,0,"MELAYU");
   $worksheet1->write_string(6,0,"CINA");
   $worksheet1->write_string(7,0,"INDIA");
   $worksheet1->write_string(8,0,"LAIN-LAIN");
   $worksheet1->write_string(9,0,"JUMLAH");

    include("../connection/config.php");
    //Get for month  Jan
  	$getDetailJan =mysql_query("CALL getDetailJanMemberRace('$year')")or die(mysql_error());
    $get1 = mysql_fetch_assoc($getDetailJan);
    $totalRaceMelayuJan = $get1['raceMelayu'];
    $totalRaceCinaJan = $get1['raceCina'];
    $totalRaceIndiaJan = $get1['raceIndia'];
    $totalRaceOtherJan = $get1['raceOther'];
    $totalAllRaceJan =  $totalRaceMelayuJan + $totalRaceCinaJan + $totalRaceIndiaJan + $totalRaceOtherJan;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month Feb
    $getDetailFeb =mysql_query("CALL getDetailFebMemberRace('$year')")or die(mysql_error());
    $get2 = mysql_fetch_assoc($getDetailFeb);
    $totalRaceMelayuFeb = $get2['raceMelayu'];
    $totalRaceCinaFeb = $get2['raceCina'];
    $totalRaceIndiaFeb = $get2['raceIndia'];
    $totalRaceOtherFeb = $get2['raceOther'];
    $totalAllRaceFeb =  $totalRaceMelayuFeb + $totalRaceCinaFeb + $totalRaceIndiaFeb + $totalRaceOtherFeb;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month March
    $getDetailMar =mysql_query("CALL getDetailMarMemberRace('$year')")or die(mysql_error());
    $get3 = mysql_fetch_assoc($getDetailMar);
    $totalRaceMelayuMar = $get3['raceMelayu'];
    $totalRaceCinaMar = $get3['raceCina'];
    $totalRaceIndiaMar = $get3['raceIndia'];
    $totalRaceOtherMar = $get3['raceOther'];
    $totalAllRaceMar =  $totalRaceMelayuMar + $totalRaceCinaMar + $totalRaceIndiaMar + $totalRaceOtherMar;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month April
    $getDetailApr =mysql_query("CALL getDetailAprMemberRace('$year')")or die(mysql_error());
    $get4 = mysql_fetch_assoc($getDetailApr);
    $totalRaceMelayuApr = $get4['raceMelayu'];
    $totalRaceCinaApr = $get4['raceCina'];
    $totalRaceIndiaApr = $get4['raceIndia'];
    $totalRaceOtherApr = $get4['raceOther'];
    $totalAllRaceApr =  $totalRaceMelayuApr + $totalRaceCinaApr + $totalRaceIndiaApr + $totalRaceOtherApr;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month May
    $getDetailMay =mysql_query("CALL getDetailMayMemberRace('$year')")or die(mysql_error());
    $get5 = mysql_fetch_assoc($getDetailMay);
    $totalRaceMelayuMay = $get5['raceMelayu'];
    $totalRaceCinaMay = $get5['raceCina'];
    $totalRaceIndiaMay = $get5['raceIndia'];
    $totalRaceOtherMay = $get5['raceOther'];
    $totalAllRaceMay =  $totalRaceMelayuMay + $totalRaceCinaMay + $totalRaceIndiaMay + $totalRaceOtherMay;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month Jun
    $getDetailJun =mysql_query("CALL getDetailJunMemberRace('$year')")or die(mysql_error());
    $get6 = mysql_fetch_assoc($getDetailJun);
    $totalRaceMelayuJun = $get6['raceMelayu'];
    $totalRaceCinaJun = $get6['raceCina'];
    $totalRaceIndiaJun = $get6['raceIndia'];
    $totalRaceOtherJun = $get6['raceOther'];
    $totalAllRaceJun =  $totalRaceMelayuJun + $totalRaceCinaJun + $totalRaceIndiaJun + $totalRaceOtherJun;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month July
    $getDetailJul =mysql_query("CALL getDetailJulMemberRace('$year')")or die(mysql_error());
    $get7 = mysql_fetch_assoc($getDetailJul);
    $totalRaceMelayuJul = $get7['raceMelayu'];
    $totalRaceCinaJul = $get7['raceCina'];
    $totalRaceIndiaJul = $get7['raceIndia'];
    $totalRaceOtherJul = $get7['raceOther'];
    $totalAllRaceJul =  $totalRaceMelayuJul + $totalRaceCinaJul + $totalRaceIndiaJul + $totalRaceOtherJul;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month August
    $getDetailAug =mysql_query("CALL getDetailAugMemberRace('$year')")or die(mysql_error());
    $get8 = mysql_fetch_assoc($getDetailAug);
    $totalRaceMelayuAug = $get8['raceMelayu'];
    $totalRaceCinaAug = $get8['raceCina'];
    $totalRaceIndiaAug = $get8['raceIndia'];
    $totalRaceOtherAug = $get8['raceOther'];
    $totalAllRaceAug =  $totalRaceMelayuAug + $totalRaceCinaAug + $totalRaceIndiaAug + $totalRaceOtherAug;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month September
    $getDetailSep =mysql_query("CALL getDetailSepMemberRace('$year')")or die(mysql_error());
    $get9 = mysql_fetch_assoc($getDetailSep);
    $totalRaceMelayuSep = $get9['raceMelayu'];
    $totalRaceCinaSep = $get9['raceCina'];
    $totalRaceIndiaSep = $get9['raceIndia'];
    $totalRaceOtherSep = $get9['raceOther'];
    $totalAllRaceSep =  $totalRaceMelayuSep + $totalRaceCinaSep + $totalRaceIndiaSep + $totalRaceOtherSep;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month October
    $getDetailOct =mysql_query("CALL getDetailOctMemberRace('$year')")or die(mysql_error());
    $get10 = mysql_fetch_assoc($getDetailOct);
    $totalRaceMelayuOct = $get10['raceMelayu'];
    $totalRaceCinaOct = $get10['raceCina'];
    $totalRaceIndiaOct = $get10['raceIndia'];
    $totalRaceOtherOct = $get10['raceOther'];
    $totalAllRaceOct =  $totalRaceMelayuOct + $totalRaceCinaOct + $totalRaceIndiaOct + $totalRaceOtherOct;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month November
    $getDetailNov =mysql_query("CALL getDetailNovMemberRace('$year')")or die(mysql_error());
    $get11 = mysql_fetch_assoc($getDetailNov);
    $totalRaceMelayuNov = $get11['raceMelayu'];
    $totalRaceCinaNov = $get11['raceCina'];
    $totalRaceIndiaNov = $get11['raceIndia'];
    $totalRaceOtherNov = $get11['raceOther'];
    $totalAllRaceNov =  $totalRaceMelayuNov + $totalRaceCinaNov + $totalRaceIndiaNov + $totalRaceOtherNov;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month December
    $getDetailDec =mysql_query("CALL getDetailDecMemberRace('$year')")or die(mysql_error());
    $get12 = mysql_fetch_assoc($getDetailDec);
    $totalRaceMelayuDec = $get12['raceMelayu'];
    $totalRaceCinaDec = $get12['raceCina'];
    $totalRaceIndiaDec = $get12['raceIndia'];
    $totalRaceOtherDec = $get12['raceOther'];
    $totalAllRaceDec =  $totalRaceMelayuDec + $totalRaceCinaDec + $totalRaceIndiaDec + $totalRaceOtherDec;
    mysql_close($con);

    include("../connection/config.php");
    //Get for total Race Melayu
    $getOverallRaceMelayu =mysql_query("CALL getOverallMelayuMemberRace('$year')")or die(mysql_error());
    $get13 = mysql_fetch_assoc($getOverallRaceMelayu);
    $totalOverallRaceMelayu = $get13['totalOverallRaceMelayu'];
    mysql_close($con);

    include("../connection/config.php");
    //Get for total Race Cina
    $getOverallRaceCina =mysql_query("CALL getOverallCinaMemberRace('$year')")or die(mysql_error());
    $get14 = mysql_fetch_assoc($getOverallRaceCina);
    $totalOverallRaceCina = $get14['totalOverallRaceCina'];
    mysql_close($con);

    include("../connection/config.php");
    //Get for total Race India
    $getOverallRaceIndia =mysql_query("CALL getOverallIndiaMemberRace('$year')")or die(mysql_error());
    $get15 = mysql_fetch_assoc($getOverallRaceIndia);
    $totalOverallRaceIndia = $get15['totalOverallRaceIndia'];
    mysql_close($con);

    include("../connection/config.php");
    //Get for total Race Lain-Lain
    $getOverallRaceOther =mysql_query("CALL getOverallOtherMemberRace('$year')")or die(mysql_error());
    $get16 = mysql_fetch_assoc($getOverallRaceOther);
    $totalOverallRaceOther = $get16['totalOverallRaceOther'];
    mysql_close($con);

    //Get for total all Race Year
    $getOverallRacePerYear = $totalAllRaceJan + $totalAllRaceFeb + $totalAllRaceMar + $totalAllRaceApr + $totalAllRaceMay + $totalAllRaceJun + $totalAllRaceJul + $totalAllRaceAug + $totalAllRaceSep + $totalAllRaceOct + $totalAllRaceNov + $totalAllRaceDec;

    include("../connection/config.php");
	$qryreport = mysql_query("CALL getExcellMemberRace('$year')") or die(mysql_error());
	
	$sqlrows=mysql_num_rows($qryreport);
	$j=4;
  $k=5;
  $l=6;
  $m=7;
  $n=8;
	
	while ($reportdisp=mysql_fetch_array($qryreport)) {
	$j=$j+1;
  $k=$k+1;
  $l=$l+1;
  $m=$m+1;
  $n=$n+1;

         //Row Melayu
		 $worksheet1->write_string($j,1,"$totalRaceMelayuJan");
         $worksheet1->write_string($j,2,"$totalRaceMelayuFeb");
		 $worksheet1->write_string($j,3,"$totalRaceMelayuMar");
		 $worksheet1->write_string($j,4,"$totalRaceMelayuApr");
		 $worksheet1->write_string($j,5,"$totalRaceMelayuMay");
		 $worksheet1->write_string($j,6,"$totalRaceMelayuJun");
		 $worksheet1->write_string($j,7,"$totalRaceMelayuJul");
		 $worksheet1->write_string($j,8,"$totalRaceMelayuAug");
		 $worksheet1->write_string($j,9,"$totalRaceMelayuSep");
		 $worksheet1->write_string($j,10,"$totalRaceMelayuOct");
		 $worksheet1->write_string($j,11,"$totalRaceMelayuNov");
		 $worksheet1->write_string($j,12,"$totalRaceMelayuDec");
         $worksheet1->write_string($j,13,"$totalOverallRaceMelayu");

         //Row Cina
         $worksheet1->write_string($k,1,"$totalRaceCinaJan");
         $worksheet1->write_string($k,2,"$totalRaceCinaFeb");
         $worksheet1->write_string($k,3,"$totalRaceCinaMar");
         $worksheet1->write_string($k,4,"$totalRaceCinaApr");
         $worksheet1->write_string($k,5,"$totalRaceCinaMay");
         $worksheet1->write_string($k,6,"$totalRaceCinaJun");
         $worksheet1->write_string($k,7,"$totalRaceCinaJul");
         $worksheet1->write_string($k,8,"$totalRaceCinaAug");
         $worksheet1->write_string($k,9,"$totalRaceCinaSep");
         $worksheet1->write_string($k,10,"$totalRaceCinaOct");
         $worksheet1->write_string($k,11,"$totalRaceCinaNov");
         $worksheet1->write_string($k,12,"$totalRaceCinaDec");
         $worksheet1->write_string($k,13,"$totalOverallRaceCina");

         //Row India
         $worksheet1->write_string($l,1,"$totalRaceIndiaJan");
         $worksheet1->write_string($l,2,"$totalRaceIndiaFeb");
         $worksheet1->write_string($l,3,"$totalRaceIndiaMar");
         $worksheet1->write_string($l,4,"$totalRaceIndiaApr");
         $worksheet1->write_string($l,5,"$totalRaceIndiaMay");
         $worksheet1->write_string($l,6,"$totalRaceIndiaJun");
         $worksheet1->write_string($l,7,"$totalRaceIndiaJul");
         $worksheet1->write_string($l,8,"$totalRaceIndiaAug");
         $worksheet1->write_string($l,9,"$totalRaceIndiaSep");
         $worksheet1->write_string($l,10,"$totalRaceIndiaOct");
         $worksheet1->write_string($l,11,"$totalRaceIndiaNov");
         $worksheet1->write_string($l,12,"$totalRaceIndiaDec");
         $worksheet1->write_string($l,13,"$totalOverallRaceIndia");

         //Row Other
         $worksheet1->write_string($m,1,"$totalRaceOtherJan");
         $worksheet1->write_string($m,2,"$totalRaceOtherFeb");
         $worksheet1->write_string($m,3,"$totalRaceOtherMar");
         $worksheet1->write_string($m,4,"$totalRaceOtherApr");
         $worksheet1->write_string($m,5,"$totalRaceOtherMay");
         $worksheet1->write_string($m,6,"$totalRaceOtherJun");
         $worksheet1->write_string($m,7,"$totalRaceOtherJul");
         $worksheet1->write_string($m,8,"$totalRaceOtherAug");
         $worksheet1->write_string($m,9,"$totalRaceOtherSep");
         $worksheet1->write_string($m,10,"$totalRaceOtherOct");
         $worksheet1->write_string($m,11,"$totalRaceOtherNov");
         $worksheet1->write_string($m,12,"$totalRaceOtherDec");
         $worksheet1->write_string($m,13,"$totalOverallRaceOther");

         //Row Jumlah
         $worksheet1->write_string($n,1,"$totalAllRaceJan");
         $worksheet1->write_string($n,2,"$totalAllRaceFeb");
         $worksheet1->write_string($n,3,"$totalAllRaceMar");
         $worksheet1->write_string($n,4,"$totalAllRaceApr");
         $worksheet1->write_string($n,5,"$totalAllRaceMay");
         $worksheet1->write_string($n,6,"$totalAllRaceJun");
         $worksheet1->write_string($n,7,"$totalAllRaceJul");
         $worksheet1->write_string($n,8,"$totalAllRaceAug");
         $worksheet1->write_string($n,9,"$totalAllRaceSep");
         $worksheet1->write_string($n,10,"$totalAllRaceOct");
         $worksheet1->write_string($n,11,"$totalAllRaceNov");
         $worksheet1->write_string($n,12,"$totalAllRaceDec");
         $worksheet1->write_string($n,13,"$getOverallRacePerYear");
	}
	
$workbook->close();
mysql_close($con);
?>