<!-- register data -->
<?php

include("../connection/config.php");

$attendanceID = $_GET['attendanceID'];
$attendanceTotal = $_GET['attendanceTotal'];

$getDetailAttendance = mysql_query("SELECT * FROM attendance WHERE attendanceID='$attendanceID'");
$get = mysql_fetch_assoc($getDetailAttendance);
$attendanceDate = $get['attendanceDate'];
$attendanceGender = $get['attendanceGender'];
$attendanceRace = $get['attendanceRace'];
$attendanceCategory = $get['attendanceCategory'];
$monthNum = substr($attendanceDate, 5, 2);
$monthNameTemp = date("F", mktime(0, 0, 0, $monthNum, 10));
$year = substr($attendanceDate, 0, 4);
$monthName = substr($monthNameTemp, 0, 3);

	$sql = "UPDATE attendance SET attendanceTotal=attendanceTotal-'$attendanceTotal' WHERE attendanceID='$attendanceID'";

	if($attendanceGender == 'Lelaki' && $attendanceRace='Melayu' && $attendanceCategory == 'Dewasa'){
			//UPDATE attendance_statistic Lelaki (--)
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale-'$attendanceTotal', raceMelayu=raceMelayu-'$attendanceTotal', adult=adult-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender='Wanita' && $attendanceRace='Melayu' && $attendanceCategory == 'Dewasa'){
			//UPDATE attendance_statistic Wanita(--)
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale-'$attendanceTotal', raceMelayu=raceMelayu-'$attendanceTotal', adult=adult-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace='Melayu' && $attendanceCategory == 'Belia'){
			//UPDATE attendance_statistic Lelaki (--)
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale-'$attendanceTotal', raceMelayu=raceMelayu-'$attendanceTotal', youth=youth-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender='Wanita' && $attendanceRace='Melayu' && $attendanceCategory == 'Belia'){
			//UPDATE attendance_statistic Wanita(--)
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale-'$attendanceTotal', raceMelayu=raceMelayu-'$attendanceTotal', youth=youth-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace='Melayu' && $attendanceCategory == 'Kanak-Kanak'){
			//UPDATE attendance_statistic Lelaki (--)
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale-'$attendanceTotal', raceMelayu=raceMelayu-'$attendanceTotal', kid=kid-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender='Wanita' && $attendanceRace='Melayu' && $attendanceCategory == 'Kanak-Kanak'){
			//UPDATE attendance_statistic Wanita(--)
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale-'$attendanceTotal', raceMelayu=raceMelayu-'$attendanceTotal', kid=kid-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace='CINA' && $attendanceCategory == 'Dewasa'){
			//UPDATE attendance_statistic Lelaki (--)
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale-'$attendanceTotal', raceCina=raceCina-'$attendanceTotal', adult=adult-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender='Wanita' && $attendanceRace='CINA' && $attendanceCategory == 'Dewasa'){
			//UPDATE attendance_statistic Wanita(--)
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale-'$attendanceTotal', raceCina=raceCina-'$attendanceTotal', adult=adult-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace='CINA' && $attendanceCategory == 'Belia'){
			//UPDATE attendance_statistic Lelaki (--)
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale-'$attendanceTotal', raceCina=raceCina-'$attendanceTotal', youth=youth-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender='Wanita' && $attendanceRace='CINA' && $attendanceCategory == 'Belia'){
			//UPDATE attendance_statistic Wanita(--)
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale-'$attendanceTotal', raceCina=raceCina-'$attendanceTotal', youth=youth-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace='CINA' && $attendanceCategory == 'Kanak-Kanak'){
			//UPDATE attendance_statistic Lelaki (--)
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale-'$attendanceTotal', raceCina=raceCina-'$attendanceTotal', kid=kid-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender='Wanita' && $attendanceRace='CINA' && $attendanceCategory == 'Kanak-Kanak'){
			//UPDATE attendance_statistic Wanita(--)
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale-'$attendanceTotal', raceCina=raceCina-'$attendanceTotal', kid=kid-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace='INDIA' && $attendanceCategory == 'Dewasa'){
			//UPDATE attendance_statistic Lelaki (--)
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale-'$attendanceTotal', raceIndia=raceIndia-'$attendanceTotal', adult=adult-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender='Wanita' && $attendanceRace='INDIA' && $attendanceCategory == 'Dewasa'){
			//UPDATE attendance_statistic Wanita(--)
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale-'$attendanceTotal', raceIndia=raceIndia-'$attendanceTotal', adult=adult-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace='INDIA' && $attendanceCategory == 'Belia'){
			//UPDATE attendance_statistic Lelaki (--)
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale-'$attendanceTotal', raceIndia=raceIndia-'$attendanceTotal', youth=youth-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender='Wanita' && $attendanceRace='INDIA' && $attendanceCategory == 'Belia'){
			//UPDATE attendance_statistic Wanita(--)
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale-'$attendanceTotal', raceIndia=raceIndia-'$attendanceTotal', youth=youth-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace='INDIA' && $attendanceCategory == 'Kanak-Kanak'){
			//UPDATE attendance_statistic Lelaki (--)
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale-'$attendanceTotal', raceIndia=raceIndia-'$attendanceTotal', kid=kid-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender='Wanita' && $attendanceRace='INDIA' && $attendanceCategory == 'Kanak-Kanak'){
			//UPDATE attendance_statistic Wanita(--)
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale-'$attendanceTotal', raceIndia=raceIndia-'$attendanceTotal', kid=kid-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace='Lain-Lain' && $attendanceCategory == 'Dewasa'){
			//UPDATE attendance_statistic Lelaki (--)
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale-'$attendanceTotal', raceOther=raceOther-'$attendanceTotal', adult=adult-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender='Wanita' && $attendanceRace='Lain-Lain' && $attendanceCategory == 'Dewasa'){
			//UPDATE attendance_statistic Wanita(--)
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale-'$attendanceTotal', raceOther=raceOther-'$attendanceTotal', adult=adult-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace='Lain-Lain' && $attendanceCategory == 'Belia'){
			//UPDATE attendance_statistic Lelaki (--)
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale-'$attendanceTotal', raceOther=raceOther-'$attendanceTotal', youth=youth-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender='Wanita' && $attendanceRace='Lain-Lain' && $attendanceCategory == 'Belia'){
			//UPDATE attendance_statistic Wanita(--)
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale-'$attendanceTotal', raceOther=raceOther-'$attendanceTotal', youth=youth-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender == 'Lelaki' && $attendanceRace='Lain-Lain' && $attendanceCategory == 'Kanak-Kanak'){
			//UPDATE attendance_statistic Lelaki (--)
			mysql_query("UPDATE attendance_statistic SET totalMale=totalMale-'$attendanceTotal', raceOther=raceOther-'$attendanceTotal', kid=kid-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}
		elseif($attendanceGender='Wanita' && $attendanceRace='Lain-Lain' && $attendanceCategory == 'Kanak-Kanak'){
			//UPDATE attendance_statistic Wanita(--)
			mysql_query("UPDATE attendance_statistic SET totalFemale=totalFemale-'$attendanceTotal', raceOther=raceOther-'$attendanceTotal', kid=kid-'$attendanceTotal' WHERE month='$monthName' AND year='$year'");

			print '<meta http-equiv="refresh" content="0;URL=../pages/kedatanganPengunjung.php">';
		}

mysql_query($sql,$con);
mysql_close($con);
?>