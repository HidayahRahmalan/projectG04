<?php
if(isset($_POST['btnEditGambar']))
{
	include("../connection/config.php");

	$staffID = $_POST['staffID'];	
	$imageName = mysql_real_escape_string($_FILES["image"]["name"]);
	$imageData = mysql_real_escape_string(file_get_contents($_FILES["image"]["tmp_name"]));
	$imageType = mysql_real_escape_string($_FILES["image"]["type"]);
	
	if(substr($imageType,0,5) == "image")
	{
		$updateImageStaff = mysql_query("CALL fnUpdateGambarPengguna('$imageData', '$staffID')")or die(mysql_error());
		
		if($updateImageStaff){
			echo '<script language = "JavaScript">alert("Berjaya update gambar akaun profil!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/penetapanAkaun.php">';
		}else{
			echo '<script language = "JavaScript">alert("Harap Maaf, Tidak Berjaya update gambar akaun profil!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/penetapanAkaun.php">';
		}
		
	}
	
	else
	{
		echo '<script language = "JavaScript">alert("Hanya fail gambar sahaja dibenarkan!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/penetapanAkaun.php">';
	}
	
	
}
?>