<!-- register data -->
<?php

include("../connection/config.php");

$signBoardDate = $_GET['signBoardDate'];
$noticeDate = $_GET['noticeDate'];
$warningDate = $_GET['warningDate'];
$memberID = $_GET['memberID'];

	mysql_query("CALL fnEditLogButiranHitamKanak('$noticeDate', '$signBoardDate', '$warningDate', '$memberID')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya Update Butiran Log Hitam ahli: '.$memberID.'!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/editButiranSenaraiHitam.php?memberID='.$memberID.'">';

mysql_close($con);
?>