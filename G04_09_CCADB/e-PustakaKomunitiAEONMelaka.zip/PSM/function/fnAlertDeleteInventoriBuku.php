<?php

$bookID = $_GET['bookID'];
$bookStatus = $_GET['bookStatus'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk padam buku ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnDeleteInventoriBuku.php?bookID='.$bookID.'&bookStatus='.$bookStatus.'";
	  }
	  
	 else
	 {
		  self.location="../pages/inventoriBuku.php";
	 }
	  
	  </script>';
?>