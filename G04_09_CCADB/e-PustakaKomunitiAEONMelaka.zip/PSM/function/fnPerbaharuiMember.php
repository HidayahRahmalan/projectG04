<!-- register data -->
<?php
include("../connection/config.php");

$memberID = $_GET['memberID'];

	mysql_query("CALL fnPerbaharuiMember('$memberID')");

	echo '<script language = "JavaScript">alert("Berjaya memperbaharui keahlian")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/paparanButiranAhli.php?memberID='.$memberID.'">';
?>