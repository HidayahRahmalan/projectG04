<?php
	include("../connection/config.php");

	$memberID = $_GET['memberID'];
	$formComment = $_GET['formComment'];	

		$fnUpdateCopPengesahanMemberTidakSah = mysql_query("CALL fnUpdateCopPengesahanMemberTidakSah('$formComment', '$memberID')")or die(mysql_error());

// 		$fnUpdateCopPengesahanMemberTidakSah = mysql_query("UPDATE form SET formStatus='TIDAK SAH', 
// formComment='$formComment' WHERE memberID='$memberID'")or die(mysql_error());
		
	if($fnUpdateCopPengesahanMemberTidakSah){
		echo '<script language = "JavaScript">alert("Maklumat status ahli tidak sah berjaya disimpan!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/senaraiAhli.php">';
	}else{
		echo '<script language = "JavaScript">alert("Harap maaf, Maklumat status ahli tidak sah tidak berjaya disimpan!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/senaraiAhli.php">';
	}
		
		
?>