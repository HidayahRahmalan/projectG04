<!-- register data -->
<?php

include("../connection/config.php");

$staffID = $_GET['staffID'];

	$sql = "CALL fnDeleteStaff('$staffID')";

		print '<meta http-equiv="refresh" content="0;URL=../pages/penggunaSistem.php">';

mysql_query($sql,$con);
mysql_close($con);
?>