<?php

$staffID = $_GET['staffID'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk padam staff ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnDeleteStaff.php?staffID='.$staffID.'";
	  }
	  
	 else
	 {
		  self.location="../pages/penggunaSistem.php";
	 }
	  
	  </script>';
?>