<?php
	include("../connection/config.php");

	$memberID = $_GET['memberID'];	
	$formComment = $_GET['formComment'];	

		$fnUpdateCopPengesahanMemberSah = mysql_query("CALL fnUpdateCopPengesahanMemberSah('$formComment', '$memberID')")or die(mysql_error());

		// $fnUpdateCopPengesahanMemberSah = mysql_query("UPDATE form SET formStatus='SAH', formComment='$formComment' WHERE memberID='$memberID'")or die(mysql_error());

		
	if($fnUpdateCopPengesahanMemberSah){
		echo '<script language = "JavaScript">alert("Maklumat ahli sah berjaya disimpan!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/senaraiAhli.php">';
	}else{
		echo '<script language = "JavaScript">alert("Harap Maaf, Maklumat ahli sah tidak berjaya disimpan!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/senaraiAhli.php">';
	}
?>