<!-- register data -->
<?php
include("../connection/config.php");

$staffID = $_POST['staffID'];
$staffIDEncrypt = md5($_POST['staffID']);
$staffName = $_POST['staffName'];
$staffContact = $_POST['staffContact'];
$staffEmail = $_POST['staffEmail'];
$staffPosition = $_POST['staffPosition'];
$staffPassword = "202cb962ac59075b964b07152d234b70";
$staffRowLevel = $_POST['staffRowLevel'];
$branchID = $_POST['branchID'];

	$sql = mysql_query("CALL fnRegisterStaff('$staffID', '$staffIDEncrypt', '$staffName', '$staffContact', '$staffEmail', '$staffPosition', '$staffPassword', '$staffRowLevel', '$branchID')")or die(mysql_error());

	if($sql){
		echo '<script language = "JavaScript">alert("Berjaya daftar pengguna staf: '.$staffID.'!")</script>';
			print '<meta http-equiv="refresh" content="0;URL=../pages/penggunaSistem.php">';
	}else{
		echo '<script language = "JavaScript">alert("Maaf tidak berjaya daftar pengguna staf: '.$staffID.'!")</script>';
			print '<meta http-equiv="refresh" content="0;URL=../pages/penggunaSistem.php">';
	}
	
mysql_close($con);
?>