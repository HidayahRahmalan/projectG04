<?php
  $bookTitle=$_GET['bookTitle'];

  include("../connection/config.php");
  error_reporting(E_ALL & ~E_NOTICE & ~8192);

  $fnGetListSearchBook=mysql_query("CALL fnGetListSearchBook('$bookTitle')")or die(mysql_error());

  echo'<div class="table-responsive">
      <table class="table">
          <thead>
              <tr>
                  <th>#</th>
                  <th>Book Title</th>
                  <th>Status</th>
                  <th>Action</th>
              </tr>
          </thead>
        <tbody>';
  while($row=mysql_fetch_array($fnGetListSearchBook))
  {
  $bill2++;
  $bookTitle = $row['bookTitle'];
  $bookStatus = $row['bookStatus'];
  $bookID = $row['bookID'];

    if($bookStatus == 'SEDIA ADA'){
    echo'<tr>
          <td>'.$bill2.'</td>
          <td>'.$bookTitle.'</td>
          <td><label style="color: green">'.$bookStatus.'</label></td>
          <td><div class="checkbox">
                  <label>
                      <input type="checkbox" name="bookID" value="'.$bookID.'">
                  </label>
              </div>
          </td>
        </tr>';
    }
    if($bookStatus == 'DALAM PINJAMAN'){
    echo'<tr>
          <td>'.$bill2.'</td>
          <td>'.$bookTitle.'</td>
          <td><label style="color: red">'.$bookStatus.'</label></td>
          <td><div class="checkbox">
                  <label>
                      <input type="checkbox" name="bookID" value="'.$bookID.'" id="disabledInput" disabled>
                  </label>
              </div>
          </td>
        </tr>';
    }
    if($bookStatus == 'TIADA'){
    echo'<tr>
          <td>'.$bill2.'</td>
          <td>'.$bookTitle.'</td>
          <td><label style="color: orange">'.$bookStatus.'</label></td>
          <td><div class="checkbox">
                  <label>
                      <input type="checkbox" name="bookID" value="'.$bookID.'" id="disabledInput" disabled>
                  </label>
              </div>
          </td>
        </tr>';
    }

  }
  echo'</tbody>
    </table>
  </div>
</div>';
mysql_close($con);
 ?>