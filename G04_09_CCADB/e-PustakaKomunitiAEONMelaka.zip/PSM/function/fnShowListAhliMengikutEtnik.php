<?php
include("../connection/config.php");
$year=$_GET['year'];
?>
<div id="buttonAreaEtnik">
    <div>
        <button title="Muat Turun Excel" type="submit" class="btn btn-default"><i class="fa fa-file-excel-o" onclick="window.location.href='../function/fnExcellMemberByRace.php?year=<?php echo $year; ?>'"></i></button>&nbsp;<button type="submit" onClick="printDivEtnik('printableAreaEtnik')" title="Cetak" type="submit" class="btn btn-default"><i class="fa fa-print fa-fw"></i></button>
    </div>
</div>
<br>
<table class="table table-striped table-bordered table-hover">
    <tbody>
    <?php
        include("../connection/config.php");
        $select=mysql_query("CALL fnExcellMemberByRace('$year')")or die(mysql_error());
        mysql_close($con);

        echo'<thead>
            <tr>
                <th>Bulan| '.$year.'</th>
                <th>Melayu</th>
                <th>Cina</th>
                <th>India</th>
                <th>Lain</th>
                <th>Jumlah</th>
            </tr>
        </thead>';
        while($row=mysql_fetch_array($select))
        {
        $totalMale = $row['totalMale'];
        $totalFemale = $row['totalFemale'];
        $raceMelayu = $row['raceMelayu'];
        $raceCina = $row['raceCina'];
        $raceIndia = $row['raceIndia'];
        $raceOther = $row['raceOther'];
        $month = $row['month'];
        $totalAllHorizontal = $raceMelayu + $raceCina + $raceIndia + $raceOther; //Mendatar
        echo'<tr>';
        echo '<td>'.$month.'</td>';
        echo '<td style="color: blue">'.$raceMelayu.'</td>';
        echo '<td style="color: red">'.$raceCina.'</td>';
        echo '<td style="color: green">'.$raceIndia.'</td>';
        echo '<td style="color: purple">'.$raceOther.'</td>';
        echo '<td><b>'.$totalAllHorizontal.'</b></td>';
        echo'</tr>';
        }

        include("../connection/config.php");
        $getTotalRaceMelayu =mysql_query("CALL getTotalRaceMelayuMemberByRace('$year')")or die(mysql_error());
        $get = mysql_fetch_assoc($getTotalRaceMelayu);
        $totalRaceMelayu = $get['totalRaceMelayu'];
        mysql_close($con);

        include("../connection/config.php");
        $getTotalRaceCina =mysql_query("CALL getTotalRaceCinaMemberByRace('$year')")or die(mysql_error());
        $get1 = mysql_fetch_assoc($getTotalRaceCina);
        $totalRaceCina = $get1['totalRaceCina'];
        mysql_close($con);

        include("../connection/config.php");
        $getTotalRaceIndia =mysql_query("CALL getTotalRaceIndiaMemberByRace('$year')")or die(mysql_error());
        $get2 = mysql_fetch_assoc($getTotalRaceIndia);
        $totalRaceIndia = $get2['totalRaceIndia'];
        mysql_close($con);

        include("../connection/config.php");
        $getTotalRaceOther =mysql_query("CALL getTotalRaceOtherMemberByRace('$year')")or die(mysql_error());
        $get3 = mysql_fetch_assoc($getTotalRaceOther);
        $totalRaceOther = $get3['totalRaceOther'];
        mysql_close($con);

        $totalOveralRace = $totalRaceMelayu + $totalRaceCina + $totalRaceIndia + $totalRaceOther;

        echo'<tr>
                <td><b>Jumlah</b></td>
                <td><b>'.$totalRaceMelayu.'<b></td>
                <td><b>'.$totalRaceCina.'<b></td>
                <td><b>'.$totalRaceIndia.'</b></td>
                <td><b>'.$totalRaceOther.'<b></td>
                <td><b>'.$totalOveralRace.'</b></td>
            </tr>';
    ?>  
    </tbody>
</table>