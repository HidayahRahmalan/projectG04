<?php

$noticeDate = $_POST['noticeDate'];
$signBoardDate = $_POST['signBoardDate'];
$warningDate = $_POST['warningDate'];
$memberID = $_POST['memberID'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk Edit Butiran Log Tarikh Senarai Hitam ahli ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnEditLogButiranHitamKanak.php?noticeDate='.$noticeDate.'&signBoardDate='.$signBoardDate.'&warningDate='.$warningDate.'&memberID='.$memberID.'";
	  }
	  
	 else
	 {
		  self.location="../pages/editButiranSenaraiHitam.php?memberID='.$memberID.'";
	 }
	  
	  </script>';
?>