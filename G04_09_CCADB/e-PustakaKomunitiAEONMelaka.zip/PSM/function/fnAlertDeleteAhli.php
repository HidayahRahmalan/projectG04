<?php

$memberID = $_GET['memberID'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk padam ahli ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnDeleteAhli.php?memberID='.$memberID.'";
	  }
	  
	 else
	 {
		  self.location="../pages/senaraiAhli.php";
	 }
	  
	  </script>';
?>