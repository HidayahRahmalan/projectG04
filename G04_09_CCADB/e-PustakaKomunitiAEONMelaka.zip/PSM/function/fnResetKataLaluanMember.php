<!-- register data -->
<?php

include("../connection/config.php");

$memberID = $_GET['memberID'];
$newPasswordEncrypt = md5("abc123");

	$sql = mysql_query("CALL fnResetKataLaluanMember('$memberID', '$newPasswordEncrypt')")or die(mysql_error());

	if($sql){
		echo '<script language = "JavaScript">alert("Berjaya reset kata laluan ahli: '.$memberID.'")</script>';
			print '<meta http-equiv="refresh" content="0;URL=../pages/paparanButiranAhli.php?memberID='.$memberID.'">';
	}else{
		echo '<script language = "JavaScript">alert("Harap Maaf Tidak Berjaya reset kata laluan ahli: '.$memberID.'")</script>';
			print '<meta http-equiv="refresh" content="0;URL=../pages/paparanButiranAhli.php?memberID='.$memberID.'">';
	}
?>