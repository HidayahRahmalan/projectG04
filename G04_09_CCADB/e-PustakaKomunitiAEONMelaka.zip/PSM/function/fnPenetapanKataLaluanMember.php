<!-- register data -->
<?php
if(isset($_POST['btnTukarKataLaluan'])){

include("../connection/config.php");

$memberID = $_POST['memberID'];
$newPassword= $_POST['newPassword'];
$newPasswordEncrypt = md5($_POST['newPassword']);
$retypePassword = $_POST['retypePassword'];


	if($newPassword != $retypePassword){
		echo '<script language = "JavaScript">alert("Kata Laluan tidak padan!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/penetapanAkaunMember.php">';
	}

	else{
	mysql_query("call fnUpdatePenetapanKataLaluanMember('$newPasswordEncrypt', '$memberID')")or die(mysql_error());

echo '<script language = "JavaScript">alert("Berjaya update kata laluan baru, silalog masuk semula!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=logout.php">';
	}

}
?>