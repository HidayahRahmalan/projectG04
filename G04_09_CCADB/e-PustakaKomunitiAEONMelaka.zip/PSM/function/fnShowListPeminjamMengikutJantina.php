<?php
include("../connection/config.php");
$year=$_GET['year'];
?>
<div id="buttonAreaJantina">
    <button title="Muat Turun Excel" type="submit" class="btn btn-default"><i class="fa fa-file-excel-o" onclick="window.location.href='../function/fnExcellBorrowerByGender.php?year=<?php echo $year; ?>'"></i></button>&nbsp;<button type="submit" onClick="printDivJantina('printableAreaJantina')" title="Cetak" type="submit" class="btn btn-default"><i class="fa fa-print fa-fw"></i></button>

</div>
<br>
<table class="table table-striped table-bordered table-hover">
    <tbody>
    <?php
        include("../connection/config.php");
        $select=mysql_query("CALL fnExcellBorrowerByGender('$year')")or die(mysql_error());
        mysql_close($con);

        echo'<thead>
            <tr>
                <th>Bulan | '.$year.'</th>
                <th>Lelaki</th>
                <th>Perempuan</th>
                <th>Jumlah</th>
            </tr>
        </thead>';
        while($row=mysql_fetch_array($select))
        {
        $totalMale = $row['totalMale'];
        $totalFemale = $row['totalFemale'];
        $month = $row['month'];
        $totalAllHorizontal = $totalMale + $totalFemale;
        echo'<tr>';
        echo '<td>'.$month.'</td>';
        echo '<td style="color: blue">'.$totalMale.'</td>';
        echo '<td style="color: red">'.$totalFemale.'</td>';
        echo '<td><b>'.$totalAllHorizontal.'</b></td>';
        echo'</tr>';
        }

        include("../connection/config.php");
        $getTotalMale =mysql_query("CALL getTotalMaleBorrowByGender('$year')")or die(mysql_error());
        $get = mysql_fetch_assoc($getTotalMale);
        $totalOverallMale = $get['totalOverallMale'];
        mysql_close($con);

        include("../connection/config.php");
        $getTotalFemale =mysql_query("CALL getTotalFemaleBorrowByGender('$year')")or die(mysql_error());
        $get1 = mysql_fetch_assoc($getTotalFemale);
        $totalOverallFemale = $get1['totalOverallFemale'];
        mysql_close($con);

        $totalOveralMaleFemale = $totalOverallMale + $totalOverallFemale;

        echo'<tr>
                <td><b>Jumlah</b></td>
                <td><b>'.$totalOverallMale.'<b></td>
                <td><b>'.$totalOverallFemale.'<b></td>
                <td><b>'.$totalOveralMaleFemale.'</b></td>
            </tr>';
    ?>  
    </tbody>
</table>