<?php

	include("../connection/config.php");

	$memberID = $_GET['memberID'];	

		$fnUpdateStatusMemberDalamProses = mysql_query("CALL fnUpdateStatusMemberDalamProses('$memberID')")or die(mysql_error());
		
		if($fnUpdateStatusMemberDalamProses){
			echo '<script language = "JavaScript">alert("Maklumat ahli dalam proses pengesahan berjaya disimpan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/ahliBaru.php">';
		}else{
			echo '<script language = "JavaScript">alert("Harap Maaf, Maklumat ahli dalam proses pengesahan tidak berjaya disimpan!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/ahliBaru.php">';
		}
		
		
?>