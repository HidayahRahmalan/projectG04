<?php

$borrowID = $_GET['borrowID'];
$memberID = $_GET['memberID'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk Batal Peminjaman Buku ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnBatalPinjaman.php?borrowID='.$borrowID.'&memberID='.$memberID.'";
	  }
	  
	 else
	 {
		  self.location="../pages/paparanButiranPeminjamBuku.php?memberID='.$memberID.'";
	 }
	  
	  </script>';
?>