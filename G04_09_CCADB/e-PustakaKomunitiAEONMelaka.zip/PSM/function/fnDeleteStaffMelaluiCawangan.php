<!-- register data -->
<?php

include("../connection/config.php");

$staffID = $_GET['staffID'];
$branchID = $_GET['branchID'];

	$sql = "CALL fnDeleteStaff('$staffID')";

	print '<meta http-equiv="refresh" content="0;URL=../pages/paparanSenaraiStaffMengikutCawangan.php?branchID='.$branchID.'">';

mysql_query($sql,$con);
mysql_close($con);
?>