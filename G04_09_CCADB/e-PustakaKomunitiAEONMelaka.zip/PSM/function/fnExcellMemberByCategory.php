<?php

$year = $_GET['year'];
$date = date("d/m/Y");
$header1 = "PERBADANAN PERPUSTAKAAN AWAM MELAKA (PERPUSTAM)";
$header2 = "PERPUSTAKAAN KOMUNITI AEON BANDARAYA MELAKA";
$header3 = "STATISTIK AHLI BARU MENGIKUT PECAHAN KATEGORI $year";

  require_once('../excel/OLEwriter.php');
  require_once('../excel/BIFFwriter.php');
  require_once('../excel/Worksheet.php');
  require_once('../excel/Workbook.php');
  include("../connection/config.php");
  
    function HeaderingExcel($filename) {
      header("Content-type: application/vnd.ms-excel");
      header("Content-Disposition: attachment; filename=$filename" );
      header("Expires: 0");
      header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
      header("Pragma: public");
      }
	  
	  // HTTP headers
HeaderingExcel('AhliKategori('.$date.').xls');// Creating a workbook
$workbook = new excel("-");
// Creating the first worksheet
$worksheet1 =& $workbook->add_worksheet('AhliKategori('.$date.')');
$worksheet1->freeze_panes(1, 0);

	//Header table
   $worksheet1->write_string(0,1,"$header1");
   $worksheet1->write_string(1,1,"$header2");
   $worksheet1->write_string(2,1,"$header3");
   $worksheet1->write_string(4,0,"KATEGORI\BULAN");
   $worksheet1->write_string(4,1,"JAN");
   $worksheet1->write_string(4,2,"FEB");
   $worksheet1->write_string(4,3,"MAC");
   $worksheet1->write_string(4,4,"APR");
   $worksheet1->write_string(4,5,"MEI");
   $worksheet1->write_string(4,6,"JUN");
   $worksheet1->write_string(4,7,"JUL");
   $worksheet1->write_string(4,8,"AUG");
   $worksheet1->write_string(4,9,"SEPT");
   $worksheet1->write_string(4,10,"OKT");
   $worksheet1->write_string(4,11,"NOV");
   $worksheet1->write_string(4,12,"DIS");
   $worksheet1->write_string(4,13,"JUMLAH");

   $worksheet1->write_string(5,0,"DEWASA");
   $worksheet1->write_string(6,0,"BELIA");
   $worksheet1->write_string(7,0,"KANAK-KANAK");
   $worksheet1->write_string(8,0,"JUMLAH");

    include("../connection/config.php");
    //Get for month  Jan
  	$getDetailJan =mysql_query("CALL getDetailJanMemberCategory('$year')")or die(mysql_error());
    $get1 = mysql_fetch_assoc($getDetailJan);
    $totalAdultJan = $get1['adult'];
    $totalYouthJan = $get1['youth'];
    $totalKidJan = $get1['kid'];
    $totalAllCategoryJan = $totalAdultJan + $totalYouthJan + $totalKidJan;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month Feb
    $getDetailFeb =mysql_query("CALL getDetailFebMemberCategory('$year')")or die(mysql_error());
    $get2 = mysql_fetch_assoc($getDetailFeb);
    $totalAdultFeb = $get2['adult'];
    $totalYouthFeb = $get2['youth'];
    $totalKidFeb = $get2['kid'];
    $totalAllCategoryFeb = $totalAdultFeb + $totalYouthFeb + $totalKidFeb;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month March
    $getDetailMar =mysql_query("CALL getDetailMarMemberCategory('$year')")or die(mysql_error());
    $get3 = mysql_fetch_assoc($getDetailMar);
    $totalAdultMar = $get3['adult'];
    $totalYouthMar = $get3['youth'];
    $totalKidMar = $get3['kid'];
    $totalAllCategoryMar = $totalAdultMar + $totalYouthMar + $totalKidMar;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month April
    $getDetailApr =mysql_query("CALL getDetailAprMemberCategory('$year')")or die(mysql_error());
    $get4 = mysql_fetch_assoc($getDetailApr);
    $totalAdultApr = $get4['adult'];
    $totalYouthApr = $get4['youth'];
    $totalKidApr = $get4['kid'];
    $totalAllCategoryApr =  $totalAdultApr + $totalYouthApr + $totalKidApr;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month May
    $getDetailMay =mysql_query("CALL getDetailMayMemberCategory('$year')")or die(mysql_error());
    $get5 = mysql_fetch_assoc($getDetailMay);
    $totalAdultMay = $get5['adult'];
    $totalYouthMay = $get5['youth'];
    $totalKidMay = $get5['kid'];
    $totalAllCategoryMay = $totalAdultMay + $totalYouthMay + $totalKidMay;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month Jun
    $getDetailJun =mysql_query("CALL getDetailJunMemberCategory('$year')")or die(mysql_error());
    $get6 = mysql_fetch_assoc($getDetailJun);
    $totalAdultJun = $get6['adult'];
    $totalYouthJun = $get6['youth'];
    $totalKidJun = $get6['kid'];
    $totalAllCategoryJun = $totalAdultJun + $totalYouthJun + $totalKidJun;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month July
    $getDetailJul =mysql_query("CALL getDetailJulMemberCategory('$year')")or die(mysql_error());
    $get7 = mysql_fetch_assoc($getDetailJul);
    $totalAdultJul = $get7['totalMale'];
    $totalYouthJul = $get7['youth'];
    $totalKidJul = $get7['kid'];
    $totalAllCategoryJul = $totalAdultJul + $totalYouthJul + $totalKidJul;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month August
    $getDetailAug =mysql_query("CALL getDetailAugMemberCategory('$year')")or die(mysql_error());
    $get8 = mysql_fetch_assoc($getDetailAug);
    $totalAdultAug = $get8['adult'];
    $totalYouthAug = $get8['youth'];
    $totalKidAug = $get8['kid'];
    $totalAllCategoryAug = $totalAdultAug + $totalYouthAug + $totalKidAug;
    mysql_close($con);

    include("../connection/config.php");  
    //Get for month September
    $getDetailSep =mysql_query("CALL getDetailSepMemberCategory('$year')")or die(mysql_error());
    $get9 = mysql_fetch_assoc($getDetailSep);
    $totalAdultSep = $get9['adult'];
    $totalYouthSep = $get9['youth'];
    $totalKidSep = $get9['kid'];
    $totalAllCategorySep = $totalAdultSep + $totalYouthSep + $totalKidSep;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month October
    $getDetailOct =mysql_query("CALL getDetailOctMemberCategory('$year')")or die(mysql_error());
    $get10 = mysql_fetch_assoc($getDetailOct);
    $totalAdultOct = $get10['adult'];
    $totalYouthOct = $get10['youth'];
    $totalKidOct = $get10['kid'];
    $totalAllCategoryOct =  $totalAdultOct + $totalYouthOct + $totalKidOct;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month November
    $getDetailNov =mysql_query("CALL getDetailNovMemberCategory('$year')")or die(mysql_error());
    $get11 = mysql_fetch_assoc($getDetailNov);
    $totalAdultNov = $get11['adult'];
    $totalYouthNov = $get11['youth'];
    $totalKidNov = $get11['kid'];
    $totalAllCategoryNov =  $totalAdultNov + $totalYouthNov + $totalKidNov;
    mysql_close($con);

    include("../connection/config.php");
    //Get for month December
    $getDetailDec =mysql_query("CALL getDetailDecMemberCategory('$year')")or die(mysql_error());
    $get12 = mysql_fetch_assoc($getDetailDec);
    $totalAdultDec = $get12['adult'];
    $totalYouthDec = $get12['youth'];
    $totalKidDec = $get12['kid'];
    $totalAllCategoryDec =  $totalAdultDec + $totalYouthDec + $totalKidDec;
    mysql_close($con);

    include("../connection/config.php");
    //Get for total Overall Adult
    $getOverallAdult =mysql_query("CALL getOverallAdultMemberCategory('$year')")or die(mysql_error());
    $get13 = mysql_fetch_assoc($getOverallAdult);
    $totalOverallAdult = $get13['totalOverallAdult'];
    mysql_close($con);

    include("../connection/config.php");
    //Get for total Overall Youth
    $getOverallYouth =mysql_query("CALL getOverallYouthMemberCategory('$year')")or die(mysql_error());
    $get14 = mysql_fetch_assoc($getOverallYouth);
    $totalOverallYouth = $get14['totalOverallYouth'];
    mysql_close($con);

    include("../connection/config.php");
    //Get for total Overall Kid
    $getOverallKid =mysql_query("CALL getOverallKidMemberCategory('$year')")or die(mysql_error());
    $get14 = mysql_fetch_assoc($getOverallKid);
    $totalOverallKid = $get14['totalOverallKid'];
    mysql_close($con);

    //Get for total Overall Gender Year
    $getOverallCategoryPerYear = $totalAllCategoryJan + $totalAllCategoryFeb + $totalAllCategoryMar + $totalAllCategoryApr + $totalAllCategoryMay + $totalAllCategoryJun + $totalAllCategoryJul + $totalAllCategoryAug + $totalAllCategorySep + $totalAllCategoryOct + $totalAllCategoryNov + $totalAllCategoryDec;

  include("../connection/config.php");
	$qryreport = mysql_query("CALL getExcellMemberCategory('$year')") or die(mysql_error());
	
	$sqlrows=mysql_num_rows($qryreport);
  $j=4;
  $k=5;
  $l=6;
  $m=7;
	
	while ($reportdisp=mysql_fetch_array($qryreport)) {
  $j=$j+1;
  $k=$k+1;
  $l=$l+1;
  $m=$m+1;

         //Row Dewasa
         $worksheet1->write_string($j,1,"$totalAdultJan");
         $worksheet1->write_string($j,2,"$totalAdultFeb");
         $worksheet1->write_string($j,3,"$totalAdultMar");
         $worksheet1->write_string($j,4,"$totalAdultApr");
         $worksheet1->write_string($j,5,"$totalAdultMay");
         $worksheet1->write_string($j,6,"$totalAdultJun");
         $worksheet1->write_string($j,7,"$totalAdultJul");
         $worksheet1->write_string($j,8,"$totalAdultAug");
         $worksheet1->write_string($j,9,"$totalAdultSep");
         $worksheet1->write_string($j,10,"$totalAdultOct");
         $worksheet1->write_string($j,11,"$totalAdultNov");
         $worksheet1->write_string($j,12,"$totalAdultDec");
         $worksheet1->write_string($j,13,"$totalOverallAdult");

         //Row Belia
         $worksheet1->write_string($k,1,"$totalYouthJan");
         $worksheet1->write_string($k,2,"$totalYouthFeb");
         $worksheet1->write_string($k,3,"$totalYouthMar");
         $worksheet1->write_string($k,4,"$totalYouthApr");
         $worksheet1->write_string($k,5,"$totalYouthMay");
         $worksheet1->write_string($k,6,"$totalYouthJun");
         $worksheet1->write_string($k,7,"$totalYouthJul");
         $worksheet1->write_string($k,8,"$totalYouthAug");
         $worksheet1->write_string($k,9,"$totalYouthSep");
         $worksheet1->write_string($k,10,"$totalYouthOct");
         $worksheet1->write_string($k,11,"$totalYouthNov");
         $worksheet1->write_string($k,12,"$totalYouthDec");
         $worksheet1->write_string($k,13,"$totalOverallYouth");

         //Row Kanak-Kanak
         $worksheet1->write_string($l,1,"$totalKidJan");
         $worksheet1->write_string($l,2,"$totalKidFeb");
         $worksheet1->write_string($l,3,"$totalKidMar");
         $worksheet1->write_string($l,4,"$totalKidApr");
         $worksheet1->write_string($l,5,"$totalKidMay");
         $worksheet1->write_string($l,6,"$totalKidJun");
         $worksheet1->write_string($l,7,"$totalKidJul");
         $worksheet1->write_string($l,8,"$totalKidAug");
         $worksheet1->write_string($l,9,"$totalKidSep");
         $worksheet1->write_string($l,10,"$totalKidOct");
         $worksheet1->write_string($l,11,"$totalKidNov");
         $worksheet1->write_string($l,12,"$totalKidDec");
         $worksheet1->write_string($l,13,"$totalOverallKid");

         //Row Jumlah
         $worksheet1->write_string($m,1,"$totalAllCategoryJan");
         $worksheet1->write_string($m,2,"$totalAllCategoryFeb");
         $worksheet1->write_string($m,3,"$totalAllCategoryMar");
         $worksheet1->write_string($m,4,"$totalAllCategoryApr");
         $worksheet1->write_string($m,5,"$totalAllCategoryMay");
         $worksheet1->write_string($m,6,"$totalAllCategoryJun");
         $worksheet1->write_string($m,7,"$totalAllCategoryJul");
         $worksheet1->write_string($m,8,"$totalAllCategoryAug");
         $worksheet1->write_string($m,9,"$totalAllCategorySep");
         $worksheet1->write_string($m,10,"$totalAllCategoryOct");
         $worksheet1->write_string($m,11,"$totalAllCategoryNov");
         $worksheet1->write_string($m,12,"$totalAllCategoryDec");
         $worksheet1->write_string($m,13,"$getOverallCategoryPerYear");
	}
	
$workbook->close();
mysql_close($con);
?>