<?php
include("../connection/config.php");

$tableName = $_POST['tableName'];
	
if($tableName == 'book_language'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query(" DELETE FROM $tableName WHERE 1")or die(mysql_error());
    
    //ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$bookLanguageID = $fileop[0];
		$bookLanguageName = $fileop[1];
		
		//INSERT .csv file data back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$bookLanguageID','$bookLanguageName')");
		
	}

	

	if($sql)
	{
			//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

elseif($tableName == 'attendance'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query(" DELETE FROM $tableName WHERE 1")or die(mysql_error());
    
    //ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$attendanceID = $fileop[0];
		$attendanceDate = $fileop[1];
		$attendanceTime = $fileop[2];
		$staffID = $fileop[3];
		$attendanceRace = $fileop[4];
		$attendanceGender = $fileop[5];
		$attendanceCategory = $fileop[6];
		$attendanceTotal = $fileop[7];

		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$attendanceID','$attendanceDate', '$attendanceTime', '$staffID', '$attendanceRace', '$attendanceGender', '$attendanceCategory', '$attendanceTotal')");
		
	}

	

	if($sql)
	{
			//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

elseif($tableName == 'attendance_statistic'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query(" DELETE FROM $tableName WHERE 1")or die(mysql_error());
    
    //ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$attendanceStatisticID = $fileop[0];
		$month = $fileop[1];
		$monthNum = $fileop[2];
		$year = $fileop[3];
		$totalMale = $fileop[4];
		$totalFemale = $fileop[5];
		$raceMelayu = $fileop[6];
		$raceCina = $fileop[7];
		$raceIndia = $fileop[8];
		$raceOther = $fileop[9];
		$adult = $fileop[10];
		$youth = $fileop[11];
		$kid = $fileop[12];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$attendanceStatisticID','$month', '$monthNum', '$year', '$totalMale', '$totalFemale', '$raceMelayu', '$raceCina', '$raceIndia', '$raceOther', '$adult', '$youth', '$kid')");
		
	}

	

	if($sql)
	{
			//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

elseif($tableName == 'audit_log'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query(" DELETE FROM $tableName WHERE 1")or die(mysql_error());
    
    //ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$auditLogID = $fileop[0];
		$staffID = $fileop[1];
		$logInDate = $fileop[2];
		$logOutDate = $fileop[3];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$auditLogID','$staffID', '$logInDate', '$logOutDate')");
		
	}

	

	if($sql)
	{
			//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

elseif($tableName == 'backup_log'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query(" DELETE FROM $tableName WHERE 1")or die(mysql_error());
    
    //ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$backupLogID = $fileop[0];
		$tableBackup = $fileop[1];
		$backupDateTime = $fileop[2];
		$descriptionBackup = $fileop[3];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$backupLogID','$tableBackup', '$backupDateTime', '$descriptionBackup')");
	}

	

	if($sql)
	{
			//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

elseif($tableName == 'blacklist'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query(" DELETE FROM $tableName WHERE 1")or die(mysql_error());
    
    //ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$blacklistID = $fileop[0];
		$memberID = $fileop[1];
		$infoBlastDate1 = $fileop[2];
		$infoBlastDate2 = $fileop[3];
		$infoBlastDate3 = $fileop[4];
		$noticeDate = $fileop[5];
		$signBoardDate = $fileop[6];
		$warningDate = $fileop[7];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$blacklistID','$memberID', '$infoBlastDate1', '$infoBlastDate2', '$infoBlastDate3', '$noticeDate', '$signBoardDate', '$warningDate')");
	}

	

	if($sql)
	{
			//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

elseif($tableName == 'book'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query("DELETE FROM $tableName WHERE 1")or die(mysql_error());
    
    //ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$bookID = $fileop[0];
		$bookTitle = $fileop[1];
		$bookISBN = $fileop[2];
		$typeBookID = $fileop[3];
		$author = $fileop[4];
		$placeOfIssue = $fileop[5];
		$publisher = $fileop[6];
		$yearsOfIssue = $fileop[7];
		$noOfAcquisition = $fileop[8];
		$dateOfAcquisition = $fileop[9];
		$callNo = $fileop[10];
		$bookPrice = $fileop[11];
		$registerDate = $fileop[12];
		$registerTime = $fileop[13];
		$bookLanguageID = $fileop[14];
		$bookStatus = $fileop[15];
		$memberID = $fileop[16];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$bookID','$bookTitle', '$bookISBN', '$typeBookID', '$author', '$placeOfIssue', '$publisher', '$yearsOfIssue', '$noOfAcquisition', '$dateOfAcquisition', '$callNo', '$bookPrice', '$registerDate', '$registerTime', '$bookLanguageID', '$bookStatus', '$memberID')");
	}

	

	if($sql)
	{
			//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

elseif($tableName == 'borrow'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query(" DELETE FROM $tableName WHERE 1")or die(mysql_error());
    
    //ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$borrowID = $fileop[0];
		$bookID = $fileop[1];
		$memberID = $fileop[2];
		$borrowStatus = $fileop[3];
		$borrowDate = $fileop[4];
		$returnDate = $fileop[5];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$borrowID','$bookID', '$memberID', '$borrowStatus', '$borrowDate', '$returnDate')");
	}

	

	if($sql)
	{
			//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

elseif($tableName == 'borrow_statistic'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query(" DELETE FROM $tableName WHERE 1")or die(mysql_error());
    
    //ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$borrowStatisticID = $fileop[0];
		$month = $fileop[1];
		$monthNum = $fileop[2];
		$year = $fileop[3];
		$totalMale = $fileop[4];
		$totalFemale = $fileop[5];
		$raceMelayu = $fileop[6];
		$raceCina = $fileop[7];
		$raceIndia = $fileop[8];
		$raceOther = $fileop[9];
		$adult = $fileop[10];
		$youth = $fileop[11];
		$kid = $fileop[12];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$borrowStatisticID','$month', '$monthNum', '$year', '$totalMale', '$totalFemale', '$raceMelayu', '$raceCina', '$raceIndia', '$raceOther', '$adult', '$youth', '$kid')");
	}

	

	if($sql)
	{
			//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

elseif($tableName == 'branch'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query(" DELETE FROM $tableName WHERE 1")or die(mysql_error());
    
    //ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$branchID = $fileop[0];
		$branchName = $fileop[1];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$branchID','$branchName')");
	}

	

	if($sql)
	{
			//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

elseif($tableName == 'contact'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query(" DELETE FROM $tableName WHERE 1")or die(mysql_error());
    
    //ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$contactID = $fileop[0];
		$contactFatherH = $fileop[1];
		$contactFatherO = $fileop[2];
		$contactFatherM = $fileop[3];
		$contactMotherH = $fileop[4];
		$contactMotherO = $fileop[5];
		$contactMotherM = $fileop[6];
		$contactSelfH = $fileop[7];
		$contactSelfO = $fileop[8];
		$contactSelfM = $fileop[9];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$contactID','$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM')");
	}

	

	if($sql)
	{
			//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

elseif($tableName == 'email'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query(" DELETE FROM $tableName WHERE 1")or die(mysql_error());
    
    //ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$emailID = $fileop[0];
		$emailFather = $fileop[1];
		$emailMother = $fileop[2];
		$emailSelf = $fileop[3];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$emailID', '$emailFather','$emailMother', '$emailSelf')");
	}

	

	if($sql)
	{
			//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

elseif($tableName == 'member'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query("DELETE FROM $tableName WHERE 1")or die(mysql_error());
    
	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$memberID = $fileop[0];
		$memberName = $fileop[1];
		$memberIC = $fileop[2];
		$memberBOD = $fileop[3];
		$memberGender = $fileop[4];
		$memberRace = $fileop[5];
		$memberAddress = $fileop[6];
		$emailID = $fileop[7];
		$contactID = $fileop[8];
		$memberType = $fileop[9];
		$memberStatus = $fileop[10];
		$staffID = $fileop[11];
		$totalBorrow = $fileop[12];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$memberID', '$memberName','$memberIC', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$emailID', '$contactID', '$memberType', '$memberStatus', '$staffID', '$totalBorrow')")or die(mysql_error());
	}

	if($sql)
	{
	//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	//ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());


	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

// elseif($tableName == 'member_date_register'){

// 	//RESET FK to dsabled before truncate table
// 	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
// 	//Truncate table
//     mysql_query("DELETE FROM $tableName WHERE 1")or die(mysql_error());

//     //ENABLED FK back
//     mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());
    
// 	$file = $_FILES['file']['tmp_name'];
// 	$handle = fopen($file,"r");	
// 	while(($fileop = fgetcsv($handle,1000,",")) !==false)
// 	{
// 		$memberDateRegisterID = $fileop[0];
// 		//$memberDateRegister = $fileop[1];
// 		//$memberDateExpired = $fileop[2];
// 		$memberID = $fileop[1];
// 		$staffID = $fileop[2];
		
// 		//INSERT .csv file back
// 		$sql = mysql_query("INSERT INTO $tableName(memberDateRegisterIDx, memberID, staffID) $tableName VALUES('$memberDateRegisterID', '$memberID', '$staffID')")or die(mysql_error());
// 	}

// 	if($sql)
// 	{
// 	//RECORD TO TABLE recovery_log
// 	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

// 	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
// 	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
// 	}
// 	else{
// 		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
// 	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
// 	}
// }

elseif($tableName == 'member_statistic'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query(" DELETE FROM $tableName WHERE 1")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$memberStatisticID = $fileop[0];
		$month = $fileop[1];
		$monthNum = $fileop[2];
		$year = $fileop[3];
		$totalMale = $fileop[4];
		$totalFemale = $fileop[5];
		$raceMelayu = $fileop[6];
		$raceCina = $fileop[7];
		$raceIndia = $fileop[8];
		$raceOther = $fileop[9];
		$adult = $fileop[10];
		$youth = $fileop[11];
		$kid = $fileop[12];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$memberStatisticID','$month', '$monthNum', '$year', '$totalMale', '$totalFemale', '$raceMelayu', '$raceCina', '$raceIndia', '$raceOther', '$adult', '$youth', '$kid')");
		
	}

	if($sql)
	{
	//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	//ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

// elseif($tableName == 'recovery_log'){

// 	//RESET FK to dsabled before truncate table
// 	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
// 	//Truncate table
//     mysql_query(" DELETE FROM $tableName WHERE 1")or die(mysql_error());

// 	$file = $_FILES['file']['tmp_name'];
// 	$handle = fopen($file,"r");	
// 	while(($fileop = fgetcsv($handle,1000,",")) !==false)
// 	{
// 		$recoveryLogID = $fileop[0];
// 		$tableBackup = $fileop[1];
// 		$backupDateTime = $fileop[2];
// 		$descriptionBackup = $fileop[3];
		
// 		//INSERT .csv file back
// 		$sql = mysql_query("INSERT INTO $tableName VALUES('$recoveryLogID', '$tableBackup', '$backupDateTime' , '$descriptionBackup'")or die(mysql_error());
// 	}
	
// 	if($sql)
// 	{
// 	//RECORD TO TABLE recovery_log
// 	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

// 	//ENABLED FK back
//     mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

// 	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
// 	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
// 	}
// 	else{
// 		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
// 	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
// 	}
// }

// elseif($tableName == 'staff'){

// 	//RESET FK to dsabled before truncate table
// 	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
// 	//Truncate table
//     mysql_query("DELETE FROM $tableName WHERE 1")or die(mysql_error());

// 	$file = $_FILES['file']['tmp_name'];
// 	$handle = fopen($file,"r");	
// 	while(($fileop = fgetcsv($handle,1000,",")) !==false)
// 	{
// 		$staffID = $fileop[0];
// 		$staffIDDecrypt = $fileop[1];
// 		$staffName = $fileop[2];
// 		$staffContact = $fileop[3];
// 		$staffEmail = $fileop[4];
// 		$staffPosition = $fileop[5];
// 		$staffPassword = $fileop[6];
// 		$staffRowLevel = $fileop[7];
// 		$branchID = $fileop[8];
// 		$staffImg = $fileop[9];
		
// 		//INSERT .csv file back
// 		$sql = mysql_query("INSERT INTO $tableName VALUES('$staffID','$staffIDDecrypt', '$staffName', '$staffContact', '$staffEmail', '$staffPosition', '$staffPassword', '$staffRowLevel', '$branchID', '$staffImg')");
		
// 	}

// 	if($sql)
// 	{
// 	//RECORD TO TABLE recovery_log
// 	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

// 	//ENABLED FK back
//     mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

// 	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
// 	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
// 	}
// 	else{
// 		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
// 	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
// 	}
// }

elseif($tableName == 'statistic_year'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query("DELETE FROM $tableName WHERE 1")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$statisticYearID = $fileop[0];
		$year = $fileop[1];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$statisticYearID', '$year')");
		
	}

	if($sql)
	{
	//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	//ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

elseif($tableName == 'total_warning'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query("DELETE FROM $tableName WHERE 1")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$totalWarningID = $fileop[0];
		$memberID = $fileop[1];
		$totalWarning = $fileop[2];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$totalWarningID', '$memberID', '$totalWarning')");
		
	}

	if($sql)
	{
	//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	//ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}

elseif($tableName == 'type_book'){

	//RESET FK to dsabled before truncate table
	mysql_query("SET foreign_key_checks = 0")or die(mysql_error());
	
	//Truncate table
    mysql_query("DELETE FROM $tableName WHERE 1")or die(mysql_error());

	$file = $_FILES['file']['tmp_name'];
	$handle = fopen($file,"r");	
	while(($fileop = fgetcsv($handle,1000,",")) !==false)
	{
		$typeBookID = $fileop[0];
		$typeBookName = $fileop[1];
		
		//INSERT .csv file back
		$sql = mysql_query("INSERT INTO $tableName VALUES('$typeBookID', '$typeBookName')");
		
	}

	if($sql)
	{
	//RECORD TO TABLE recovery_log
	mysql_query("INSERT INTO recovery_log VALUES('', '$tableName', NOW(), 'RECOVERY DATA')")or die(mysql_error());

	//ENABLED FK back
    mysql_query("SET foreign_key_checks = 1;")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya pemulihan rajah '.$tableName.'!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf tidak berjaya!")</script>';
	print '<meta http-equiv="refresh" content="0;URL=../pages/pemulihanData.php">';
	}
}
?>