<?php
include("../connection/config.php");
$year=$_GET['year'];
?>
<div id="buttonAreaKategori">
    <button title="Muat Turun Excel" name="btnExcell" type="submit" class="btn btn-default" onclick="window.location.href='../function/fnExcellVisitorByCategory.php?year=<?php echo $year; ?>'"><i class="fa fa-file-excel-o"></i></button>&nbsp;<button type="submit" onClick="printDivKategori('printableAreaKategori')" title="Cetak" type="submit" class="btn btn-default"><i class="fa fa-print fa-fw"></i></button>
</div>
<br>
<table class="table table-striped table-bordered table-hover">
    <?php
        include("../connection/config.php");
        $select=mysql_query("CALL fnExcellVisitorByCategory('$year')")or die(mysql_error());
        mysql_close($con);

        echo'<thead>
                <tr>
                    <th>Bulan| '.$year.'</th>
                    <th>Dewasa</th>
                    <th>Kanak</th>
                    <th>Belia</th>
                    <th>Jumlah</th>
                </tr>
            </thead>
        <tbody>';
        while($row=mysql_fetch_array($select))
        {
        $adult = $row['adult'];
        $youth = $row['youth'];
        $kid = $row['kid'];
        $month = $row['month'];
        $totalAllHorizontal = $adult + $kid + $youth; //Mendatar
        echo'<tr>';
        echo '<td>'.$month.'</td>';
        echo '<td style="color: blue">'.$adult.'</td>';
        echo '<td style="color: red">'.$kid.'</td>';
        echo '<td style="color: green">'.$youth.'</td>';
        echo '<td><b>'.$totalAllHorizontal.'</b></td>';
        echo'</tr>';
        }

        include("../connection/config.php");
        $getTotalAdult =mysql_query("CALL getTotalAdultVisitorByCategory('$year')")or die(mysql_error());
        $get = mysql_fetch_assoc($getTotalAdult);
        $totalAdult = $get['totalAdult'];
        mysql_close($con);

        include("../connection/config.php");
        $getTotalYouth =mysql_query("CALL getTotalYouthVisitorByCategory('$year')")or die(mysql_error());
        $get1 = mysql_fetch_assoc($getTotalYouth);
        $totalYouth = $get1['totalYouth'];
        mysql_close($con);

        include("../connection/config.php");
        $getTotalKid =mysql_query("CALL getTotalKidVisitorByCategory('$year')")or die(mysql_error());
        $get2 = mysql_fetch_assoc($getTotalKid);
        $totalKid = $get2['totalKid'];
        mysql_close($con);

        $totalOverall = $totalAdult + $totalYouth + $totalKid;

        echo'<tr>
                <td><b>Jumlah</b></td>
                <td><b>'.$totalAdult.'<b></td>
                <td><b>'.$totalKid.'<b></td>
                <td><b>'.$totalYouth.'</b></td>
                <td><b>'.$totalOverall.'<b></td>
            </tr>';
        
    ?>  
    </tbody>
</table>