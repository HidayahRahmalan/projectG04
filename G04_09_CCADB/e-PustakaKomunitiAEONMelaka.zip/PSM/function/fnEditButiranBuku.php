<!-- register data -->
<?php

include("../connection/config.php");

$bookID = $_POST['bookID'];
$bookTitle = $_POST['bookTitle'];
$bookISBN = $_POST['bookISBN'];
$typeBookID = $_POST['typeBookID'];
$author = $_POST['author'];
$placeOfIssue = $_POST['placeOfIssue'];
$publisher = $_POST['publisher'];
$yearsOfIssue = $_POST['yearsOfIssue'];
$noOfAcquisition = $_POST['noOfAcquisition'];
$dateOfAcquisition = $_POST['dateOfAcquisition'];
$callNo = $_POST['callNo'];
$bookPrice = $_POST['bookPrice'];
$bookLanguageID = $_POST['bookLanguageID'];

	mysql_query("CALL fnEditButiranBuku('$bookTitle', '$typeBookID', '$author', '$placeOfIssue', '$publisher', '$yearsOfIssue', '$noOfAcquisition', '$dateOfAcquisition', '$bookPrice', '$bookLanguageID', '$bookID')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya update buku :'.$bookTitle.'!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/inventoriBuku.php">';

?>