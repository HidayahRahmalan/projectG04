<?php

$attendanceID = $_GET['attendanceID'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk edit kedatangan ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnPadamKedatangan.php?attendanceID='.$attendanceID.'";
	  }
	  
	 else
	 {
		  self.location="../pages/kedatanganPengunjung.php";
	 }
	  
	  </script>';
?>