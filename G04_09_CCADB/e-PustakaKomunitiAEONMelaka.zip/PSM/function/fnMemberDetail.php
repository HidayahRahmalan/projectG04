<?php

include("../connection/config.php");

function getUsersData($id)
{
	$array = array();
	$q = mysql_query("SELECT * FROM member WHERE memberIDEncrypt='$id'");
	while($r = mysql_fetch_assoc($q))
	{
		$array['memberID'] = $r['memberID'];
		$array['memberIDEncrypt'] = $r['memberIDEncrypt'];
		$array['memberName'] = $r['memberName'];
		$array['memberIC'] = $r['memberIC'];
		$array['memberBOD'] = $r['memberBOD'];
		$array['memberGender'] = $r['memberGender'];
		$array['memberRace'] = $r['memberRace'];
		$array['memberAddress'] = $r['memberAddress'];
		$array['emailID'] = $r['emailID'];
		$array['contactID'] = $r['contactID'];
		$array['memberType'] = $r['memberType'];
		$array['memberStatus'] = $r['memberStatus'];
		$array['totalBorrow'] = $r['totalBorrow'];
		$array['memberPassword'] = $r['memberPassword'];
	}
	return $array;
}

function getId($id)
{
	$q = mysql_query("SELECT `memberIDEncrypt` FROM `member` WHERE `memberIDEncrypt`='".$id."'");
	while($r = mysql_fetch_assoc($q))
	{
		return $r['memberIDEncrypt'];
	}
}

function userExists($id)
{
	$numrows = mysql_num_rows(mysql_query("SELECT memberIDEncrypt FROM member WHERE memberIDEncrypt='$id'"));
	if($numrows==1)
		return true;
	else
		return false;	
}
?>