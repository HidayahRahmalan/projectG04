<?php

$staffID = $_GET['staffID'];
$branchID = $_GET['branchID'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk padam staff ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnDeleteStaffMelaluiCawangan.php?staffID='.$staffID.'&branchID='.$branchID.'";
	  }
	  
	 else
	 {
		  self.location="../pages/paparanSenaraiStaffMengikutCawangan.php?branchID='.$branchID.'";
	 }
	  
	  </script>';
?>