<?php

$infoBlastDate1 = $_POST['infoBlastDate1'];
$infoBlastDate2 = $_POST['infoBlastDate2'];
$infoBlastDate3 = $_POST['infoBlastDate3'];
$warningDate = $_POST['warningDate'];
$memberID = $_POST['memberID'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk Edit Butiran Log Tarikh Senarai Hitam ahli ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnEditLogButiranHitam.php?infoBlastDate1='.$infoBlastDate1.'&infoBlastDate2='.$infoBlastDate2.'&infoBlastDate3='.$infoBlastDate3.'&warningDate='.$warningDate.'&memberID='.$memberID.'";
	  }
	  
	 else
	 {
		  self.location="../pages/editButiranSenaraiHitam.php?memberID='.$memberID.'";
	 }
	  
	  </script>';
?>