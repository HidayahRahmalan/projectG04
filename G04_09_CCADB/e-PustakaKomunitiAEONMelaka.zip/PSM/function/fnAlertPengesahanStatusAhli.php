<?php

$memberID = $_POST['memberID'];

if(isset($_POST['btnSah'])){
 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk mengesahkan status ahli ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnUpdateStatusMemberSah.php?memberID='.$memberID.'";
	  }
	  
	 else
	 {
		  self.location="../pages/paparanBorangAhli.php?memberID='.$memberID.'";
	 }
	  
	  </script>';
}

if(isset($_POST['btnDalamProses'])){
 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk dalam proses status ahli ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnUpdateStatusMemberDalamProses.php?memberID='.$memberID.'";
	  }
	  
	 else
	 {
		  self.location="../pages/paparanBorangAhli.php?memberID='.$memberID.'";
	 }
	  
	  </script>';
}
?>