<!-- register data -->
<?php

include("../connection/config.php");

$infoBlastDate1 = $_POST['infoBlastDate1'];
$infoBlastDate2 = $_POST['infoBlastDate2'];
$infoBlastDate3 = $_POST['infoBlastDate3'];
$warningDate = $_POST['warningDate'];
$memberID = $_POST['memberID'];

	mysql_query("CALL fnEditLogButiranHitam('$infoBlastDate1', '$infoBlastDate2', '$infoBlastDate3', '$warningDate', '$memberID')")or die(mysql_error());

	echo '<script language = "JavaScript">alert("Berjaya Update Butiran Log Hitam ahli: '.$memberID.'!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/editButiranSenaraiHitam.php?memberID='.$memberID.'">';

mysql_close($con);
?>