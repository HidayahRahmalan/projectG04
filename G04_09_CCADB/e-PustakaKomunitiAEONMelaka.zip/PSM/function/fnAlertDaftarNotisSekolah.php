<?php

$memberID = $_POST['memberID'];
$noticeDate = $_POST['noticeDate'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk padam ahli ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnDaftarNotisSekolah.php?memberID='.$memberID.'&noticeDate='.$noticeDate.'";
	  }
	  
	 else
	 {
		  self.location="../pages/ahliSenaraiHitam.php";
	 }
	  
	  </script>';
?>