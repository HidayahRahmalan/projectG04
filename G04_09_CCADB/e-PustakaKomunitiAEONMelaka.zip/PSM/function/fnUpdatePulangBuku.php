<?php
	include("../connection/config.php");

	$borrowID = $_GET['borrowID'];
	$memberID = $_GET['memberID'];	

	//Get Detail Book
	$getBorrowBookDetail = mysql_query("CALL getBorrowBookDetail('$borrowID')");
	$get1 = mysql_fetch_assoc($getBorrowBookDetail);
	$bookID = $get1['bookID'];
	mysql_close($con);

		include("../connection/config.php");
		//UPDATE book Status
		$updateBookStatusSediaAda = mysql_query("CALL updateBookStatusSediaAda('$bookID')")or die(mysql_error());
		mysql_close($con);

		include("../connection/config.php");
		//UPDATE borrow Status
		mysql_query("CALL updateBorrowStatusPulang('$borrowID')")or die(mysql_error());
		mysql_close($con);

		include("../connection/config.php");
		//UPDATE totalBorrow on Member(--)
		mysql_query("CALL updateTotalBorrowMemberDecrease('$memberID')")or die(mysql_error());
		mysql_close($con);

		if($updateBookStatusSediaAda){
			echo '<script language = "JavaScript">alert("Maklumat pinjaman berjaya update!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/paparanButiranPinjamanBuku.php?memberID='.$memberID.'">';
		}else{
			echo '<script language = "JavaScript">alert("Harap Maaf, Maklumat pinjaman Tidak berjaya update!")</script>';
				print '<meta http-equiv="refresh" content="0;URL=../pages/paparanButiranPinjamanBuku.php?memberID='.$memberID.'">';
		}
		
		
?> 	