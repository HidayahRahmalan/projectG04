<?php

include("../connection/config.php");

$staffID = $_GET['staffID'];

	//update audit_log [LOGOUT]
	$fnLogoutStaff = mysql_query("CALL fnLogoutStaff('$staffID')")or die(mysql_error());

session_start();
session_destroy();
header("location:../index.php");
?>