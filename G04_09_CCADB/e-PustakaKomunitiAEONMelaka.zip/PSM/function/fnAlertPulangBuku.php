<?php

$borrowID = $_GET['borrowID'];
$memberID = $_GET['memberID'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk Sah Pemulangan Buku peminjam ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnUpdatePulangBuku.php?borrowID='.$borrowID.'&memberID='.$memberID.'";
	  }
	  
	 else
	 {
		  self.location="../pages/paparanButiranPeminjamBuku.php?memberID='.$memberID.'";
	 }
	  
	  </script>';
?>