<!-- register data -->
<?php

include("../connection/config.php");

$bookID = $_GET['bookID'];
$bookStatus = $_GET['bookStatus'];

	if($bookStatus == 'SEDIA ADA'){

		mysql_query("CALL fnDeleteInventoriBuku('$bookID')")or die(mysql_error());
			print '<meta http-equiv="refresh" content="0;URL=../pages/inventoriBuku.php">';
	}
	else if($bookStatus == 'DALAM PINJAMAN'){
		echo '<script language = "JavaScript">alert("Harap maaf Buku tidak boleh dipadam jika status DALAM PINJAMAN!")</script>';
					print '<meta http-equiv="refresh" content="0;URL=../pages/inventoriBuku.php">';
	}
	else{
		echo '<script language = "JavaScript">alert("Harap maaf transaksi tergendala, sila hunbungi pihak admin untuk rujukan lebih lanjut!")</script>';
					print '<meta http-equiv="refresh" content="0;URL=../pages/inventoriBuku.php">';
	}
	mysql_close($con);
?>