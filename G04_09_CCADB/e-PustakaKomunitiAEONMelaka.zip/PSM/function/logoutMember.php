<?php

include("../connection/config.php");

$memberID = $_GET['memberID'];

//update audit_log [LOGOUT]
$fnLogoutMember = mysql_query("CALL fnLogoutMember('$memberID')")or die(mysql_error());

session_start();
session_destroy();
header("location:../index.php");
?>