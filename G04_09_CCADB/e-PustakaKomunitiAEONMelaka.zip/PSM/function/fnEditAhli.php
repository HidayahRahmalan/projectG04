<!-- register data -->
<?php
if(isset($_POST['btnEditButiranAhli'])){

$memberID = $_POST['memberID'];
$memberName= mysql_real_escape_string($_POST['memberName']);
$memberBOD = $_POST['memberBOD'];
$memberGender = $_POST['memberGender'];
$memberRace = $_POST['memberRace'];
$emailID = $_POST['emailID'];
$memberAddress = $_POST['memberAddress'];
$memberType = $_POST['memberType'];
$memberStatus = $_POST['memberStatus'];
$emailFather = $_POST['emailFather'];
$emailMother = $_POST['emailMother'];
$emailSelf = $_POST['emailSelf'];
$contactID = $_POST['contactID'];
$contactFatherH = $_POST['contactFatherH'];
$contactFatherO = $_POST['contactFatherO'];
$contactFatherM = $_POST['contactFatherM'];
$contactMotherH = $_POST['contactMotherH'];
$contactMotherO = $_POST['contactMotherO'];
$contactMotherM = $_POST['contactMotherM'];
$contactSelfH = $_POST['contactSelfH'];
$contactSelfO = $_POST['contactSelfO'];
$contactSelfM = $_POST['contactSelfM'];
	
	include("../connection/config.php");
	//UPDATE Contact
	mysql_query("CALL fnUpdateContact('$contactFatherH', '$contactFatherO', '$contactFatherM', '$contactMotherH', '$contactMotherO', '$contactMotherM', '$contactSelfH', '$contactSelfO', '$contactSelfM', '$contactID')")or die(mysql_error());
	mysql_close($con);

	include("../connection/config.php");
	//UPDATE Email
	mysql_query("CALL fnUpdateEmail('$emailFather', '$emailMother', '$emailSelf', '$emailID')")or die(mysql_error());
	mysql_close($con);

	include("../connection/config.php");
	$sql = mysql_query("CALL fnUpdateMember('$memberName', '$memberBOD', '$memberGender', '$memberRace', '$memberAddress', '$memberType', '$memberStatus', '$memberID')")or die(mysql_error());
	mysql_close($con);

	if($sql){
		echo '<script language = "JavaScript">alert("Berjaya update maklumat peribadi ahli : '.$memberName.'!")</script>';
			print '<meta http-equiv="refresh" content="0;URL=../pages/paparanEditButiranAhli.php?memberID='.$memberID.'">';
	}else{
		echo '<script language = "JavaScript">alert("Harap Maaf, Tidak Berjaya update maklumat peribadi ahli : '.$memberName.'!")</script>';
			print '<meta http-equiv="refresh" content="0;URL=../pages/paparanEditButiranAhli.php?memberID='.$memberID.'">';
	}
}
?>