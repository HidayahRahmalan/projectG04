<!-- register data -->
<?php

include("../connection/config.php");

$bookTitle = $_POST['bookTitle'];
$bookISBN = $_POST['bookISBN'];
$typeBookID = $_POST['typeBookID'];
$author = $_POST['author'];
$placeOfIssue = $_POST['placeOfIssue'];
$publisher = $_POST['publisher'];
$yearsOfIssue = $_POST['yearsOfIssue'];
$noOfAcquisition = $_POST['noOfAcquisition'];
$dateOfAcquisition = $_POST['dateOfAcquisition'];
$callNo = $_POST['callNo'];
$bookPrice = $_POST['bookPrice'];
$bookLanguageID = $_POST['bookLanguageID'];

	$insertNewBook = mysql_query("CALL insertNewBook('$bookTitle', '$bookISBN', '$typeBookID', '$author', '$placeOfIssue','$publisher', '$yearsOfIssue', '$noOfAcquisition', '$dateOfAcquisition', '$callNo', '$bookPrice','$bookLanguageID')")or die(mysql_error());

if($insertNewBook){
	echo '<script language = "JavaScript">alert("Berjaya daftar buku '.$bookTitle.'!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/inventoriBuku.php">';
}else{
	echo '<script language = "JavaScript">alert("Tidak Berjaya!")</script>';
		print '<meta http-equiv="refresh" content="0;URL=../pages/inventoriBuku.php">';
}

mysql_close($con);
?>