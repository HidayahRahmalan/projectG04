<?php

$attendanceID = $_POST['attendanceID'];
$attendanceTotal = $_POST['attendanceTotal'];

 echo 
	 ' <script language = "JavaScript">
	  var papar1 = confirm("Anda pasti untuk edit kedatangan ini?");
	  
	  if(papar1==true)
	  {
		 self.location="fnEditKedatangan.php?attendanceID='.$attendanceID.'&attendanceTotal='.$attendanceTotal.'";
	  }
	  
	 else
	 {
		  self.location="../pages/editKedatangan.php?attendanceID='.$attendanceID.'";
	 }
	  
	  </script>';
?>