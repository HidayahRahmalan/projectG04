<?php
mysql_connect("127.0.0.1", "root", "") or die ("Oops! Server not connected"); // Connect to the host
mysql_select_db("psm") or die ("Oops! DB not connected"); // select the database

$con = mysql_connect("127.0.0.1", "root", "") or die ("Oops! Server not connected"); // Connect to the host
mysql_select_db("psm") or die ("Oops! DB not connected"); // select the database
?>